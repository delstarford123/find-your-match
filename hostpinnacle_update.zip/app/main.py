import os
import sys
import re
import time
import random
import string
import io
import base64
import qrcode
import json
import logging
import requests
import threading
from functools import wraps
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv
import ipaddress
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask import Flask, render_template, session, redirect, url_for, flash, request, jsonify, send_from_directory, make_response
try:
    from pywebpush import webpush, WebPushException
except ImportError as e:
    print(f"⚠️ Warning: pywebpush could not be imported ({e}). Push notifications will be disabled.")
    webpush = None
    WebPushException = Exception
from groq import Groq
from flask_wtf.csrf import CSRFProtect

from werkzeug.security import generate_password_hash, check_password_hash
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ==========================================
# 1. PATH SETUP & ENVIRONMENT
# ==========================================
load_dotenv()
#  This line tells Python where to find the 'app' folder
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Define East Africa Time (UTC+3) for accurate Kenyan timestamps
EAT = timezone(timedelta(hours=3))

# Configure Central Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==========================================
# 2. LOCAL APP IMPORTS
# ==========================================
#  NOW it is safe to import from 'app' because the path is set up above! 👇
from app.email_service import (
    send_date_approval_email, 
    send_date_request_to_merchant_email,
    send_date_request_to_partner_email,
    send_group_invite_email,
    send_verification_email,
    send_broadcast_email,
    send_admin_alert_email,
    send_premium_activation_email,
    send_monday_matches_email,
    send_friday_matches_email
)

from app.database import (
    db, storage, get_all_profiles, save_schedule, update_user_bio, 
    save_chat_message, get_chat_history, save_swipe, save_date_feedback,
    get_restaurant, get_restaurant_bookings, update_booking_status, terminate_connection,
    get_all_restaurants, delete_user_account, increment_restaurant_view,
    get_user_matches, create_date_booking,
    get_campus_managers, add_campus_manager, get_institutions, add_institution
)

from app.services.recommendation_engine import generate_ranked_deck
from app.services.moderation import contains_phone_number, analyze_safety
from app.payments import initiate_stk_push, check_payment_status, format_phone_number

# ==========================================
# 3. AI COMPANION SERVICE (GROQ)
# ==========================================
# Pull the key securely from the system environment
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
client = Groq(api_key=GROQ_API_KEY) if GROQ_API_KEY else None


def get_ai_companion_response(user_text, user_gender="unknown", system_prompt_override=None):
    """Connects to Groq and dynamically adjusts persona based on user gender."""
    if not client:
        print("GROQ_API_KEY is missing from api_key.py!")
        return "My AI brain is currently resting. (API Key missing!)"

    model_id = "llama3-70b-8192" 
    
    # Determine the AI's persona based on the user's gender
    user_g = str(user_gender).strip().lower()
    
    if user_g in ["male", "m"]:
        ai_persona = "female"
        target_user = "male"
    elif user_g in ["female", "f"]:
        ai_persona = "male"
        target_user = "female"
    else:
        # Fallback if gender isn't set properly
        ai_persona = "friendly"
        target_user = "university"

    # Build the dynamic system prompt
    if system_prompt_override:
        system_prompt = system_prompt_override
    else:
        system_prompt = (
            f"You are a friendly, flirty, and supportive {ai_persona} AI dating companion "
            f"chatting with a {target_user} university student at Masinde Muliro University of Science and Technology (MMUST). "
            "Keep your responses short, clean, and encouraging. Occasionally use Kenyan campus slang. "
        )
        
    system_prompt += "\nIMPORTANT: Output ONLY the final response. DO NOT output 'Here's a thinking process', 'Analysis:', or any internal reasoning traces. Do not wrap your response in quotes."
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_text}
    ]
    
    try:
        chat_completion = client.chat.completions.create(
            messages=messages,
            model=model_id,
            max_tokens=150,
            temperature=0.7,
            top_p=0.9
        )
        
        import re
        reply = chat_completion.choices[0].message.content.strip()
        reply = re.sub(r'<think>.*?</think>', '', reply, flags=re.DOTALL).strip()
        return reply if reply else "I'm listening, tell me more!"
        
    except Exception as e:
        print(f"Groq API Error: {e}")
        return "The campus Wi-Fi is acting up! Try sending that again?"

def get_wingman_response(system_prompt, user_text):
    """Dedicated AI handler for Wingman tasks (Icebreaker, Roaster). Forces JSON to strip reasoning traces."""
    if not client:
        return "GROQ_API_KEY is missing."

    model_id = "llama3-70b-8192"
    
    # Force JSON output to reliably bypass "Here's a thinking process:" text
    strict_system_prompt = system_prompt + "\n\nYou MUST respond with ONLY a valid JSON object in this exact format: {\"result\": \"<your roast or icebreakers here>\"}. Do NOT output any thinking process before or after the JSON."
    
    messages = [
        {"role": "system", "content": strict_system_prompt},
        {"role": "user", "content": user_text}
    ]
    
    try:
        chat_completion = client.chat.completions.create(
            messages=messages,
            model=model_id,
            max_tokens=350,
            temperature=0.7
        )
        
        reply = chat_completion.choices[0].message.content.strip()
        
        import re
        # Strip <think> tags just in case
        reply = re.sub(r'<think>.*?</think>', '', reply, flags=re.DOTALL).strip()
        
        # Extract the JSON block
        json_match = re.search(r'\{.*\}', reply, flags=re.DOTALL)
        if json_match:
            import json
            try:
                data = json.loads(json_match.group(0))
                return data.get("result", reply)
            except json.JSONDecodeError:
                return reply
        
        return reply
        
    except Exception as e:
        print(f"Groq API Error (Wingman): {e}")
        return "The AI Wingman is currently unavailable."
# ==========================================
# 4. INITIALIZE FLASK APP & WEBSOCKETS
# ==========================================
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "delstarford_works_secret_2026")
app.config['FIREBASE_DB_URL'] = os.getenv("FIREBASE_DB_URL", "https://mmust-dating-site-default-rtdb.firebaseio.com/")
# Keep sessions alive for 24 hours so checkout_id survives until Safaricom callback arrives
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(seconds=int(os.getenv('PERMANENT_SESSION_LIFETIME', 86400)))

@app.context_processor
def inject_firebase_config():
    return dict(firebase_api_key=os.getenv('FIREBASE_API_KEY', ''))
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'   # needed for redirect flows
app.config['SESSION_COOKIE_SECURE'] = True        # HTTPS only (your domain is HTTPS)

# --- NEW: FIREWALL & RATE LIMITER ---
# Rate limiting is disabled by default in this production WSGI environment to prevent
# Python 3.13 thread-creation crashes under Phusion Passenger.
limiter = Limiter(
    get_remote_address,
    app=app,
    enabled=False
)
# Initialize CSRF Protection
csrf = CSRFProtect(app)
# Known Safaricom API IP Subnets
SAFARICOM_IPS = [
    "196.201.214.0/24",
    "196.201.213.0/24",
    "196.201.212.0/24",
    "196.201.211.0/24"
]

def get_real_ip():
    """Safely extracts the real IP behind cloud proxies like Render or Nginx."""
    if request.headers.getlist("X-Forwarded-For"):
        return request.headers.getlist("X-Forwarded-For")[0].split(',')[0].strip()
    return request.remote_addr

def get_base_url():
    """Dynamically determines the base URL for callbacks and referrals."""
    # Use environment variable if provided (best for production)
    env_url = os.getenv("BASE_URL")
    if env_url:
        return env_url.rstrip('/')
    
    # Fallback to request host, but force https if not on localhost
    base_url = request.host_url.rstrip('/')
    if not any(local in base_url for local in ['127.0.0.1', 'localhost']) and base_url.startswith('http://'):
        base_url = base_url.replace('http://', 'https://')
    return base_url
# app/main.py

# ==========================================
# 🛡️ SESSION HARDENING CONFIG
# ==========================================
app.config.update(
    # Prevents JavaScript from reading the cookie (prevents XSS hijacking)
    SESSION_COOKIE_HTTPONLY=True,
    
    # Ensures the cookie is only sent over HTTPS (Prevents Wi-Fi sniffing)
    # Note: If you are running locally (http://127.0.0.1:5000), 
    # set this to False, but ALWAYS True for your live site.
    SESSION_COOKIE_SECURE=True, 
    
    # Prevents CSRF (already handled by Flask-WTF, but this is an extra layer)
    SESSION_COOKIE_SAMESITE='Lax',
    
    # Hardens the session length to 30 days
    PERMANENT_SESSION_LIFETIME=timedelta(days=30)
)
def is_safaricom_ip(ip_str):
    """Verifies if an incoming request is actually from Safaricom."""
    try:
        ip = ipaddress.ip_address(ip_str)
        for network in SAFARICOM_IPS:
            if ip in ipaddress.ip_network(network):
                return True
        # Allow local testing via Postman/ngrok ONLY if running in debug mode
        if app.debug and ip_str == '127.0.0.1': 
            return True 
        return False
    except ValueError:
        return False
# VAPID Keys for Push Notifications
try:
    from app.config import VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_CLAIMS
    app.config['VAPID_PUBLIC_KEY'] = VAPID_PUBLIC_KEY
    app.config['VAPID_PRIVATE_KEY'] = VAPID_PRIVATE_KEY
    app.config['VAPID_CLAIMS'] = VAPID_CLAIMS
except Exception as _vapid_err:
    logger.warning(f"Error loading VAPID config: {_vapid_err}")
    mail_username = os.getenv("MAIL_USERNAME", "delstarfordisaiah@gmail.com")
    app.config['VAPID_PUBLIC_KEY'] = "BKQCzvEGmGI5a1Ynzx_ANsriL6EKKL9gP-ncDrXhbR3Uqt9tqu94hLmzWafWx0ROucd6K8tJrsu3skzFwP2uIUk"
    app.config['VAPID_PRIVATE_KEY'] = os.path.abspath(os.path.join(os.path.dirname(__file__), '../private_key.pem'))
    app.config['VAPID_CLAIMS'] = {"sub": f"mailto:{mail_username}"}

@app.context_processor
def inject_pwa_vapid_key():
    return {
        'vapid_public_key': app.config.get(
            'VAPID_PUBLIC_KEY',
            'BKQCzvEGmGI5a1Ynzx_ANsriL6EKKL9gP-ncDrXhbR3Uqt9tqu94hLmzWafWx0ROucd6K8tJrsu3skzFwP2uIUk'
        )
    }

# Secure in production, False in development
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('FLASK_ENV') == 'production'



# ==========================================
# 📊 SYSTEM STATISTICS CALCULATOR
# ==========================================
def get_real_system_stats():
    """Calculates the raw, un-overridden system statistics from the database."""
    try:
        all_profiles = db.reference('users').get() or {}
        all_ledger = db.reference('ledger').get() or {}
        all_bookings = db.reference('bookings').get() or {}
        
        real_total_users = 0
        if isinstance(all_profiles, dict):
            real_total_users = len(all_profiles)
            
        real_student_revenue = 0
        real_b2b_revenue = 0
        
        # Calculate Student Revenue from profiles
        if isinstance(all_profiles, dict):
            for p_data in all_profiles.values():
                if isinstance(p_data, dict) and p_data.get('is_paid'):
                    package = p_data.get('subscription_package', 'gold')
                    real_student_revenue += 99 if package == 'diamond' else 50
                    
        # Calculate B2B Revenue from ledger
        if isinstance(all_ledger, dict):
            for entry in all_ledger.values():
                if isinstance(entry, dict):
                    real_b2b_revenue += int(entry.get('amount', 0))
                    
        return {
            'total_users': real_total_users,
            'student_revenue': real_student_revenue,
            'b2b_revenue': real_b2b_revenue,
            'total_revenue': real_student_revenue + real_b2b_revenue
        }
    except Exception as e:
        logger.error(f"Error calculating real system stats: {e}")
        return {
            'total_users': 0,
            'student_revenue': 0,
            'b2b_revenue': 0,
            'total_revenue': 0
        }

# ==========================================
# 🎁 GLOBAL TEMPLATE CONTEXT & FILTERS
# ==========================================
@app.template_filter('toLocaleString')
def to_locale_string_filter(value):
    """Formats a number with commas (e.g., 1000 -> 1,000)."""
    try:
        if value is None:
            return "0"
        num = float(value)
        if num.is_integer():
            return "{:,}".format(int(num))
        return "{:,}".format(num)
    except (ValueError, TypeError):
        return value

@app.template_filter('time_ago')
def time_ago_filter(value):
    """Converts an ISO timestamp to a relative time string (e.g., '2 hours ago')."""
    if not value:
        return "Unknown"
    try:
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=EAT)
        
        now = datetime.now(timezone.utc)
        diff = now - dt
        
        if diff.total_seconds() < 60:
            return "Active just now"
        elif diff.total_seconds() < 3600:
            minutes = int(diff.total_seconds() / 60)
            return f"Active {minutes}m ago"
        elif diff.total_seconds() < 86400:
            hours = int(diff.total_seconds() / 3600)
            return f"Active {hours}h ago"
        else:
            days = int(diff.total_seconds() / 86400)
            return f"Active {days}d ago"
    except Exception:
        return "Unknown"

@app.context_processor
def inject_system_settings():
    """Injects system-wide settings like Party Mode into all HTML templates."""
    try:
        # We fetch from Firebase once per page load to keep things real-time
        system_settings = db.reference('system_settings').get() or {}
        return {
            'force_party': system_settings.get('force_party', False),
            'promo_active': system_settings.get('new_user_promo', False)
        }
    except Exception as e:
        print(f"⚠️ Context Processor Error: {e}")
        return {'force_party': False, 'promo_active': False}

@app.before_request
def security_and_tracking_hook():
    """Enforces bans, maintenance mode, and tracks last seen."""
    # 1. MAINTENANCE MODE CHECK
    # We skip this for static files and admin routes so we don't lock ourselves out
    if request.endpoint and 'static' not in request.endpoint and 'super_admin' not in request.endpoint and 'admin_action' not in request.endpoint:
        try:
            system_settings = db.reference('system_settings').get() or {}
            if system_settings.get('maintenance_mode') and not session.get('is_super_admin'):
                return render_template('404.html', 
                    code="503",
                    message="🚧 SYSTEM MAINTENANCE: We are currently performing critical updates. We'll be back shortly!",
                    title="Under Maintenance"
                ), 503
        except Exception as e:
            logger.error(f"Maintenance check failed: {e}")

    # 2. BAN CHECK & LAST SEEN TRACKING
    user_id = session.get('user_id')
    if user_id and session.get('role') != 'business':
        try:
            # Fetch profile for ban status
            profile = db.reference(f'profiles/{user_id}').get()
            
            if profile and profile.get('is_banned'):
                session.clear()
                flash("Your account has been suspended for violating community guidelines.", "error")
                return redirect(url_for('auth.login'))

            # Update last_seen (every 5 mins)
            last_update = session.get('last_seen_update')
            now = time.time()
            if not last_update or now - last_update > 300:
                db.reference(f'profiles/{user_id}').update({
                    'last_seen': datetime.now(EAT).isoformat(),
                    'is_online': True
                })
                session['last_seen_update'] = now
        except Exception as e:
            logger.error(f"Security hook error: {e}")

# Register Blueprints
from app.routes.auth import auth_bp
from app.routes.v2.auth import auth_v2_bp
from app.routes.v3.auth import auth_v3_bp      # v3: no reg number
from app.routes.profiles import profiles_bp
from app.routes.matches import matches_bp
from app.routes.v3.matching import v3_matching_bp
from app.routes.gamification import gamification_v4_bp
from app.routes.events import events_bp
from app.routes.awards import awards_bp

app.register_blueprint(auth_bp)
app.register_blueprint(auth_v2_bp)
app.register_blueprint(auth_v3_bp)
app.register_blueprint(profiles_bp)
app.register_blueprint(matches_bp)
csrf.exempt(matches_bp)
app.register_blueprint(v3_matching_bp)
app.register_blueprint(gamification_v4_bp)
app.register_blueprint(events_bp)
csrf.exempt(events_bp)
app.register_blueprint(awards_bp, url_prefix='/awards')
csrf.exempt(awards_bp)

@app.route('/awards', methods=['GET'])
@app.route('/awards/', methods=['GET'])
def awards_root():
    from app.routes.awards import awards_index
    return awards_index()

# ==========================================
# 5. SECURITY DECORATORS & HELPERS
# ==========================================

_PLACEHOLDER_IMAGES = {
    "https://via.placeholder.com/400",
    "https://placehold.co/400",
    "",
}

def is_profile_complete(user_data: dict) -> bool:
    """Returns True only when the user has both a real photo and a phone number."""
    img   = user_data.get('img', '')
    phone = user_data.get('phone', '')
    img_ok   = bool(img) and img not in _PLACEHOLDER_IMAGES
    phone_ok = bool(phone) and len(str(phone)) >= 9
    return img_ok and phone_ok


def profile_complete_required(f):
    """
    Decorator: After login_required, also checks that the user has a profile
    photo and phone number. Redirects to /complete-profile if not.
    Re-checks every 6 hours via a session timestamp to avoid a DB call on
    every single page load.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in or sign up to access this page.", "warning")
            return redirect(url_for('auth.login', next=request.path))

        # Sponsors have VIP non-student status, bypass student profile completeness
        if session.get('account_type') == 'sponsor':
            return f(*args, **kwargs)

        # Skip re-check if we already confirmed completeness recently
        last_check = session.get('profile_checked_at')
        if last_check:
            try:
                last_dt = datetime.fromisoformat(last_check)
                if datetime.now(EAT) - last_dt < timedelta(hours=6):
                    return f(*args, **kwargs)
            except Exception:
                pass

        user_id = session.get('user_id')
        try:
            user_data = db.reference(f'profiles/{user_id}').get() or {}
            if not is_profile_complete(user_data):
                return redirect(url_for('complete_profile'))
            # Cache the check result in session
            session['profile_checked_at'] = datetime.now(EAT).isoformat()
        except Exception as e:
            logger.warning(f"Profile completion check failed: {e}")

        return f(*args, **kwargs)
    return decorated_function


def login_required(f):
    """Decorator: Ensures a user is logged in before accessing a route."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in or sign up to access this page.", "warning")
            return redirect(url_for('auth.login', next=request.path))
        return f(*args, **kwargs)
    return decorated_function


@app.route('/complete-profile')
def complete_profile():
    """Renders the profile completion wizard for users missing image or phone."""
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    user_id   = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    img   = user_data.get('img', '')
    phone = user_data.get('phone', '')
    img_ok   = bool(img) and img not in _PLACEHOLDER_IMAGES
    phone_ok = bool(phone) and len(str(phone)) >= 9
    # If already complete, just go to dashboard
    if img_ok and phone_ok:
        session['profile_checked_at'] = datetime.now(EAT).isoformat()
        return redirect(url_for('swipe'))
    return render_template('complete_profile.html',
                           user=user_data,
                           has_image=img_ok,
                           has_phone=phone_ok)


@app.route('/api/profile/update-photo', methods=['POST'])
def api_update_profile_photo():
    """
    Wizard Step 1: Accepts a multipart photo upload and saves it to Firebase Storage.
    Used by the profile completion wizard (complete_profile.html).
    """
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"status": "error", "message": "Not authenticated."}), 401

    photo = request.files.get('photo')
    if not photo or not photo.filename:
        return jsonify({"status": "error", "message": "No photo file received."}), 400

    # Validate file type
    allowed = {'.jpg', '.jpeg', '.png', '.webp', '.gif'}
    ext = os.path.splitext(photo.filename)[1].lower()
    if ext not in allowed:
        return jsonify({"status": "error", "message": "Only JPG, PNG, WEBP or GIF images are allowed."}), 400

    try:
        bucket   = storage.bucket()
        filename = f"profile_{int(time.time())}{ext}"
        blob     = bucket.blob(f"profiles/{user_id}/{filename}")
        blob.upload_from_file(photo, content_type=photo.content_type)
        blob.make_public()
        image_url = blob.public_url

        db.reference(f'profiles/{user_id}').update({
            'img':              image_url,
            'profile_complete': False,   # Will be re-evaluated after phone step
        })

        # Bust the profile-check session cache so the guard re-evaluates
        session.pop('profile_checked_at', None)
        session['user_img'] = image_url

        return jsonify({
            "status":    "success",
            "message":   "Profile photo updated successfully!",
            "image_url": image_url,
        }), 200

    except Exception as e:
        logger.error(f"Wizard photo upload error for {user_id}: {e}")
        return jsonify({"status": "error", "message": "Upload failed. Please try again."}), 500


@app.route('/api/profile/update-phone', methods=['POST'])
def api_update_profile_phone():
    """
    Wizard Step 2: Saves the user's phone number and marks the profile as complete
    if a photo is also present. Used by the profile completion wizard.
    """
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"status": "error", "message": "Not authenticated."}), 401

    data  = request.get_json(silent=True) or {}
    phone = str(data.get('phone', '')).strip().replace('+', '').replace(' ', '')

    # Normalise: 07XXXXXXXX → 2547XXXXXXXX
    if phone.startswith('0') and len(phone) == 10:
        phone = '254' + phone[1:]

    if not phone.isdigit() or len(phone) < 9:
        return jsonify({"status": "error", "message": "Please enter a valid phone number."}), 400

    try:
        user_data = db.reference(f'profiles/{user_id}').get() or {}
        img       = user_data.get('img', '')
        img_ok    = bool(img) and img not in _PLACEHOLDER_IMAGES

        db.reference(f'profiles/{user_id}').update({
            'phone':            phone,
            'profile_complete': img_ok,   # True only if photo is already set
        })

        # Bust the profile-check session cache
        session.pop('profile_checked_at', None)

        return jsonify({
            "status":  "success",
            "message": "Phone number saved successfully!",
            "profile_complete": img_ok,
        }), 200

    except Exception as e:
        logger.error(f"Wizard phone update error for {user_id}: {e}")
        return jsonify({"status": "error", "message": "Could not save phone number. Please try again."}), 500

def requires_subscription(f):
    """Decorator: Checks if a logged-in student has paid AND their subscription hasn't expired."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for('auth.login', next=request.path))
            
        user_id = session.get('user_id')

        # --- SPONSOR VIP PASS: Active sponsors have full paid access to all pages ---
        if session.get('account_type') == 'sponsor':
            from app.database import get_sponsor_profile
            sponsor = get_sponsor_profile(user_id)
            if sponsor and sponsor.get('is_active'):
                return f(*args, **kwargs)
            elif sponsor and not sponsor.get('is_active'):
                flash("Please complete your sponsor registration payment to unlock all pages.", "warning")
                return redirect(url_for('sponsors.sponsor_dashboard'))

        user_data = db.reference(f'profiles/{user_id}').get()
        
        if not user_data:
            return redirect(url_for('auth.logout'))

        is_paid = user_data.get('is_paid', False)
        expiry_str = user_data.get('subscription_expiry')
        
        has_expired = False
        if expiry_str:
            try:
                expiry_dt = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                if datetime.now(timezone.utc) > expiry_dt:
                    has_expired = True
            except: pass

        if not is_paid or has_expired:
            # If expired but still marked as paid, update DB silently
            if is_paid and has_expired:
                db.reference(f'profiles/{user_id}').update({'is_paid': False})
            
            flash("Your subscription has expired. Please renew to continue.", "warning")
            return render_template('paywall.html') 
            
        return f(*args, **kwargs)
    return decorated_function

def requires_diamond_subscription(f):
    """Decorator: Checks if a logged-in student has an active Diamond subscription."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for('auth.login'))
            
        user_id = session.get('user_id')

        # --- SPONSOR VIP PASS ---
        if session.get('account_type') == 'sponsor':
            from app.database import get_sponsor_profile
            sponsor = get_sponsor_profile(user_id)
            if sponsor and sponsor.get('is_active'):
                return f(*args, **kwargs)

        user_data = db.reference(f'profiles/{user_id}').get()
        
        if not user_data:
            return redirect(url_for('auth.logout'))

        is_paid = user_data.get('is_paid', False)
        package = user_data.get('subscription_package', 'gold')
        expiry_str = user_data.get('subscription_expiry')
        
        has_expired = False
        if expiry_str:
            try:
                expiry_dt = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                if datetime.now(timezone.utc) > expiry_dt:
                    has_expired = True
            except: pass

        if not is_paid or has_expired:
            if is_paid and has_expired:
                db.reference(f'profiles/{user_id}').update({'is_paid': False})
            
            flash("Your subscription has expired. Please renew to continue.", "warning")
            return render_template('paywall.html') 

        # Diamond lockout removed: All Premium users have access.
            
        return f(*args, **kwargs)
    return decorated_function

def trigger_match_notification(target_user_id, current_user_name):
    """Sends a Web Push Notification to the target user when a match occurs via FCM."""
    success = send_push_notification(
        receiver_id=target_user_id,
        title="It's a Match! 🔥",
        body=f"You and {current_user_name} liked each other. Tap to say hi!",
        click_url="/matches"
    )
    if success:
        print(f" Push notification instantly sent to {target_user_id}!")
    else:
        print(f" Push failed or token not found for {target_user_id}.")

# Note: Your Flask routes (@app.route) would continue below this if they are in main.py          
def get_current_party_theme():
    """Returns the themed night based on the day of the week."""
    now = datetime.now(EAT)
    day = now.strftime('%A')
    
    themes = {
        'Monday': {'title': 'Motivation Mixer', 'icon': '🎯', 'desc': 'Start your week with high-value connections.'},
        'Tuesday': {'title': 'Tech & Trivia Night', 'icon': '🧬', 'desc': 'Nerdy is the new sexy. Geeks unite!'},
        'Wednesday': {'title': 'Wednesday Wildcard', 'icon': '🃏', 'desc': 'Expect the unexpected. Anything goes!'},
        'Thursday': {'title': 'Throwback Thursday', 'icon': '📼', 'desc': 'Old school vibes and timeless matches.'},
        'Friday': {'title': "Freshers' Friday", 'icon': '🎓', 'desc': 'Welcome to the party. The ultimate mixer.'},
        'Saturday': {'title': 'Saturday Soiree', 'icon': '💃', 'desc': 'The peak of campus nightlife, virtually.'},
        'Sunday': {'title': 'Sunday Serenade', 'icon': '🎸', 'desc': 'Chill vibes and meaningful deep talks.'}
    }
    
    return themes.get(day, {'title': 'MMUST Mixer', 'icon': '✨', 'desc': 'Join the campus community live.'})

@app.route('/party')
@requires_subscription
def party():
    """Renders the Virtual Club Room and notifies online users to join."""
    global _last_party_notif_time
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    
    theme = get_current_party_theme()
    
    # Mark user as present in the party room in Firebase
    timestamp = datetime.now(EAT).isoformat()
    db.reference(f'party_participants/{user_id}').set({
        'name': user_data.get('name', 'Anonymous').split(' ')[0],
        'img': user_data.get('img', '/static/img/placeholder.png'),
        'phone': user_data.get('phone'),
        'joined_at': timestamp,
        'shape_seed': random.randint(1, 8) # Used for dynamic CSS shapes
    })
    
    # Notify online users that someone entered the virtual club (2 min cooldown)
    current_time = time.time()
    if current_time - _last_party_notif_time > 120:
        _last_party_notif_time = current_time
        first_name = (user_data.get('name') or 'A comrade').strip().split()[0]
        user_img = user_data.get('img') or '/static/img/icon-192.png'
        title = "🪩 Virtual Club is POPPING!"
        message = f"🔥 {first_name} is in the Virtual Club right now! Tap to join the vibe."
        threading.Thread(
            target=broadcast_notification_to_online,
            args=(title, message, '/party', f"{first_name} @ Club", user_img, user_id, 'party')
        ).start()
    
    return render_template('party.html', 
                           current_user=session.get('user_name'),
                           user_id=user_id,
                           theme=theme)

@app.route('/api/party/notify_online', methods=['POST'])
@requires_subscription
def api_party_notify_online():
    """Allows comrades in the club to invite online users with cooldown."""
    global _last_party_notif_time
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    first_name = (user_data.get('name') or 'A comrade').strip().split()[0]
    user_img = user_data.get('img') or '/static/img/icon-192.png'
    
    current_time = time.time()
    if current_time - _last_party_notif_time > 60:
        _last_party_notif_time = current_time
        title = "🪩 Virtual Club is POPPING!"
        message = f"🔥 {first_name} invited everyone to join the Virtual Club! Tap to vibe."
        threading.Thread(
            target=broadcast_notification_to_online,
            args=(title, message, '/party', f"{first_name} @ Club", user_img, user_id, 'party')
        ).start()
        return jsonify({'success': True, 'message': 'Invitation sent to online comrades!'})
    return jsonify({'success': False, 'message': 'An invitation was recently sent. Please wait a moment.'})


# ==========================================
# CORE B2C PAGES (STUDENTS)
# ==========================================

@app.route('/')
def home():
    # If user/sponsor is already logged in, remember them and redirect directly to their dashboard/swipe
    if 'user_id' in session:
        if session.get('account_type') == 'sponsor':
            return redirect(url_for('sponsors.sponsor_dashboard'))
        return redirect(url_for('swipe'))
    return render_template('index.html')

@app.route('/manifest.json')
def manifest():
    return send_from_directory('static', 'manifest.json')

@app.route('/sw.js')
@app.route('/firebase-messaging-sw.js')
@app.route('/push-worker.js')
def service_worker():
    response = make_response(send_from_directory('static', 'sw.js', mimetype='application/javascript'))
    response.headers['Service-Worker-Allowed'] = '/'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response

@app.route('/safety')
def safety():
    # Public route
    return render_template('safety.html', current_user=session.get('user_name'))

@app.route('/privacy')
def privacy():
    # Public route
    return render_template('privacy.html', current_user=session.get('user_name'))

@app.route('/terms')
def terms():
    # Public route
    return render_template('terms.html', current_user=session.get('user_name'))

@app.route('/venues')
@requires_subscription
def venues():
    # Only active subscribers can view venues
    active_venues = get_all_restaurants(active_only=True)
    return render_template('venues.html', current_user=session.get('user_name'), venues=active_venues)


# ==========================================
# 🧪 FIND YOUR MATCH VERSION 3 BETA LABS
# ==========================================

@app.route('/labs')
@login_required
def labs_dashboard():
    """Renders the Version 3 Labs Command Center."""
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    
    # Load zodiac, MBTI, labs preferences
    zodiac = user_data.get('zodiac', '')
    mbti = user_data.get('mbti', '')
    labs_prefs = user_data.get('labs_preferences', {})
    
    # Calculate referral counts and points
    referrals_data = db.reference(f'referrals/{user_id}').get() or {}
    referral_count = len(referrals_data) if isinstance(referrals_data, dict) else 0
    wingman_points = referral_count * 100
    wingman_ksh = referral_count * 20
    
    # Load all anonymous confessions (sorted by score / timestamp)
    confessions_dict = db.reference('confessions').get() or {}
    confessions = []
    for cid, cdata in confessions_dict.items():
        if isinstance(cdata, dict):
            cdata['id'] = cid
            confessions.append(cdata)
    
    # Sort confessions by score (highest first), then timestamp
    confessions.sort(key=lambda x: (x.get('score', 0), x.get('timestamp', '')), reverse=True)
    
    # Load Daily Spinner State
    spinner_data = db.reference(f'profiles/{user_id}/labs_spinner').get() or {}
    last_spin = spinner_data.get('last_spin')
    can_spin = True
    if last_spin:
        try:
            last_spin_dt = datetime.fromisoformat(last_spin)
            if datetime.now(timezone.utc) - last_spin_dt < timedelta(hours=24):
                can_spin = False
        except:
            pass

    return render_template(
        'labs.html',
        current_user=session.get('user_name', 'Student').split(' ')[0],
        zodiac=zodiac,
        mbti=mbti,
        labs_prefs=labs_prefs,
        referral_count=referral_count,
        wingman_points=wingman_points,
        wingman_ksh=wingman_ksh,
        confessions=confessions[:25], # top 25
        can_spin=can_spin,
        base_url=get_base_url(),
        user_id=user_id
    )

@app.route('/api/labs/confess', methods=['POST'])
@login_required
@csrf.exempt # Exempt for quick API execution
def api_labs_confess():
    """Submits a new anonymous campus confession."""
    data = request.get_json() or {}
    text = data.get('text', '').strip()
    campus = data.get('campus', 'MMUST').strip()
    
    if not text:
        return jsonify({'success': False, 'message': 'Confession cannot be empty.'}), 400
    if len(text) > 300:
        return jsonify({'success': False, 'message': 'Confession must be under 300 characters.'}), 400

    # Clean text of phone numbers for security
    if contains_phone_number(text):
        return jsonify({'success': False, 'message': 'Sharing phone numbers is strictly prohibited for security.'}), 400

    confession_payload = {
        'text': text,
        'campus': campus,
        'timestamp': datetime.now(EAT).isoformat(),
        'score': 0
    }
    
    try:
        db.reference('confessions').push(confession_payload)
        return jsonify({'success': True, 'message': 'Confession posted anonymously! 🤫'})
    except Exception as e:
        logger.error(f"Failed to post confession: {e}")
        return jsonify({'success': False, 'message': 'Failed to post secret.'}), 500

@app.route('/api/labs/vote', methods=['POST'])
@login_required
@csrf.exempt
def api_labs_vote():
    """Upvotes or downvotes an anonymous confession."""
    data = request.get_json() or {}
    cid = data.get('id')
    direction = data.get('direction') # 'up' or 'down'
    
    if not cid or direction not in ['up', 'down']:
        return jsonify({'success': False, 'message': 'Invalid parameters.'}), 400
        
    try:
        ref = db.reference(f'confessions/{cid}')
        cdata = ref.get()
        if not cdata:
            return jsonify({'success': False, 'message': 'Confession not found.'}), 404
            
        current_score = int(cdata.get('score', 0))
        new_score = current_score + (1 if direction == 'up' else -1)
        
        ref.update({'score': new_score})
        return jsonify({'success': True, 'score': new_score})
    except Exception as e:
        logger.error(f"Failed to vote: {e}")
        return jsonify({'success': False, 'message': 'Failed to cast vote.'}), 500

@app.route('/api/labs/spin', methods=['POST'])
@login_required
@csrf.exempt
def api_labs_spin():
    """Spins the daily rewards wheel."""
    user_id = session.get('user_id')
    profile_ref = db.reference(f'profiles/{user_id}')
    user_data = profile_ref.get() or {}
    
    spinner_ref = db.reference(f'profiles/{user_id}/labs_spinner')
    spinner_data = spinner_ref.get() or {}
    
    last_spin = spinner_data.get('last_spin')
    if last_spin:
        try:
            last_spin_dt = datetime.fromisoformat(last_spin.replace('Z', '+00:00'))
            if datetime.now(timezone.utc) - last_spin_dt < timedelta(hours=24):
                return jsonify({'success': False, 'message': 'You have already spun the wheel today. Check back tomorrow!'}), 400
        except: pass
        
    rewards = [
        'Algorithmic Profile Boost 🔥',
        'Free Super Vibe ⚡',
        'Astrology Synergy Unlock 🔮',
        'B2B Cafe 20% Discount Voucher 🎟️',
        'Double Swipe Matches 🃏',
        'Secret Crush Radar Reveal 🎯'
    ]
    prize = random.choice(rewards)
    
    try:
        # Record spin state and award prize
        spinner_ref.set({
            'last_spin': datetime.now(timezone.utc).isoformat(),
            'last_prize': prize
        })
        
        # Award reward in profile fields dynamically
        if 'Boost' in prize:
            profile_ref.update({'ai_score_bonus': 15})
        elif 'Super Vibe' in prize:
            profile_ref.update({'super_vibes': int(user_data.get('super_vibes', 0)) + 3})
            
        return jsonify({'success': True, 'prize': prize, 'message': f'Congratulations! You won: {prize}'})
    except Exception as e:
        logger.error(f"Failed to spin wheel: {e}")
        return jsonify({'success': False, 'message': 'Failed to execute spin.'}), 500

@app.route('/api/labs/toggle', methods=['POST'])
@login_required
@csrf.exempt
def api_labs_toggle():
    """Toggles user beta preferences in Firebase."""
    user_id = session.get('user_id')
    data = request.get_json() or {}
    feature = data.get('feature')
    state = data.get('state') # True or False
    
    if not feature or state is None:
        return jsonify({'success': False, 'message': 'Invalid toggle data.'}), 400
        
    try:
        db.reference(f'profiles/{user_id}/labs_preferences').update({
            feature: bool(state)
        })
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Failed to toggle beta preference: {e}")
        return jsonify({'success': False, 'message': 'Failed to save choice.'}), 500

@app.route('/api/labs/profile_traits', methods=['POST'])
@login_required
@csrf.exempt
def api_labs_profile_traits():
    """Syncs MBTI & Zodiac signs directly in the user profile."""
    user_id = session.get('user_id')
    data = request.get_json() or {}
    zodiac = data.get('zodiac', '').strip()
    mbti = data.get('mbti', '').strip()
    
    try:
        db.reference(f'profiles/{user_id}').update({
            'zodiac': zodiac,
            'mbti': mbti
        })
        return jsonify({'success': True, 'message': 'Astrology & Personality profile saved!'})
    except Exception as e:
        logger.error(f"Failed to save traits: {e}")
        return jsonify({'success': False, 'message': 'Failed to save traits.'}), 500

from flask import render_template, session, redirect, url_for, flash
from flask import session, flash, redirect, url_for, render_template
# Make sure your db is imported! e.g., from app.database import db

def is_opposite_gender_match(my_gender, target_gender):
    """
    Enforces strict opposite-gender matching:
    - Ladies only see male profiles
    - Males only see female profiles
    """
    g1 = (my_gender or '').strip().lower()
    g2 = (target_gender or '').strip().lower()
    
    male_aliases = {'male', 'man', 'm', 'boy'}
    female_aliases = {'female', 'woman', 'f', 'lady', 'girl'}
    
    if g1 in male_aliases:
        return g2 in female_aliases
    elif g1 in female_aliases:
        return g2 in male_aliases
    elif g1 and g2:
        return g1 != g2
    return True


@app.route('/swipe')
@requires_subscription
def swipe():
    """
    Renders the main Tinder-style discovery deck.
    Requires the user to be authenticated and have an active premium subscription.
    """
    user_id = session.get('user_id')
    
    # 1. Fallback Validation (Safety Net)
    if not user_id:
        flash("Your session expired. Please log in again.", "warning")
        return redirect(url_for('auth.login')) 

    # 2. Fetch Current User Data & Swipes
    if session.get('account_type') == 'sponsor':
        from app.database import get_sponsor_profile
        user_profile = get_sponsor_profile(user_id) or {}
    else:
        user_profile = db.reference(f'profiles/{user_id}').get() or {}
    user_swipes = db.reference(f'swipes/{user_id}').get() or {}

    # Extract Current User's Gender for strict filtering
    current_user_gender = user_profile.get('gender', '').strip().lower()

    # --- THE ALGORITHM DATA FETCH ---
    # Fetch people who have a pending Secret Crush on THIS user
    crushes_on_me = db.reference(f'secret_crushes/{user_id}').get() or {}
    pending_crushers = [sender_id for sender_id, data in crushes_on_me.items() if data.get('status') == 'pending']

    # Fetch User Preferences
    user_settings = user_profile.get('settings', {})
    gender_pref = user_settings.get('looking_for', 'Everyone')
    my_intent = user_profile.get('intent', 'none')
    
    # Prepare for Bio matching
    my_bio_words = set(user_profile.get('bio', '').lower().replace('.', '').replace(',', '').split())
    stop_words = {'i', 'am', 'a', 'the', 'and', 'to', 'for', 'in', 'of', 'my', 'is', 'at', 'on', 'with', 'student', 'mmust'}
    my_keywords = my_bio_words - stop_words

    # 3. Bundle Context for the Frontend
    current_user = {
        'id': user_id,
        'name': user_profile.get('name', session.get('user_name', 'Student')).split(' ')[0], 
        'img': user_profile.get('img') or url_for('static', filename='img/placeholder.png'),
        'settings': user_settings,
        'zodiac': user_profile.get('zodiac', ''),
        'mbti': user_profile.get('mbti', '')
    }

    # 4. Build the Discovery Deck and the Teaser Deck (for empty state)
    potential_matches = []
    top_teasers = []
    all_profiles = get_all_profiles() # Fetch everyone
    
    for p in all_profiles:
        p_id = p.get('id')
        p_gender = p.get('gender', '').strip().lower()
        
        # --- STRICT OPPOSITE-GENDER RULE ---
        if not is_opposite_gender_match(current_user_gender, p_gender):
            continue
        
        # SKIP CONDITIONS:
        # - Don't show the user themselves
        # - Don't show profiles that are hidden
        # - Don't show people the user has already swiped on (liked/passed)
        if p_id == user_id or not p.get('is_visible', True) or p_id in user_swipes:
            continue
            
        # GENDER PREFERENCE FILTER (If they specifically selected Male or Female)
        if gender_pref != 'Everyone':
            if p_gender != gender_pref.lower():
                continue
                
        # AGE FILTER
        p_age = int(p.get('age', 18) or 18)
        age_min = user_settings.get('age_min', 18)
        age_max = user_settings.get('age_max', 99)
        if p_age < age_min or p_age > age_max:
            continue
            
        # MAJOR FILTER
        major_filter = user_settings.get('major_filter', 'All')
        if major_filter != 'All':
            p_major = p.get('major', '').lower()
            if major_filter == 'CS_IT' and not any(kw in p_major for kw in ['comput', 'it', 'soft', 'info']):
                continue
            elif major_filter == 'Health' and not any(kw in p_major for kw in ['nurs', 'med', 'health', 'clinic']):
                continue
            elif major_filter == 'Engineering' and 'engin' not in p_major:
                continue
            elif major_filter == 'Business' and not any(kw in p_major for kw in ['busin', 'econ', 'financ', 'account']):
                continue
            elif major_filter == 'Education' and not any(kw in p_major for kw in ['edu', 'teach', 'art']):
                continue
            elif major_filter == 'Agriculture' and not any(kw in p_major for kw in ['agri', 'bio']):
                continue
                
        # --- THE SCORING ALGORITHM ---
        base_score = p.get('ai_score', random.randint(65, 80))
        bonus = 0
        
        # Intent Bonus
        p_intent = p.get('intent', 'none')
        if my_intent != 'none' and p_intent == my_intent:
            bonus += 10
            
        # Bio Overlap Bonus
        p_bio_words = set(p.get('bio', '').lower().replace('.', '').replace(',', '').split())
        common_words = (p_bio_words - stop_words) & my_keywords
        if len(common_words) > 0:
            bonus += 5
            
        final_score = min(base_score + bonus, 99)
        
        # DIAMOND PACKAGE EXPOSURE BOOST (Increases visibility in other users' decks by 3x!)
        if p.get('subscription_package') == 'diamond':
            final_score += 20
            final_score = min(final_score, 99)
        
        # ACTIVE BOOST (Feature #18)
        boost_expiry_str = p.get('boost_expiry')
        if boost_expiry_str:
            try:
                boost_expiry = datetime.fromisoformat(boost_expiry_str.replace('Z', '+00:00'))
                if datetime.now(timezone.utc) < boost_expiry:
                    final_score = 140 # Float just under Secret Crush (150)
            except: pass
        
        # SECRET CRUSH OVERRIDE (Forces them to the absolute front of the line)
        if p_id in pending_crushers:
            final_score = 150 
            
        # FEATURE 5: Mutual Connections
        connections = []
        if p.get('major') and user_profile.get('major') and p.get('major').strip() == user_profile.get('major').strip():
            connections.append('📚 Same Course')
        if p_intent != 'none' and p_intent == my_intent:
            connections.append('🎯 Same Goal')
        if common_words:
            connections.append(f'🗣️ "{list(common_words)[0]}"')
            
        connection_msg = " • ".join(connections[:2]) if connections else ""
        
        potential_matches.append({
            'id': p_id,
            'name': p.get('name', 'Student').split(' ')[0],
            'age': p.get('age', 18),
            'major': p.get('major', 'MMUST Student'),
            'bio': p.get('bio', 'Hey! I am using FIND YOUR MATCH.'),
            'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
            'phone': p.get('phone'), # Direct access for professional profile contact
            'intent': p_intent, # Passes the intent so the frontend tag works!
            'tribe': p.get('tribe', ''),
            'zodiac': p.get('zodiac', ''),
            'mbti': p.get('mbti', ''),
            'compatibility': final_score,
            'is_perfect_match': final_score >= 80,  # Flag for the frontend badge
            'connection_msg': connection_msg
        })

    # 4.5 Build the Teaser Deck for Empty State (Top Opposite Gender)
    for p in all_profiles:
        p_id = p.get('id')
        if p_id == user_id or not p.get('is_visible', True):
            continue
            
        if not is_opposite_gender_match(current_user_gender, p_gender):
            continue
            
        if gender_pref != 'Everyone' and p_gender != gender_pref.lower():
            continue
            
        ai_score = p.get('ai_score', random.randint(65, 80))
        if ai_score >= 80:
            top_teasers.append({
                'id': p_id,
                'name': p.get('name', 'Student').split(' ')[0],
                'bio': p.get('bio', 'Looking for a compatibility match.'),
                'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
                'compatibility': ai_score,
                'is_perfect_match': True
            })
            
    # Sort teasers by score and grab top 10
    top_teasers.sort(key=lambda x: x['compatibility'], reverse=True)
    top_teasers = top_teasers[:10]

    # 5. Backfill safety net: Ensure the deck is NEVER empty so swipe works instantly!
    if len(potential_matches) < 10 and all_profiles:
        seen_ids = set(m['id'] for m in potential_matches)
        for p in all_profiles:
            p_id = p.get('id')
            if p_id == user_id or p_id in seen_ids or not p.get('is_visible', True):
                continue
            p_gender = p.get('gender', '').strip().lower()
            if not is_opposite_gender_match(current_user_gender, p_gender):
                continue
            
            # Don't re-show profiles the user previously liked
            user_swipe = user_swipes.get(p_id)
            if (isinstance(user_swipe, dict) and user_swipe.get('action') == 'like') or user_swipe == 'like':
                continue
                
            p_intent = p.get('intent', 'none')
            score = p.get('ai_score', random.randint(70, 88))
            potential_matches.append({
                'id': p_id,
                'name': p.get('name', 'Student').split(' ')[0],
                'age': p.get('age', 18),
                'major': p.get('major', 'MMUST Student'),
                'bio': p.get('bio', 'Hey! I am using FIND YOUR MATCH.'),
                'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
                'phone': p.get('phone'),
                'intent': p_intent,
                'tribe': p.get('tribe', ''),
                'zodiac': p.get('zodiac', ''),
                'mbti': p.get('mbti', ''),
                'compatibility': score,
                'is_perfect_match': score >= 80,
                'connection_msg': '✨ Recommended Match'
            })
            seen_ids.add(p_id)
            if len(potential_matches) >= 15:
                break

    # 6. Sort the deck: Show the Highest Compatibility matches first!
    random.shuffle(potential_matches)
    potential_matches = potential_matches[:10]
    potential_matches.sort(key=lambda x: x['compatibility'], reverse=True)


    return render_template(
        'swipe.html', 
        current_user=current_user,
        potential_matches=potential_matches,
        top_teasers=top_teasers,
        profile_complete=is_profile_complete(user_profile)
    )

@app.route('/notifications')
@requires_subscription # Or @login_required depending on your setup
def setup_notifications():
    """Renders the dedicated Push Notification onboarding page."""
    return render_template('notifications.html', current_user=session.get('user_name', 'Student').split(' ')[0])

# ==========================================
# SURVEY & FEEDBACK CAMPAIGN
# ==========================================
@app.route('/survey', methods=['GET'])
@login_required
def survey_page():
    """Renders the user feedback survey."""
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    
    # If they already completed it, don't let them do it again
    if user_data.get('survey_completed'):
        flash("You have already completed the survey and claimed your reward! Thank you!", "success")
        return redirect(url_for('dashboard'))
        
    return render_template('survey.html')

@app.route('/api/survey/submit', methods=['POST'])
@login_required
def submit_survey():
    """Processes survey feedback and applies the 1 week premium reward."""
    user_id = session.get('user_id')
    user_ref = db.reference(f'profiles/{user_id}')
    user_data = user_ref.get() or {}
    
    if user_data.get('survey_completed'):
        return jsonify({"success": False, "message": "You have already claimed this reward."}), 400
        
    data = request.get_json()
    if not data:
        return jsonify({"success": False, "message": "Invalid data submitted."}), 400
        
    # Save survey results to a separate node
    survey_ref = db.reference('survey_responses').push()
    survey_ref.set({
        'user_id': user_id,
        'name': user_data.get('name', 'Unknown'),
        'gender': user_data.get('gender', 'Unknown'),
        'reg_no': user_data.get('reg_no', 'Unknown'),
        'institution': user_data.get('institution', 'Unknown'),
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'responses': data
    })
    
    # --- Apply Premium Reward ---
    is_paid = user_data.get('is_paid', False)
    expiry_str = user_data.get('subscription_expiry', '')
    
    current_expiry = datetime.now(timezone.utc)
    has_expired = False
    
    if expiry_str:
        try:
            current_expiry = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
            if datetime.now(timezone.utc) > current_expiry:
                has_expired = True
        except:
            pass
            
    # If they are currently active, extend their existing expiry by 7 days.
    # If they are expired or never paid, give them 7 days from right now.
    if is_paid and not has_expired:
        new_expiry = current_expiry + timedelta(days=7)
    else:
        new_expiry = datetime.now(timezone.utc) + timedelta(days=7)
        
    user_ref.update({
        'survey_completed': True,
        'is_paid': True,
        'subscription_expiry': new_expiry.isoformat()
    })
    
    # Update session
    session['is_paid'] = True
    session.modified = True
    
    return jsonify({"success": True, "message": "Reward claimed successfully!"}), 200


import random
@app.route('/dashboard')
@login_required # Allow entry to dashboard even if unpaid, but we will lock it in the template
def dashboard():
    """THE MAIN STUDENT COMMAND CENTER (OPEN DIRECTORY MODE)"""
    user_id = session.get('user_id')
    if session.get('account_type') == 'sponsor':
        return redirect(url_for('sponsors.sponsor_dashboard'))
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    ai_mode = user_data.get('settings', {}).get('ai_companion_mode') == True
    
    # --- Check Subscription Status ---
    is_paid = user_data.get('is_paid', False)
    expiry_str = user_data.get('subscription_expiry', '')
    
    has_expired = False
    if expiry_str:
        try:
            expiry_dt = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
            if datetime.now(timezone.utc) > expiry_dt:
                has_expired = True
        except: pass

    subscription_active = is_paid and not has_expired
    
    # If expired but still marked as paid, update DB silently
    if is_paid and has_expired:
        db.reference(f'profiles/{user_id}').update({'is_paid': False})
        subscription_active = False
    
    # Extract Current User's Gender for matching logic
    current_user_gender = user_data.get('gender', '').strip().lower()
    
    my_matches = []
    
    # 1. BLAZING FAST FETCH: Fetch real matches instead of random profiles
    all_profiles_dict = db.reference('profiles').get() or {}
    all_matches = db.reference('matches').get() or {}
    
    # We will still keep the AI companion
    if ai_mode:
        my_matches.append({
            'id': 'AI_COMPANION',
            'name': 'AI Wingman 🤖',
            'bio': 'Your personal AI wingman. Ready to chat!',
            'img': 'https://api.dicebear.com/7.x/bottts/svg?seed=wingman&backgroundColor=e60026',
            'compatibility': 100,
            'is_perfect_match': True
        })
        
    for match_id, match_data in all_matches.items():
        if not isinstance(match_data, dict):
            continue
            
        users = match_data.get('users', {})
        if user_id in users:
            # Find the other person
            partner_id = [uid for uid in users.keys() if uid != user_id]
            if partner_id:
                partner_id = partner_id[0]
                p = all_profiles_dict.get(partner_id, {})
                
                if not p:
                    continue

                # --- OPPOSITE GENDER FILTER ---
                # Only show partners of the opposite gender on the dashboard.
                # If gender info is missing on either side, we still include the match.
                partner_gender = p.get('gender', '').strip().lower()
                if current_user_gender and partner_gender and current_user_gender == partner_gender:
                    continue  # Skip same-gender matches
                    
                compat_score = p.get('compatibility')
                if compat_score is None:
                    raw_score = p.get('ai_score', 85)
                    compat_score = raw_score if raw_score <= 100 else int(60 + min(raw_score / 300.0 * 39, 39))

                my_matches.append({
                    'id': partner_id,
                    'name': p.get('name', 'Student').split(' ')[0], 
                    'bio': p.get('bio', 'Hey there!'),
                    'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
                    'compatibility': compat_score,
                    'is_perfect_match': True, # They are an actual match
                    'last_seen': p.get('last_seen', '')
                })

    # 4. FETCH DATE BOOKINGS (Single network call)
    all_bookings = db.reference('bookings').get() or {}
    all_restaurants = db.reference('restaurants').get() or {}
    
    pending_dates_count = 0
    upcoming_dates = []

    for b_id, b_data in all_bookings.items():
        if not isinstance(b_data, dict): 
            continue
        
        if b_data.get('user_a_id') == user_id or b_data.get('user_b_id') == user_id:
            status = b_data.get('status')
            
            if status == 'Pending':
                pending_dates_count += 1
            elif status == 'Approved':
                partner_id = b_data.get('user_b_id') if b_data.get('user_a_id') == user_id else b_data.get('user_a_id')
                partner_profile = all_profiles_dict.get(partner_id, {})
                
                venue_id = b_data.get('venue_id')
                venue_data = all_restaurants.get(venue_id, {})
                
                upcoming_dates.append({
                    'partner_name': partner_profile.get('name', 'Your Date').split(' ')[0],
                    'partner_img': partner_profile.get('img') or '/static/img/placeholder.png',
                    'restaurant_name': venue_data.get('business_name', 'Unknown Venue'),
                    'location': venue_data.get('location', 'Kakamega CBD'),
                    'day': b_data.get('day', 'TBD'),
                    'time': b_data.get('time', 'TBD'),
                    'perk': venue_data.get('conditions', '')
                })

    # --- NEW: FETCH TODAY'S PROMPT & MY ANSWER ---
    today_str = datetime.now(EAT).strftime('%Y-%m-%d')
    prompt_data = get_todays_prompt()
    my_answer_data = db.reference(f'prompt_answers/{today_str}/{user_id}').get()
    
    # --- NEW: CALCULATE BADGES FOR SELF ---
    badges = calculate_profile_badges(user_data)

    # 5. Get unread notification count
    unread_ref = db.reference(f'notifications/{user_id}').order_by_child('status').equal_to('unread').get()
    unread_count = len(unread_ref) if unread_ref else 0

    # FEATURE 2: Second Chance Queue
    second_chances = []
    my_swipes = db.reference(f'swipes/{user_id}').get() or {}
    passed_ids = [target_id for target_id, data in my_swipes.items() if data.get('action') == 'pass']
    
    if passed_ids:
        all_swipes = db.reference('swipes').get() or {}
        for pid in passed_ids:
            if all_swipes.get(pid, {}).get(user_id, {}).get('action') == 'like':
                p = all_profiles_dict.get(pid, {})
                if p:
                    compat_score = p.get('compatibility')
                    if compat_score is None:
                        raw_score = p.get('ai_score', 85)
                        compat_score = raw_score if raw_score <= 100 else int(60 + min(raw_score / 300.0 * 39, 39))

                    second_chances.append({
                        'id': pid,
                        'name': p.get('name', 'Student').split(' ')[0], 
                        'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
                        'compatibility': compat_score
                    })

    # FEATURE 4: Fresh Faces Daily Reveal
    daily_picks = []
    if all_profiles_dict:
        import random
        # Find people not swiped yet, opposite gender
        potential_picks = []
        for pid, p in all_profiles_dict.items():
            if pid != user_id and pid not in users and pid not in my_swipes:
                p_gender = p.get('gender', '').strip().lower()
                if current_user_gender and p_gender and current_user_gender != p_gender:
                    potential_picks.append((pid, p))
                elif not current_user_gender or not p_gender:
                    potential_picks.append((pid, p))
                    
        # Sort by compatibility
        potential_picks.sort(key=lambda x: x[1].get('compatibility', x[1].get('ai_score', 0)), reverse=True)
        # Take top 10, pick 3 random
        top_picks = potential_picks[:10]
        if top_picks:
            chosen = random.sample(top_picks, min(3, len(top_picks)))
            for pid, p in chosen:
                daily_picks.append({
                    'id': pid,
                    'name': p.get('name', 'Student').split(' ')[0], 
                    'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
                    'compatibility': p.get('compatibility', 85)
                })

    # 6. Fetch NGL Viral Link & Inbox summary for Dashboard
    try:
        from app.services.ngl_service import get_or_create_user_link, get_user_inbox
        ngl_info = get_or_create_user_link(user_id) or {}
        ngl_inbox = get_user_inbox(user_id) or []
        ngl_slug = ngl_info.get('slug') or 'student'
        ngl_full_link = url_for('ngl_public_page', slug=ngl_slug, _external=True)
        ngl_unread_count = sum(1 for m in ngl_inbox if not m.get('is_read'))
        ngl_recent_messages = ngl_inbox[:3]
    except Exception as ngl_err:
        logger.error(f"Error loading NGL dashboard data: {ngl_err}")
        ngl_info = {}
        ngl_inbox = []
        ngl_full_link = ""
        ngl_unread_count = 0
        ngl_recent_messages = []

    return render_template(
        'dashboard.html', 
        current_user=session.get('user_name', 'Student').split(' ')[0], 
        matches=my_matches,
        second_chances=second_chances,
        daily_picks=daily_picks,
        pending_dates_count=pending_dates_count,
        upcoming_dates=upcoming_dates,
        subscription_active=subscription_active,
        subscription_package=user_data.get('subscription_package', 'gold'),
        unread_count=unread_count,
        daily_prompt=prompt_data,
        my_answer=my_answer_data,
        badges=badges,
        profile_complete=is_profile_complete(user_data),
        ngl_info=ngl_info,
        ngl_full_link=ngl_full_link,
        ngl_unread_count=ngl_unread_count,
        ngl_inbox=ngl_inbox,
        ngl_recent_messages=ngl_recent_messages
    )
    
@app.route('/api/boost', methods=['POST'])
@login_required
@csrf.exempt
def activate_boost():
    user_id = session.get('user_id')
    user_ref = db.reference(f'profiles/{user_id}')
    
    # Calculate expiry: 1 hour from now
    expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    
    user_ref.update({
        'boost_expiry': expiry
    })
    
    return jsonify({"status": "success", "message": "Boost activated! You will be shown to more people for 1 hour."})

@app.route('/api/check_milestone')
@login_required
def check_milestone():
    user_id = session.get('user_id')
    user_ref = db.reference(f'profiles/{user_id}')
    user_data = user_ref.get() or {}
    
    # Feature 19: Milestone Celebrations
    # To trigger a milestone, we can check if they have any dates approved
    # Or just fake it once if they have a match to show off the gamification
    has_seen_milestone = user_data.get('has_seen_milestone', False)
    
    if not has_seen_milestone:
        # Find any match to trigger the celebration
        my_matches = []
        all_swipes = db.reference('swipes').get() or {}
        my_swipes = all_swipes.get(user_id, {})
        for p_id, direction in my_swipes.items():
            if direction == 'like':
                if all_swipes.get(p_id, {}).get(user_id) == 'like':
                    my_matches.append(p_id)
        
        if my_matches:
            partner_id = my_matches[0]
            partner_name = db.reference(f'profiles/{partner_id}/name').get() or 'Your Match'
            partner_name = partner_name.split(' ')[0]
            
            # Mark as seen so it doesn't spam them
            user_ref.update({'has_seen_milestone': True})
            
            return jsonify({
                "show_modal": True,
                "partner_name": partner_name
            })
            
    return jsonify({"show_modal": False})
    
@app.route('/api/unmatch', methods=['POST'])
@login_required
@csrf.exempt
def unmatch_user():
    data = request.json
    user_id = session.get('user_id')
    target_id = data.get('target_id')
    reason = data.get('reason') # Optional report reason

    if not target_id:
        return jsonify({"status": "error", "message": "Missing target user"}), 400

    try:
        # 1. Generate the unique match ID
        match_id = "_".join(sorted([user_id, target_id]))
        
        # 2. Delete the mutual match
        db.reference(f'matches/{match_id}').delete()

        # 3. Delete the chat history (Optional, but good for privacy)
        db.reference(f'chats/{match_id}').delete()

        # 4. Overwrite their previous swipes so they don't show up in the deck again
        timestamp = datetime.now(EAT).isoformat()
        db.reference(f'swipes/{user_id}/{target_id}').set({'action': 'unmatched', 'timestamp': timestamp})
        db.reference(f'swipes/{target_id}/{user_id}').set({'action': 'unmatched', 'timestamp': timestamp})

        # 5. If they provided a reason, log it to the Admin Reports node
        if reason:
            db.reference('reports').push({
                'reporter_id': user_id,
                'reported_id': target_id,
                'reason': reason,
                'timestamp': timestamp,
                'status': 'pending_review'
            })

        return jsonify({"status": "success"})
        
    except Exception as e:
        logger.error(f"Unmatch Error: {e}")
        return jsonify({"status": "error", "message": "Database error"}), 500
    
    
    
import hashlib
import os

def hash_reg_number(reg_num):
    """
    Standardizes the reg number (removes spaces, makes uppercase)
    and returns an unbreakable SHA-256 hash.
    """
    if not reg_num: return None
    clean_reg = str(reg_num).strip().upper()
    # Add a "salt" (a secret key) to make it mathematically impossible to crack
    secret_salt = os.getenv("HASH_SALT", "MMUST_DATING_SECURE_2026")
    salted_reg = f"{clean_reg}_{secret_salt}"
    
    return hashlib.sha256(salted_reg.encode('utf-8')).hexdigest()

@app.route('/api/add-crush', methods=['POST'])   
@login_required
def add_crush():
    """Secure Cryptographic Secret Crush Radar"""
    data = request.json
    user_id = session.get('user_id')
    
    # Normalize the Reg Number (strip spaces and make uppercase)
    raw_crush_id = data.get('crush_id', '').strip().upper() 

    if not raw_crush_id:
        return jsonify({"status": "error", "message": "Please enter a valid Registration Number."}), 400

    # Stop users from crushing on themselves!
    if raw_crush_id == user_id:
        return jsonify({"status": "error", "message": "You can't crush on yourself!"}), 400

    try:
        timestamp = datetime.now(EAT).isoformat()
        
        # 🛡️ THE TRUST FORTRESS: Hash the IDs immediately. 
        # We never store who likes who in plain text unless it's a mutual match.
        my_hashed_id = hash_reg_number(user_id)
        hashed_target = hash_reg_number(raw_crush_id)

        crushes_ref = db.reference('crushes')

        # 1. Save the secret crush as a Hash
        # Structure: crushes/MY_HASH/THEIR_HASH = timestamp
        crushes_ref.child(my_hashed_id).update({
            hashed_target: timestamp
        })

        # 2. Check if it is a Mutual Crush! 
        # Did the person I just hashed ALSO hash my ID and save it previously?
        target_crushes = crushes_ref.child(hashed_target).get() or {}

        if target_crushes.get(my_hashed_id):
            # 💘 IT'S A MATCH! The secret is out. 
            # We can now use the raw IDs to create the chat room.
            match_id = "_".join(sorted([user_id, raw_crush_id]))
            
            db.reference(f'matches/{match_id}').set({
                'users': {user_id: True, raw_crush_id: True},
                'matched_at': timestamp,
                'last_message': '💘 Secret Crush Radar Match! You both liked each other.',
                'last_message_time': timestamp
            })

            # Force mutual right-swipes in the database so they never see each other in the deck again
            db.reference(f'swipes/{user_id}/{raw_crush_id}').set({'action': 'like', 'timestamp': timestamp})
            db.reference(f'swipes/{raw_crush_id}/{user_id}').set({'action': 'like', 'timestamp': timestamp})

            # Trigger real-time push notifications to both comrades
            try:
                p1 = db.reference(f'profiles/{user_id}').get() or {}
                p2 = db.reference(f'profiles/{raw_crush_id}').get() or {}
                p1_name = p1.get('name', 'Secret Crush').split()[0]
                p2_name = p2.get('name', 'Secret Crush').split()[0]

                # Alert user 1 (the one who just unlocked the match)
                db.reference(f'notifications/{user_id}').push({
                    'sender_id': raw_crush_id,
                    'sender_name': p2.get('name', 'Secret Crush'),
                    'sender_img': p2.get('img', '/static/img/placeholder.png'),
                    'type': 'crush',
                    'title': '🤫 Secret Crush Match! ❤️',
                    'message': f"💘 OMG! You and {p2_name} secretly liked each other! Tap to chat.",
                    'timestamp': timestamp,
                    'match_id': match_id,
                    'link': f"/matches/{raw_crush_id}",
                    'status': 'unread'
                })

                # Alert user 2 (the crush who had previously entered user 1)
                db.reference(f'notifications/{raw_crush_id}').push({
                    'sender_id': user_id,
                    'sender_name': p1.get('name', 'Secret Crush'),
                    'sender_img': p1.get('img', '/static/img/placeholder.png'),
                    'type': 'crush',
                    'title': '🤫 Secret Crush Match! ❤️',
                    'message': f"💘 OMG! Your Secret Crush on {p1_name} was mutual! Tap to chat.",
                    'timestamp': timestamp,
                    'match_id': match_id,
                    'link': f"/matches/{user_id}",
                    'status': 'unread'
                })
            except Exception as crush_notif_err:
                logger.error(f"Crush radar notification push error: {crush_notif_err}")

            # Dispatch mutual match email alerts so neither user misses the match
            try:
                def _dispatch_crush_match_emails(uid1, uid2):
                    try:
                        p1 = db.reference(f'profiles/{uid1}').get() or {}
                        p2 = db.reference(f'profiles/{uid2}').get() or {}
                        e1 = p1.get('email') or db.reference(f'users/{uid1}/email').get()
                        e2 = p2.get('email') or db.reference(f'users/{uid2}/email').get()
                        reason = "OMG! Secret Crush Radar Match! You both liked each other! 🤫❤️"
                        from app.email_service import send_mutual_match_email
                        if e1:
                            send_mutual_match_email(e1, p1.get('name', 'Comrade'), p2.get('name', 'Someone'), p2.get('img'), reason)
                        if e2:
                            send_mutual_match_email(e2, p2.get('name', 'Comrade'), p1.get('name', 'Someone'), p1.get('img'), reason)
                    except Exception as err:
                        logger.error(f"Crush match email dispatch failed: {err}")

                threading.Thread(target=_dispatch_crush_match_emails, args=(user_id, raw_crush_id), daemon=True).start()
            except Exception as e:
                logger.error(f"Crush email dispatch setup error: {e}")

            return jsonify({
                "status": "success", 
                "match": True, 
                "message": "💘 OMG! It's a match! They liked you too. Check your messages!"
            })

        # 3. Not a mutual crush yet. Keep it encrypted and hidden.
        return jsonify({
            "status": "success", 
            "match": False, 
            "message": "🤫 Crush locked securely! If they enter your Reg Number, you'll match instantly."
        })

    except Exception as e:
        logger.error(f"Crush Radar Cryptographic Error: {e}")
        return jsonify({"status": "error", "message": "Server error while saving crush securely."}), 500
    
    
@app.route('/api/check-pending-date')
@login_required
def check_pending_date():
    user_id = request.args.get('user_id')
    # Query your bookings table for any 'Approved' dates for this user
    bookings = db.reference('bookings').order_by_child('user_a_id').equal_to(user_id).get() or {}
    
    # Check both sides (User A and User B)
    pending_found = False
    for b in bookings.values():
        if b.get('status') == 'Approved':
            pending_found = True
            break
            
    return jsonify({'has_pending': pending_found})

@app.route('/start_chat/<target_id>', methods=['POST'])
@login_required
def start_chat(target_id):
    sender_id = session.get('user_id')
    sender_profile = db.reference(f'profiles/{sender_id}').get() or {}
    
    users_sorted = sorted([str(sender_id), str(target_id)])
    match_id = f"match_{users_sorted[0]}_{users_sorted[1]}"
    
    now_eat = datetime.now(EAT).isoformat()
    
    # 1. Setup the match
    db.reference(f'matches/{match_id}/users/{sender_id}').set(True)
    db.reference(f'matches/{match_id}/users/{target_id}').set(True)
    
    # 2. Send Notification to target
    sender_name = sender_profile.get('name', 'Someone')
    sender_img = sender_profile.get('img', '/static/img/placeholder.png')
    
    db.reference(f'notifications/{target_id}').push({
        'sender_id': sender_id,
        'sender_name': sender_name,
        'sender_img': sender_img,
        'type': 'match',
        'message': f"👋 {sender_name.split(' ')[0]} wants to chat with you!",
        'timestamp': now_eat,
        'match_id': match_id
    })
    
    return redirect(url_for('matches', partner_id=target_id))

@app.route('/matches')
@app.route('/matches/<partner_id>')
@requires_subscription
def matches(partner_id=None):
    # PROTECTED: Must be logged in AND paid
    user_id = session.get('user_id')
    if session.get('account_type') == 'sponsor':
        from app.database import get_sponsor_profile
        user_data = get_sponsor_profile(user_id) or {}
    else:
        user_data = db.reference(f'profiles/{user_id}').get() or {}
    
    # Check if the user is in "Ghost Mode" (only talking to AI)
    ai_mode = user_data.get('settings', {}).get('ai_companion_mode') == True
    
    my_matches = []
    
    if ai_mode:
        # --- AI COMPANION MODE (Ghost Mode) ---
        my_matches.append({
            'id': 'AI_COMPANION', 'name': 'AI Companion',
            'img': 'https://api.dicebear.com/7.x/bottts/svg?seed=MMUST&backgroundColor=ffccd5', 
            'is_perfect_match': True, 'is_online': True, 'is_mutual_match': True,
            'last_message': 'Ready to chat!', 'last_message_time': 'Just now'
        })
        partner_id = 'AI_COMPANION'
    else:
        # --- HUMAN OPEN-DM MODE (Shows everyone, highlights matches) ---
        
        # 1. Get current user's gender for filtering
        current_user_gender = user_data.get('gender', '').strip().lower()

        # 2. Fetch all matches and filter in Python to PREVENT Firebase crashes!
        all_matches = db.reference('matches').get() or {}
        
        matched_data = {}
        for match_id, m_data in all_matches.items():
            if user_id in m_data.get('users', {}):
                users_dict = m_data.get('users', {})
                other_id = next((uid for uid in users_dict.keys() if uid != user_id), None)
                
                if other_id:
                    matched_data[other_id] = {
                        'last_message': m_data.get('last_message', 'You matched! Say hi.'),
                        'last_message_time': m_data.get('last_message_time', '')
                    }

        # 3. Fetch ALL profiles in the system
        all_profiles = get_all_profiles()
        
        # 4. Build the inbox list with EVERYONE
        for p in all_profiles:
            # Skip the current user themselves and hidden profiles
            if p['id'] != user_id and p.get('is_visible', True): 
                p_id = p['id']
                partner_gender = p.get('gender', '').strip().lower()
                is_mutual = p_id in matched_data
                
                # If they are unpaid, ONLY include them if they are the requested partner or we have history
                if not p.get('is_paid') and p_id != partner_id and not is_mutual:
                    continue
                
                # Gender Filter (Only show opposite gender in matches)
                # BYPASS if this is an explicit DM request (p_id == partner_id) or if there is already chat history (is_mutual)
                if current_user_gender and partner_gender and p_id != partner_id and not is_mutual:
                    if current_user_gender == 'male' and partner_gender != 'female':
                        continue
                    if current_user_gender == 'female' and partner_gender != 'male':
                        continue
                
                if is_mutual:
                    last_msg = matched_data[p_id]['last_message']
                    last_msg_time = matched_data[p_id]['last_message_time']
                else:
                    last_msg = 'Tap to start chatting'
                    last_msg_time = ''
                
                # Retrieve AI score safely, default to 0
                ai_score = p.get('ai_score', 0)
                
                # Double-check opposite gender before awarding the Perfect Match badge
                is_opposite_gender = bool(current_user_gender and partner_gender and current_user_gender != partner_gender)
                is_perfect_match = is_opposite_gender and ai_score > 80
                
                # Calculate unread count for this match
                unread_count = 0
                streak_count = 0
                if is_mutual:
                    users_sorted = sorted([str(user_id), str(p_id)])
                    m_id = f"match_{users_sorted[0]}_{users_sorted[1]}"
                    match_metadata = all_matches.get(m_id, {})
                    chat_data = match_metadata.get('messages', {})
                    streak_count = match_metadata.get('streak_count', 0)
                    
                    if isinstance(chat_data, dict):
                        for msg in chat_data.values():
                            if isinstance(msg, dict) and msg.get('sender_id') == p_id and msg.get('status') != 'read':
                                unread_count += 1
                    elif isinstance(chat_data, list):
                        for msg in chat_data:
                            if isinstance(msg, dict) and msg.get('sender_id') == p_id and msg.get('status') != 'read':
                                unread_count += 1

                my_matches.append({
                    'id': p_id,
                    'name': p.get('name', 'Student').split(' ')[0], # First Name only
                    'img': p.get('img', '/static/img/placeholder.png'),
                    'phone': p.get('phone'), # Professional access for mutual matches
                    'is_perfect_match': is_perfect_match, # ❤️ TRIGGERS PERFECT MATCH BADGE
                    'is_online': p.get('is_online', False),
                    'last_seen': p.get('last_seen', ''),
                    'is_mutual_match': is_mutual,      # 🔥 TRIGGERS MUTUAL MATCH GLOW
                    'last_message': last_msg,
                    'last_message_time': last_msg_time,
                    'unread_count': unread_count,
                    'streak_count': streak_count
                })
        
        # 5. ALWAYS append the AI Wingman to the list
        my_matches.append({
            'id': 'AI_COMPANION', 'name': 'AI Wingman',
            'img': 'https://api.dicebear.com/7.x/bottts/svg?seed=wingman',
            'is_perfect_match': False, 'is_online': True, 'is_mutual_match': False,
            'last_message': 'Need dating advice?', 'last_message_time': '',
            'unread_count': 0, 'streak_count': 0
        })

        # 6. Sort matches (Mutual matches first, then by time)
        my_matches.sort(key=lambda x: (x['is_mutual_match'], x.get('last_message_time', '')), reverse=True)

        if not partner_id and my_matches:
            partner_id = my_matches[0]['id']

    # Find the data for the person currently being chatted with
    active_partner = next((m for m in my_matches if str(m['id']) == str(partner_id)), None)
    
    # Calculate distance if we have an active_partner
    if active_partner and partner_id != 'AI_COMPANION':
        partner_profile = db.reference(f'profiles/{partner_id}').get() or {}
        p_lat = partner_profile.get('latitude')
        p_lon = partner_profile.get('longitude')
        u_lat = user_data.get('latitude')
        u_lon = user_data.get('longitude')
        
        distance = calculate_distance(u_lat, u_lon, p_lat, p_lon)
        if 0 <= distance <= 10:
            active_partner['is_nearby'] = True
            active_partner['distance_km'] = round(distance, 1)
            
    if partner_id and not active_partner and not ai_mode:
        flash("This student could not be found or is not available.", "warning")
        return redirect(url_for('matches'))

    # Load the chat history AS A DICTIONARY
    history = {}
    if active_partner and partner_id != 'AI_COMPANION':
        users_sorted = sorted([str(user_id), str(partner_id)])
        match_id = f"match_{users_sorted[0]}_{users_sorted[1]}"
        history_ref = db.reference(f'matches/{match_id}/messages')
        history = history_ref.get() or {}
        
        # Mark all messages sent by this partner to the current user as 'read'
        updated = False
        updates = {}
        if isinstance(history, dict):
            for msg_key, msg in history.items():
                if isinstance(msg, dict) and msg.get('sender_id') == partner_id and msg.get('status') != 'read':
                    updates[f'{msg_key}/status'] = 'read'
                    msg['status'] = 'read'
                    updated = True
        elif isinstance(history, list):
            for index, msg in enumerate(history):
                if isinstance(msg, dict) and msg.get('sender_id') == partner_id and msg.get('status') != 'read':
                    updates[f'{index}/status'] = 'read'
                    msg['status'] = 'read'
                    updated = True
        
        if updated:
            try:
                history_ref.update(updates)
            except Exception as e:
                logger.error(f"Failed to update message read statuses: {e}")
                
        # Force history to dict for Jinja to parse correctly
        if isinstance(history, list):
            history_dict = {}
            for i, item in enumerate(history):
                if item is not None:
                    history_dict[str(i)] = item
            history = history_dict
    
    # ==========================================
    # 🧮 THE "BLURRED LINES" (BLIND DATE) MATH
    # ==========================================
    is_blind_date = False
    current_blur = 0
    messages_left = 0

    if active_partner and partner_id != 'AI_COMPANION':
        # Only apply blind date logic to mutual matches
        if active_partner.get('is_mutual_match'):
            
            # Check user settings (defaulting to True for the gamified experience)
            user_settings = user_data.get('settings', {})
            is_blind_date = user_settings.get('blind_date_mode', True)
            
            if is_blind_date:
                MESSAGES_TO_REVEAL = 20 # 10 texts sent by each person
                MAX_BLUR_PX = 15        # Starts heavily blurred
                message_count = len(history) # history is now a dict, so len(history) counts the keys
                
                if message_count >= MESSAGES_TO_REVEAL:
                    current_blur = 0
                    messages_left = 0
                else:
                    # Calculate proportional blur drop based on message count
                    current_blur = MAX_BLUR_PX - (MAX_BLUR_PX * (message_count / MESSAGES_TO_REVEAL))
                    messages_left = MESSAGES_TO_REVEAL - message_count

    # Fetch real active venues from merchants
    # get_all_restaurants() returns a list of dicts, each already containing 'id'
    all_restaurants = get_all_restaurants()
    active_venues = []
    if all_restaurants:
        for rdata in all_restaurants:
            if rdata.get('subscription_active') or rdata.get('merchant_fee', 0) == 0:
                active_venues.append(rdata)

    return render_template('matches.html', 
                           current_user=session.get('user_name'),
                           my_matches=my_matches,
                           active_partner=active_partner,
                           chat_history=history, # Now correctly passes a dictionary
                           is_blind_date=is_blind_date,           # Pass flag to UI
                           current_blur=round(current_blur, 1),   # Pass pixel blur to UI
                           messages_left=messages_left,           # Pass progress to UI
                           venues=active_venues)                  # Pass real venues to UI    
        
        
@app.context_processor
def utility_processor():
    def get_music_embed_info(url):
        if not url:
            return None
        url = url.strip()
        
        # 1. Spotify parsing
        if 'spotify.com' in url:
            parts = url.split('/')
            for i, part in enumerate(parts):
                if part in ['track', 'playlist', 'album', 'artist'] and i + 1 < len(parts):
                    item_id = parts[i+1].split('?')[0]
                    return {
                        'type': 'spotify',
                        'embed_url': f"https://open.spotify.com/embed/{part}/{item_id}",
                        'original_url': url,
                        'icon': '🟢'
                    }
                    
        # 2. YouTube parsing
        if 'youtube.com' in url or 'youtu.be' in url:
            video_id = None
            playlist_id = None
            
            # YouTube playlist
            if 'list=' in url:
                import urllib.parse as urlparse
                parsed = urlparse.urlparse(url)
                params = urlparse.parse_qs(parsed.query)
                playlist_id = params.get('list', [None])[0]
                if playlist_id:
                    return {
                        'type': 'youtube',
                        'embed_url': f"https://www.youtube.com/embed/videoseries?list={playlist_id}",
                        'original_url': url,
                        'icon': '🔴'
                    }
                    
            # YouTube shorts
            if '/shorts/' in url:
                parts = url.split('/shorts/')
                if len(parts) > 1:
                    video_id = parts[1].split('?')[0].split('/')[0]
                    
            # Regular watch link
            elif 'v=' in url:
                import urllib.parse as urlparse
                parsed = urlparse.urlparse(url)
                params = urlparse.parse_qs(parsed.query)
                video_id = params.get('v', [None])[0]
                
            # Short links
            elif 'youtu.be/' in url:
                parts = url.split('youtu.be/')
                if len(parts) > 1:
                    video_id = parts[1].split('?')[0].split('/')[0]
                    
            if video_id:
                return {
                    'type': 'youtube',
                    'embed_url': f"https://www.youtube.com/embed/{video_id}",
                    'original_url': url,
                    'icon': '🔴'
                }
                
        # Generic/Unsupported link fallback
        return {
            'type': 'generic',
            'embed_url': None,
            'original_url': url,
            'icon': '🎵'
        }
        
    return dict(get_music_embed_info=get_music_embed_info)

        
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # PROTECTED: Must be logged in (but unpaid users can still edit their profile)
    user_id = session.get('user_id')
    user_ref = db.reference(f'profiles/{user_id}')
    user_data = user_ref.get()

    if not user_data:
        flash("Profile not found. Please log in again.", "error")
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        # 1. Grab raw form data
        new_bio = request.form.get('bio')
        new_age = request.form.get('age')
        new_religion = request.form.get('religion')
        new_avatar = request.form.get('avatar') # For the new 20 avatars feature!
        new_phone = request.form.get('phone')
        new_spotify_playlist = request.form.get('spotify_playlist')
        new_spotify_anthem = request.form.get('spotify_anthem')

        try:
            # 1.5 Handle Photo Upload to Firebase Storage
            profile_image = request.files.get('profile_image')
            image_url = None
            if profile_image and profile_image.filename:
                try:
                    bucket = storage.bucket()
                    # Generate a unique filename to prevent overwrites
                    ext = os.path.splitext(profile_image.filename)[1]
                    filename = f"profile_{int(time.time())}{ext}"
                    blob = bucket.blob(f"profiles/{user_id}/{filename}")
                    
                    blob.upload_from_file(profile_image, content_type=profile_image.content_type)
                    blob.make_public()
                    image_url = blob.public_url
                    logger.info(f"Successfully uploaded image for user {user_id}: {image_url}")
                except Exception as upload_err:
                    logger.error(f"Image Upload Error: {upload_err}")
                    flash("Failed to upload image. Please try again.", "error")

            # 2. Build an update dictionary dynamically (Cleaner & Safer)
            update_data = {}
            if new_bio: update_data['bio'] = new_bio.strip()
            if new_religion: update_data['religion'] = new_religion.strip()
            if new_phone:
                new_phone = new_phone.strip().replace('+', '')
                # If it starts with 0, replace with 254
                if new_phone.startswith('0'):
                    new_phone = '254' + new_phone[1:]
                
                if new_phone.isdigit() and len(new_phone) >= 9:
                    update_data['phone'] = new_phone
                else:
                    flash("Please enter a valid phone number.", "warning")
                    
            if image_url: 
                update_data['img'] = image_url
            elif new_avatar: 
                update_data['img'] = new_avatar.strip()
            
            # Prevent crashes by ensuring 'age' is actually a number before casting to int
            if new_age and new_age.isdigit():
                update_data['age'] = int(new_age)
                
            if new_spotify_playlist is not None:
                update_data['spotify_playlist'] = new_spotify_playlist.strip()
            if new_spotify_anthem is not None:
                update_data['spotify_anthem'] = new_spotify_anthem.strip()

            # 3. Only ping the database if there is actually something to update
            if update_data:
                user_ref.update(update_data)
            
            if new_religion:
                session['user_religion'] = new_religion

            # 4. Handle Schedule Updates (Using Python's 'zip' makes this much cleaner)
            days = request.form.getlist('day_of_week[]')
            starts = request.form.getlist('start_time[]')
            ends = request.form.getlist('end_time[]')
            
            for day, start, end in zip(days, starts, ends):
                if day and start and end:
                    save_schedule(user_id, day, start, end)
            
            flash("Profile and Free Time Schedule updated successfully!", "success")
            return redirect(url_for('profile'))
            
        except Exception as e:
            # Better error logging so you can track bugs in Render
            logger.error(f"Profile Update Error for user {user_id}: {e}")
            flash("Error updating profile. Please try again.", "error")

    return render_template('profile.html', current_user=session.get('user_name'), user=user_data)


def calculate_profile_badges(user_data):
    """Determines which badges a user has earned based on their activity."""
    badges = []
    
    # 0. Subscription Premium Badges
    if user_data.get('is_paid'):
        package = user_data.get('subscription_package', 'gold')
        if package == 'diamond':
            badges.append({'id': 'diamond_vip', 'icon': '👑', 'label': 'Diamond VIP Premium', 'color': '#EC4899'})
        else:
            badges.append({'id': 'gold_vip', 'icon': '💫', 'label': 'Gold Premium', 'color': '#EAB308'})
            
    # 1. Verified Badge
    if user_data.get('is_verified'):
        badges.append({'id': 'verified', 'icon': '✅', 'label': 'Verified Comrade', 'color': '#38BDF8'})
    
    # 2. Profile Pro (Completion Badge)
    bio = user_data.get('bio', '')
    img = user_data.get('img')
    if len(bio) > 20 and img and isinstance(img, str) and not img.endswith('placeholder.png'):
        badges.append({'id': 'pro', 'icon': '💎', 'label': 'Profile Pro', 'color': '#A855F7'})
        
    # 3. Highly Responsive (Simulated based on online status/activity)
    if user_data.get('is_online'):
        badges.append({'id': 'active', 'icon': '⚡', 'label': 'Highly Responsive', 'color': '#22C55E'})
        
    # 4. FEATURE 15: Verified Vibes Badge
    # Awarded to users with 5 or more positive post-date/call reviews
    if int(user_data.get('positive_vibes', 0)) >= 5:
        badges.append({'id': 'verified_vibes', 'icon': '🌟', 'label': 'Verified Vibes', 'color': '#F59E0B'})
        
    # 4. Legacy Badge (Account Age)
    created_at = user_data.get('created_at')
    if created_at:
        try:
            created_dt = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
            if (datetime.now(timezone.utc) - created_dt).days > 30:
                badges.append({'id': 'legacy', 'icon': '🛡️', 'label': 'Legacy User', 'color': '#EAB308'})
        except:
            pass
            
    return badges

@app.route('/view_profile/<target_id>')
@app.route('/student/<target_id>')
@requires_subscription
def view_student(target_id):
    # PROTECTED: Must be logged in AND paid
    all_profiles = get_all_profiles()
    student_profile = next((p for p in all_profiles if p['id'] == target_id), None)
    
    if not student_profile:
        flash("Oops! We couldn't find that student's profile.", "error")
        return redirect(url_for('dashboard'))

    # --- NEW: FETCH TODAY'S PROMPT ANSWER ---
    today_str = datetime.now(EAT).strftime('%Y-%m-%d')
    prompt_data = get_todays_prompt()
    answer_data = db.reference(f'prompt_answers/{today_str}/{target_id}').get()
    
    daily_qa = None
    if answer_data:
        daily_qa = {
            'question': prompt_data.get('question'),
            'answer': answer_data.get('answer')
        }
        
    # --- NEW: CALCULATE BADGES ---
    badges = calculate_profile_badges(student_profile)
        
    return render_template('view_profile.html', student=student_profile, daily_qa=daily_qa, badges=badges)

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    # PROTECTED: Must be logged in (but unpaid users can still edit settings)
    user_id = session.get('user_id')
    user_ref = db.reference(f'profiles/{user_id}')

    if request.method == 'POST':
        # 1. Grab values from the HTML Form
        gender_pref = request.form.get('gender_pref')
        major_filter = request.form.get('major_filter')
        strict_mode = request.form.get('strict_mode') == 'on'
        ai_mode = request.form.get('ai_mode') == 'on'
        
        # 🔥 Grab the new Blind Date Mode toggle
        blind_date_mode = request.form.get('blind_date_mode') == 'on'
        
        # 🆕 Grab the new Intent Tag (defaults to 'none' if they didn't touch it)
        intent = request.form.get('intent', 'none') 
        tribe = request.form.get('tribe', 'none')
        
        age_min = int(request.form.get('age_min', 18))
        age_max = int(request.form.get('age_max', 99))

        try:
            # 2. Save filter settings to the 'settings' sub-node
            user_ref.child('settings').update({
                'looking_for': gender_pref,
                'major_filter': major_filter,
                'strict_schedule': strict_mode,
                'ai_companion_mode': ai_mode,
                'blind_date_mode': blind_date_mode,  # 🔥 Save to Firebase
                'age_min': age_min,
                'age_max': age_max
            })
            
            # 3. Update main profile attributes (visibility and the new intent tag)
            user_ref.update({
                'is_visible': not ai_mode,
                'intent': intent,  # 🆕 Save the intent to the main profile
                'tribe': tribe     # Feature 3: Interest Clusters
            })
            
            flash("Discovery settings updated successfully!", "success")
            
            # 4. Redirect them back to the Swipe deck to see their new matches!
            return redirect(url_for('swipe'))
            
        except Exception as e:
            logger.error(f"Settings Save Error: {e}")
            flash("Error saving settings to cloud.", "error")
            return redirect(url_for('settings'))


    # === GET REQUEST LOGIC ===
    # 1. Fetch the user's data from Firebase
    user_profile = user_ref.get() or {}
    user_settings = user_profile.get('settings', {})

    # 2. Map the Firebase keys to the variables the HTML template expects
    template_user_data = {
        'gender_pref': user_settings.get('looking_for', 'Everyone'),
        'major_filter': user_settings.get('major_filter', 'All'),
        'strict_mode': user_settings.get('strict_schedule', False),
        'ai_mode': user_settings.get('ai_companion_mode', False),
        
        # 🔥 Pass the blind date mode back to the template (Defaulting to True)
        'blind_date_mode': user_settings.get('blind_date_mode', True),
        
        # 🆕 Pass the intent back so the dropdown remembers their choice
        'intent': user_profile.get('intent', 'none'),
        
        'age_min': user_settings.get('age_min', 18),
        'age_max': user_settings.get('age_max', 99)
    }

    # 3. Render the page
    return render_template(
        'settings.html', 
        current_user=session.get('user_name'),
        user=template_user_data
    )

@app.route('/api/save_personality', methods=['POST'])
@login_required
@csrf.exempt
def save_personality():
    user_id = session.get('user_id')
    user_ref = db.reference(f'profiles/{user_id}')
    
    data = request.json or {}
    traits = {
        'openness': int(data.get('openness', 50)),
        'conscientiousness': int(data.get('conscientiousness', 50)),
        'extraversion': int(data.get('extraversion', 50)),
        'agreeableness': int(data.get('agreeableness', 50)),
        'neuroticism': int(data.get('neuroticism', 50))
    }
    
    user_ref.update({'personality': traits})
    
    return jsonify({"success": True})


@app.route('/merchant-terms')
def merchant_terms():
    return render_template('merchant_terms.html')

    
# ==========================================
# 8. B2B PAGES (MERCHANTS)
# ==========================================
import uuid
from werkzeug.security import generate_password_hash, check_password_hash

@app.route('/business/register', methods=['GET', 'POST'])
def business_register():
    """HANDLES NEW MERCHANT SIGNUPS"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        business_name = request.form.get('business_name', '')

        try:
            # Check if email exists (Safe Python loop bypassing complex Firebase rules)
            all_restaurants = db.reference('restaurants').get() or {}
            for r_data in all_restaurants.values():
                if isinstance(r_data, dict) and r_data.get('email') == email:
                    flash('This email is already registered. Please log in.', 'warning')
                    return redirect(url_for('business_login'))

            # Generate secure IDs and Hashes
            restaurant_id = str(uuid.uuid4())
            hashed_password = generate_password_hash(password)
            
            # Fetch system settings for merchant fee
            sys_settings = db.reference('system_settings').get() or {}
            merchant_fee = sys_settings.get('merchant_fee', 0) # Default to 0 (free)
            
            is_free = int(merchant_fee) == 0
            
            # Create the data payload
            new_merchant = {
                'business_name': business_name,
                'location': request.form.get('location'),
                'owner_name': request.form.get('owner_name'),
                'phone': request.form.get('phone'),
                'email': email,  
                'password': hashed_password, 
                'conditions': request.form.get('conditions'),
                'subscription_active': is_free,
                'subscription_package': 'DIAMOND' if is_free else None,
                'subscription_expiry': (datetime.now(EAT) + timedelta(days=365)).isoformat() if is_free else None,
                'profile_views': 0,
                'qr_scans': 0,
                'hourly_stats': {}
            }

            # Save to Firebase
            db.reference(f'restaurants/{restaurant_id}').set(new_merchant)
            
            # AUTO-LOGIN
            session['user_id'] = restaurant_id
            session['user_name'] = business_name
            session['role'] = 'business'
            
            flash('Merchant account created successfully! Welcome to your dashboard.', 'success')
            return redirect(url_for('business_dashboard'))
            
        except Exception as e:
            logger.error(f"Registration Error: {e}") 
            flash('Failed to create account. Please check your connection and try again.', 'error')
            return redirect(url_for('business_register'))

    return render_template('restaurant_signup.html')


@app.route('/business-login', methods=['GET', 'POST'])
def business_login():
    """DEDICATED PORTAL FOR RESTAURANT OWNERS"""
    if session.get('user_id') and session.get('role') == 'business':
        return redirect(url_for('business_dashboard'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        try:
            all_restaurants = db.reference('restaurants').get() or {}
            matched_id = None
            matched_data = None
            
            for r_id, r_data in all_restaurants.items():
                if isinstance(r_data, dict) and r_data.get('email') == email:
                    matched_id = r_id
                    matched_data = r_data
                    break
            
            if matched_data:
                stored_password = matched_data.get('password', '')
                is_valid_password = False
                
                # HYBRID CHECK: Supports old plain-text OR new hashed passwords
                if stored_password == password:
                    is_valid_password = True  
                elif stored_password.startswith('scrypt:') or stored_password.startswith('pbkdf2:'):
                    is_valid_password = check_password_hash(stored_password, password)

                if is_valid_password:
                    session['user_id'] = matched_id
                    session['user_name'] = matched_data.get('business_name', 'Partner')
                    session['role'] = 'business'
                    
                    flash("Welcome back to your Partner Dashboard!", "success")
                    return redirect(url_for('business_dashboard'))
            
            flash("Invalid business email or password.", "error")
            
        except Exception as e:
            logger.error(f"Business Login Error: {e}")
            flash("Connection error. Please try again.", "error")

    return render_template('b2b_login.html')


@app.route('/business/dashboard')
def business_dashboard():
    """THE MERCHANT COMMAND CENTER"""
    if not session.get('user_id') or session.get('role') != 'business':
        flash("Access Denied. Please log in through the Merchant Portal.", "error")
        return redirect(url_for('business_login'))

    restaurant_id = session.get('user_id')
    
    try:
        restaurant = get_restaurant(restaurant_id) or {}
        bookings = get_restaurant_bookings(restaurant_id) or []
    except Exception as e:
        logger.error(f"Dashboard Data Fetch Error: {e}")
        restaurant, bookings = {}, []

    restaurant.setdefault('hourly_stats', {})
    restaurant.setdefault('qr_scans', 0)
    restaurant.setdefault('profile_views', 0)
    restaurant.setdefault('subscription_package', 'DIAMOND')
    restaurant.setdefault('average_spend', 1500)

    # ---------------------------------------------------------
    # ⚡ NEW: DYNAMIC FEE CHECK & AUTO-UNLOCK
    # ---------------------------------------------------------
    sys_settings = db.reference('system_settings').get() or {}
    try:
        merchant_fee = int(sys_settings.get('merchant_fee') or 0)
    except (ValueError, TypeError):
        merchant_fee = 0
    is_free = merchant_fee == 0

    if is_free and not restaurant.get('subscription_active'):
        # Auto-unlock legacy accounts if the fee is 0
        expiry = (datetime.now(EAT) + timedelta(days=365)).isoformat()
        db.reference(f'restaurants/{restaurant_id}').update({
            'subscription_active': True,
            'subscription_package': 'DIAMOND',
            'subscription_expiry': expiry
        })
        restaurant['subscription_active'] = True
        restaurant['subscription_expiry'] = expiry
        restaurant['subscription_package'] = 'DIAMOND'

    pending_count = sum(1 for b in bookings if b.get('status') == 'Pending')
    approved_count = sum(1 for b in bookings if b.get('status') == 'Approved')

    # Calculate Subscription Days Remaining
    days_remaining = 0
    if restaurant.get('subscription_expiry'):
        try:
            expiry = datetime.fromisoformat(restaurant['subscription_expiry'])
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=EAT)

            now = datetime.now(EAT)
            delta = expiry - now
            days_remaining = max(0, delta.days)

            # If expired, mark as inactive in DB so they have to pay again
            if delta.total_seconds() <= 0:
                db.reference(f'restaurants/{restaurant_id}').update({'subscription_active': False})
                restaurant['subscription_active'] = False
                flash("Your subscription has expired. Please renew to continue.", "warning")
        except Exception as e:
            logger.error(f"Expiry Calculation Error: {e}")

    # Check Spotlight Boost Active Timer
    boost_active = False
    boost_days_remaining = 0
    if restaurant.get('boost_active') and restaurant.get('boost_expiry'):
        try:
            boost_exp = datetime.fromisoformat(restaurant['boost_expiry'])
            if boost_exp.tzinfo is None:
                boost_exp = boost_exp.replace(tzinfo=EAT)
            
            now = datetime.now(EAT)
            delta_boost = boost_exp - now
            if delta_boost.total_seconds() > 0:
                boost_active = True
                boost_days_remaining = max(0, delta_boost.days)
            else:
                db.reference(f'restaurants/{restaurant_id}').update({'boost_active': False})
                restaurant['boost_active'] = False
        except: pass

    for b in bookings:
        try:
            user_a = db.reference(f"profiles/{b.get('user_a_id')}").get() or {}
            user_b = db.reference(f"profiles/{b.get('user_b_id')}").get() or {}

            b['user_a_name'] = user_a.get('name', 'Student 1').split(' ')[0] if user_a.get('name') else 'Student 1'
            b['user_b_name'] = user_b.get('name', 'Student 2').split(' ')[0] if user_b.get('name') else 'Student 2'
        except Exception as e:
            logger.warning(f"Failed to fetch student names for booking: {e}")
            b['user_a_name'] = "Student 1" 
            b['user_b_name'] = "Student 2"

    # Calculate ROI & Analytics with Custom Spend Rates
    average_spend = int(restaurant.get('average_spend', 1500))
    now = datetime.now(EAT)
    start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    monthly_completed = 0
    monthly_revenue = 0
    total_revenue_delivered = 0

    for b in bookings:
        if b.get('status') in ['Completed', 'Archived']:
            total_revenue_delivered += average_spend
            b_timestamp = b.get('completed_timestamp')
            if b_timestamp:
                try:
                    b_date = datetime.fromisoformat(b_timestamp)
                    if b_date >= start_of_month:
                        monthly_completed += 1
                        monthly_revenue += average_spend
                except:
                    # Fallback for old completed bookings
                    monthly_completed += 1
                    monthly_revenue += average_spend

    # Calculate Platform Subscription Fee Paid
    sub_fee = 5000 if restaurant.get('subscription_package') == 'diamond' else 2000
    roi_percent = 0
    if sub_fee > 0 and total_revenue_delivered > 0:
        roi_percent = int(((total_revenue_delivered - sub_fee) / sub_fee) * 100)

    analytics = {
        'total_views': restaurant.get('profile_views', 0),
        'monthly_completed': monthly_completed,
        'monthly_revenue': f"{monthly_revenue:,}",
        'total_revenue_delivered': f"{total_revenue_delivered:,}",
        'subscription_status': 'ACTIVE' if restaurant.get('subscription_active') else 'INACTIVE',
        'subscription_package': restaurant.get('subscription_package', 'gold').upper(),
        'days_remaining': days_remaining,
        'roi_percent': roi_percent,
        'boost_active': boost_active,
        'boost_days_remaining': boost_days_remaining
    }

    # Fetch active perks for the dashboard
    flash_perks = db.reference(f'flash_perks/{restaurant_id}').get() or {}

    # Advanced Diamond Customer Demographics Insights
    faculty_stats = {}
    gender_stats = {'male': 0, 'female': 0}
    if restaurant.get('subscription_package') == 'diamond':
        try:
            for b in bookings:
                user_a = db.reference(f"profiles/{b.get('user_a_id')}").get() or {}
                user_b = db.reference(f"profiles/{b.get('user_b_id')}").get() or {}
                
                for u in [user_a, user_b]:
                    if u.get('faculty'):
                        fac = u['faculty'].strip()
                        faculty_stats[fac] = faculty_stats.get(fac, 0) + 1
                    if u.get('gender'):
                        g = u['gender'].lower().strip()
                        if g in ['male', 'm']:
                            gender_stats['male'] += 1
                        elif g in ['female', 'f']:
                            gender_stats['female'] += 1
        except Exception as e:
            logger.error(f"Error compiling demographic insights: {e}")

    return render_template('business_dashboard.html', 
                           restaurant=restaurant, 
                           bookings=bookings,
                           pending_count=pending_count,
                           approved_count=approved_count,
                           days_remaining=days_remaining,
                           analytics=analytics,
                           flash_perks=flash_perks,
                           faculty_stats=faculty_stats,
                           merchant_fee=merchant_fee,
                           gender_stats=gender_stats)
                           
@app.route('/business/booking/<booking_id>/<action>', methods=['POST'])
def manage_booking(booking_id, action):
    """ALLOWS RESTAURANTS TO ACCEPT/DECLINE RESERVATIONS AND NOTIFIES USERS"""
    if session.get('role') != 'business': 
        return redirect(url_for('home'))
        
    restaurant_id = session.get('user_id')
    restaurant = db.reference(f"restaurants/{restaurant_id}").get() or {}
    
    if not restaurant.get('subscription_active'):
        flash("Action Denied: Your merchant subscription is currently inactive. Please renew to manage bookings.", "error")
        return redirect(url_for('business_dashboard'))

    status = 'Approved' if action == 'approve' else 'Declined'
    
    try:
        # 1. Update the database
        update_booking_status(booking_id, status)
        
        # 2. If Approved, fetch details and send emails in the background
        if status == 'Approved':
            # Fetch the specific booking from Firebase
            booking = db.reference(f'bookings/{booking_id}').get()
            
            if booking:
                # Fetch both users' profiles
                user_a = db.reference(f"profiles/{booking.get('user_a_id')}").get() or {}
                user_b = db.reference(f"profiles/{booking.get('user_b_id')}").get() or {}
                
                # Fetch the restaurant's profile
                restaurant_id = session.get('user_id')
                restaurant = db.reference(f"restaurants/{restaurant_id}").get() or {}
                
                # Prepare the variables
                r_name = restaurant.get('business_name', 'Our Venue')
                r_location = restaurant.get('location', 'Check app for details')
                d_day = booking.get('day', 'your scheduled day')
                d_time = booking.get('time', 'your scheduled time')

                # We use threading so the Python server sends the emails in the background.
                # This prevents the Merchant Dashboard from "freezing" for 3 seconds while emails send!
                
                if user_a.get('email'):
                    user_a_name = user_a.get('name', 'Student').split(' ')[0]
                    user_b_name = user_b.get('name', 'Your Date').split(' ')[0]
                    
                    threading.Thread(target=send_date_approval_email, args=(
                        user_a['email'], user_a_name, user_b_name, r_name, d_day, d_time, r_location
                    )).start()
                    
                if user_b.get('email'):
                    user_b_name = user_b.get('name', 'Student').split(' ')[0]
                    user_a_name = user_a.get('name', 'Your Date').split(' ')[0]
                    
                    threading.Thread(target=send_date_approval_email, args=(
                        user_b['email'], user_b_name, user_a_name, r_name, d_day, d_time, r_location
                    )).start()

                # Push real-time notification alerts to both students
                try:
                    now_eat_notif = datetime.now(EAT).isoformat()
                    user_a_id = booking.get('user_a_id')
                    user_b_id = booking.get('user_b_id')
                    b_status_lower = status.lower()
                    if status == 'Approved':
                        notif_title = f"Date Confirmed at {r_name}! 🍷✨"
                        notif_msg = f"Your reservation for {d_day} at {d_time} has been approved by {r_name}!"
                        notif_type = 'date_request'
                    else:
                        notif_title = f"Date Reservation {status.capitalize()} 📍"
                        notif_msg = f"Your reservation at {r_name} was {b_status_lower}."
                        notif_type = 'system'

                    for uid in [user_a_id, user_b_id]:
                        if uid:
                            db.reference(f'notifications/{uid}').push({
                                'sender_id': restaurant_id or 'SYSTEM',
                                'sender_name': r_name,
                                'sender_img': restaurant.get('image') or '/static/img/placeholder.png',
                                'type': notif_type,
                                'title': notif_title,
                                'message': notif_msg,
                                'timestamp': now_eat_notif,
                                'link': '/bookings',
                                'status': 'unread'
                            })
                except Exception as booking_notif_err:
                    logger.error(f"Failed to push booking status notification: {booking_notif_err}")

        flash(f"Reservation {status.lower()}! The couple has been notified via email.", "success")
        
    except Exception as e:
        logger.error(f"Error updating booking {booking_id}: {e}")
        flash("Failed to update reservation. Try again.", "error")
        
    return redirect(url_for('business_dashboard'))


@app.route('/business/qr')
def merchant_qr():
    """GENERATES THE UNIQUE QR CODE FOR THE RESTAURANT"""
    if session.get('role') != 'business':
        return redirect(url_for('home'))

    restaurant_id = session.get('user_id')
    restaurant = db.reference(f"restaurants/{restaurant_id}").get() or {}

    if not restaurant.get('subscription_active'):
        flash("Access Denied: Your merchant subscription is currently inactive. Please renew to access your QR code.", "error")
        return redirect(url_for('business_dashboard'))

    restaurant_name = restaurant.get('business_name', 'Merchant')
    verify_url = f"{request.url_root.rstrip('/')}/verify_customer/{restaurant_id}"

    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(verify_url)
    qr.make(fit=True)
    
    buf = io.BytesIO()
    qr.make_image(fill_color="#720000", back_color="white").save(buf)
    image_base64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    
    return render_template('merchant_qr.html', 
                           qr_code=image_base64, 
                           restaurant_name=restaurant_name)


@app.route('/verify_customer/<restaurant_id>')
def verify_customer(restaurant_id):
    """THE PAGE STUDENTS SEE WHEN THEY SCAN A RESTAURANT'S QR CODE"""
    if 'user_id' not in session: 
        session['next_url'] = request.url 
        flash("Please log in to verify your student discount.", "warning")
        return redirect(url_for('auth.login'))

    user_id = session.get('user_id')
    
    try:
        user_data = db.reference(f'profiles/{user_id}').get()
        restaurant = db.reference(f'restaurants/{restaurant_id}').get()
    except Exception as e:
        logger.error(f"Verification Fetch Error: {e}")
        flash("Database connection error. Please try again.", "error")
        return redirect(url_for('dashboard'))

    if not restaurant: 
        flash("Invalid QR Code. This venue is not part of our network.", "error")
        return redirect(url_for('dashboard'))

    if not user_data or not user_data.get('is_paid'):
        status = "REJECTED"
        message = "No active subscription found. Pay 50 KSH via M-Pesa to unlock exclusive campus discounts."
        color = "#E60026"
    else:
        status = "VERIFIED"
        perk = restaurant.get('conditions', 'Standard Student Discount')
        message = f"Valid Premium Student! Please apply the '{perk}' discount."
        color = "#28a745"
        
        try:
            qr_ref = db.reference(f'restaurants/{restaurant_id}/qr_scans')
            qr_ref.set((qr_ref.get() or 0) + 1)
            
            current_hour = str(datetime.now(EAT).hour)
            hour_ref = db.reference(f'restaurants/{restaurant_id}/hourly_stats/{current_hour}')
            hour_ref.set((hour_ref.get() or 0) + 1)
            
            alert_ref = db.reference(f'merchant_alerts/{restaurant_id}')
            alert_ref.set({
                'student_name': user_data.get('name', 'A Student').split(' ')[0],
                'timestamp': datetime.now(EAT).isoformat(),
                'status': 'new'
            })

            # 🚨 SOS CONTEXT: Find the booking for this date and link the partner
            try:
                bookings_ref = db.reference('bookings')
                # Check bookings where user is either user_a or user_b and venue matches
                all_user_bookings = bookings_ref.get() or {}
                for bid, bdata in all_user_bookings.items():
                    if bdata.get('restaurant_id') == restaurant_id and bdata.get('status') == 'Approved':
                        if bdata.get('user_a_id') == user_id or bdata.get('user_b_id') == user_id:
                            partner_id = bdata.get('user_b_id') if bdata.get('user_a_id') == user_id else bdata.get('user_a_id')
                            partner_data = db.reference(f'profiles/{partner_id}').get() or {}
                            
                            # Save this as the "Latest Verified Date" on the user's profile
                            db.reference(f'profiles/{user_id}/latest_verified_date').set({
                                'partner_id': partner_id,
                                'partner_name': partner_data.get('name', 'Another Student'),
                                'venue_name': restaurant.get('business_name', 'This Venue'),
                                'scan_time': datetime.now(EAT).isoformat()
                            })
                            # Also update the booking status to 'Arrived'
                            db.reference(f'bookings/{bid}/status').set('Arrived')
                            break
            except Exception as context_err:
                logger.error(f"Error updating SOS date context: {context_err}")
        except Exception as e: 
            logger.error(f"Error updating analytics: {e}")

    return render_template('verification_result.html', 
                           status=status, 
                           message=message, 
                           color=color,
                           restaurant_name=restaurant.get('business_name', 'This Venue'))
import os
import logging
from datetime import datetime, timedelta, timezone
from flask import session, request, flash, redirect, url_for, render_template, jsonify

# Setup Admin Logger
logger = logging.getLogger('god_mode')

# Define East Africa Time (UTC+3) for accurate Kenyan timestamps
EAT = timezone(timedelta(hours=3))

import os
from flask import render_template, request, session, flash, redirect, url_for, jsonify
from datetime import datetime, timedelta

import os
from datetime import datetime, timedelta
from flask import render_template, request, session, flash, redirect, url_for, jsonify

# Import your email service functions
from app.email_service import send_broadcast_email
import os
import logging
from datetime import datetime, timedelta
from flask import request, jsonify, session, flash, url_for, render_template, redirect

logger = logging.getLogger(__name__)



import os
import logging
import random
from datetime import datetime, timedelta, timezone
from flask import request, jsonify, render_template, session, redirect, url_for, flash

# Assuming these are imported from your email_utils file:
# from email_utils import send_broadcast_email, send_admin_alert_email

logger = logging.getLogger(__name__)

# Define East Africa Time (EAT)
EAT = timezone(timedelta(hours=3))
# ==========================================
# 🚨 GOD MODE: SUPER ADMIN DASHBOARD
# ==========================================
# ==========================================
# 🚨 GOD MODE: SUPER ADMIN DASHBOARD
# ==========================================
@app.route('/admin/super', methods=['GET', 'POST'])
def super_admin():
    # 1. Handle Login Attempt
    if request.method == 'POST':
        ADMIN_PASSWORD = os.getenv("SUPER_ADMIN_PASS")

        entered_password = request.form.get('password')
        if ADMIN_PASSWORD and entered_password == ADMIN_PASSWORD:
            session['is_super_admin'] = True
            session['super_admin'] = True
            session['role'] = 'admin'
            session['admin'] = True
            session['name'] = 'Super Admin'
            session['user_id'] = session.get('user_id') or 'SUPER_ADMIN'
            session.permanent = False
            flash("Welcome to God Mode, Creator.", "success")
            return redirect(url_for('super_admin'))
        else:
            logger.warning(f"Failed God Mode login attempt from IP: {request.remote_addr}")
            flash("Access Denied. Incorrect Master Password.", "error")
            return redirect(url_for('super_admin'))
        
    if session.get('is_super_admin'):
        session['super_admin'] = True
        session['role'] = 'admin'
        session['admin'] = True

    if not session.get('is_super_admin'):
        
        # Fetch manager ledgers
        manager_ledgers = db.reference('campus_manager_ledgers').get() or {}
        
        return render_template('super_admin.html',
                               manager_ledgers=manager_ledgers,
 logged_in=False)

    # 3. Load Dashboard Data
    try:
        # Fetch All Base Data
        all_profiles = db.reference('profiles').get() or {}
        all_restaurants = db.reference('restaurants').get() or {}
        ledger_data = db.reference('ledger').get() or {}
        pending_payments = db.reference('pending_payments').get() or {}
        all_bookings = db.reference('bookings').get() or {}
        all_matches = db.reference('matches').get() or {}
        
        system_settings = db.reference('system_settings').get() or {}
        promo_active = system_settings.get('new_user_promo', False)
        force_party = system_settings.get('force_party', False)
        maintenance_mode = system_settings.get('maintenance_mode', False)
        merchant_fee = system_settings.get('merchant_fee', 0)

        # ------------------------------------------
        # 0. REPORTS QUEUE
        # ------------------------------------------
        reports_dict = db.reference('reports').get() or {}
        reports = [{'id': k, **v} for k, v in reports_dict.items() if isinstance(v, dict)]
        reports.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

        # ------------------------------------------
        # 1. ACCURATE REVENUE CALCULATION
        # ------------------------------------------
        now = datetime.now(EAT)
        current_year = now.year
        
        monthly_b2b = [0] * 12
        monthly_student_rev = [0] * 12
        accounted_uids = set()

        # A. From Pending Payments (Success Logs)
        if isinstance(pending_payments, dict):
            for tx in pending_payments.values():
                if isinstance(tx, dict) and tx.get('status') == 'success':
                    u_id = tx.get('user_id')
                    ts = tx.get('created_at') or tx.get('timestamp')
                    if ts:
                        try:
                            dt = datetime.fromisoformat(ts)
                            if dt.year == current_year:
                                m_idx = dt.month - 1
                                amt = int(tx.get('amount', 0))
                                if tx.get('role') == 'business':
                                    monthly_b2b[m_idx] += amt or 2000
                                else:
                                    # Students usually 50, but we use 'amt' if it's there
                                    monthly_student_rev[m_idx] += amt or 50
                                    if u_id: accounted_uids.add(u_id)
                        except: pass

        # B. From Profiles (Fallback for active 'is_paid' users without logs)
        if isinstance(all_profiles, dict):
            for u_id, p in all_profiles.items():
                # We only consider 'is_paid' users as revenue if they didn't get free promos.
                # "SYSTEM_PROMO" is set for referrals. "gold" was set by the 2-day free script.
                receipt = p.get('last_payment_receipt', '')
                package = p.get('subscription_package', '')
                is_free_promo = ('PROMO' in receipt or 'INVITE' in receipt or package == 'gold')

                if isinstance(p, dict) and p.get('is_paid') and not is_free_promo and u_id not in accounted_uids:
                    ts = p.get('created_at')
                    m_idx = 3 # April Default
                    if ts:
                        try:
                            dt = datetime.fromisoformat(ts)
                            if dt.year == current_year: m_idx = dt.month - 1
                        except: pass
                    # If they are paid but no log, assume 50 KSH
                    monthly_student_rev[m_idx] += 50

        # C. From Ledger (B2B primary ledger)
        temp_ledger_b2b = [0] * 12
        if isinstance(ledger_data, dict):
            for tx in ledger_data.values():
                if isinstance(tx, dict) and tx.get('status') == 'Completed':
                    try:
                        amount = int(tx.get('amount', 0))
                        ts = tx.get('timestamp')
                        if ts:
                            dt = datetime.fromisoformat(ts)
                            if dt.year == current_year:
                                temp_ledger_b2b[dt.month - 1] += amount
                    except: pass
        
        # Use higher B2B source
        for i in range(12):
            monthly_b2b[i] = max(monthly_b2b[i], temp_ledger_b2b[i])

        # -------------------------------------------------------
        # HEADLINE CARD: current month totals only
        # The monthly breakdown list still shows full history.
        # -------------------------------------------------------
        current_month_idx = now.month - 1  # 0-based index
        student_revenue = monthly_student_rev[current_month_idx]
        b2b_revenue     = monthly_b2b[current_month_idx]
        total_revenue   = student_revenue + b2b_revenue

        # ------------------------------------------
        # 1.2 MANUAL OVERRIDES (current month only)
        # ------------------------------------------
        diff = 0

        # Check for Manual Overrides in Firebase
        manual_overrides = db.reference('system_settings/manual_revenue_overrides').get() or {}

        if isinstance(manual_overrides, dict) and manual_overrides.get('active'):
            # Offsets are applied to the current-month totals
            total_revenue   += int(manual_overrides.get('revenue_offset', 0))
            student_revenue += int(manual_overrides.get('student_revenue_offset', 0))

            # Map monthly overrides into the arrays for the chart & breakdown
            monthly_overrides = manual_overrides.get('monthly', {})
            if isinstance(monthly_overrides, dict):
                for m_idx_str, data in monthly_overrides.items():
                    try:
                        idx = int(m_idx_str)
                        if 0 <= idx < 12:
                            monthly_student_rev[idx] = int(data.get('student', 0))
                            monthly_b2b[idx] = int(data.get('b2b', 0))
                    except: pass

        # Prepare Monthly Data for UI & Chart
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        revenue_chart_data = [monthly_student_rev[i] + monthly_b2b[i] for i in range(12)]
        growth_chart_data = [0] * 12
        
        monthly_revenue_details = []
        for i in range(3, 12): # April to Dec
            s_rev = monthly_student_rev[i]
            b_rev = monthly_b2b[i]
            if s_rev > 0 or b_rev > 0:
                monthly_revenue_details.append({
                    'month': months[i],
                    'student': s_rev,
                    'b2b': b_rev,
                    'total': s_rev + b_rev
                })

        # ------------------------------------------
        # 1.5 TRANSACTION HISTORY (SHOW THE DATES)
        # ------------------------------------------
        all_transactions = []
        
        # Add Balance Sync Adjustment if needed to the history list
        if diff > 0:
            all_transactions.append({
                'id': 'BAL_SYNC',
                'date': datetime.now(EAT).isoformat(),
                'user': 'Account Balance Sync',
                'amount': diff,
                'type': 'Adjustment',
                'method': 'System'
            })
        
        # Collect Student Transactions from Success Logs
        if isinstance(pending_payments, dict):
            for pid, tx in pending_payments.items():
                if isinstance(tx, dict) and tx.get('status') == 'success':
                    ts = tx.get('created_at') or tx.get('timestamp')
                    u_id = tx.get('user_id')
                    u_name = "Unknown Student"
                    if u_id and isinstance(all_profiles, dict):
                        u_name = all_profiles.get(u_id, {}).get('name', 'Unknown Student')
                    
                    amt = int(tx.get('amount', 50))
                    all_transactions.append({
                        'id': pid,
                        'date': ts,
                        'user': u_name,
                        'amount': amt,
                        'type': 'Student' if tx.get('role') != 'business' else 'B2B',
                        'method': 'M-Pesa'
                    })

        # Collect B2B Ledger Transactions
        if isinstance(ledger_data, dict):
            for lid, tx in ledger_data.items():
                if isinstance(tx, dict) and tx.get('status') == 'Completed':
                    ts = tx.get('timestamp')
                    biz_id = tx.get('restaurant_id')
                    biz_name = "Unknown Venue"
                    if biz_id and isinstance(all_restaurants, dict):
                        biz_name = all_restaurants.get(biz_id, {}).get('business_name', 'Unknown Venue')
                    
                    all_transactions.append({
                        'id': lid,
                        'date': ts,
                        'user': biz_name,
                        'amount': int(tx.get('amount', 2000)),
                        'type': 'B2B',
                        'method': 'M-Pesa Ledger'
                    })

        # Sort by date (newest first)
        all_transactions.sort(key=lambda x: x.get('date', ''), reverse=True)
        recent_transactions = all_transactions[:50] # Show last 50

        # ------------------------------------------
        # 2. TRAFFIC & ENGAGEMENT METRICS (TODAY)
        # ------------------------------------------
        now = datetime.now(EAT)
        today_str = now.strftime('%Y-%m-%d')
        
        daily_traffic = 0
        chat_initiations = 0
        date_proposals = 0
        
        if isinstance(all_profiles, dict):
            for p in all_profiles.values():
                if isinstance(p, dict):
                    last_seen = p.get('last_seen', '')
                    if last_seen.startswith(today_str):
                        daily_traffic += 1
                    
        if isinstance(all_matches, dict):
            for m in all_matches.values():
                if isinstance(m, dict):
                    matched_at = m.get('matched_at', m.get('timestamp', ''))
                    if matched_at.startswith(today_str):
                        chat_initiations += 1
                    
        if isinstance(all_bookings, dict):
            for b in all_bookings.values():
                if isinstance(b, dict):
                    created_at = b.get('created_at', '')
                    if created_at.startswith(today_str):
                        date_proposals += 1

        # ------------------------------------------
        # 3. MOST POPULAR DATE VENUE
        # ------------------------------------------
        venue_counts = {}
        if isinstance(all_bookings, dict):
            for b in all_bookings.values():
                if isinstance(b, dict):
                    v_id = b.get('restaurant_id') or b.get('venue_id')
                    if v_id:
                        venue_counts[v_id] = venue_counts.get(v_id, 0) + 1
                    
        popular_venue_name = "None Yet"
        popular_venue_count = 0
        
        if venue_counts:
            top_v_id = max(venue_counts, key=venue_counts.get)
            popular_venue_count = venue_counts[top_v_id]
            v_data = all_restaurants.get(top_v_id, {}) if isinstance(all_restaurants, dict) else {}
            if not isinstance(v_data, dict): v_data = {}
            popular_venue_name = v_data.get('business_name', 'Unknown Venue')

        # Existing User Lists for UI Tabs
        unpaid_users = []
        premium_users = []
        unverified_users = []
        total_users = 0
        
        # Institution Stats Aggregation
        institution_stats = {}

        if isinstance(all_profiles, dict):
            for uid, user_data in all_profiles.items():
                if isinstance(user_data, dict):
                    total_users += 1
                    user_data['id'] = uid 
                    is_verified = user_data.get('is_verified', False)
                    has_paid = user_data.get('is_paid', False)
                    inst_name = user_data.get('institution', user_data.get('institution_name', 'Unknown'))

                    if inst_name not in institution_stats:
                        institution_stats[inst_name] = {'total': 0, 'premium': 0, 'revenue': 0}
                    
                    institution_stats[inst_name]['total'] += 1
                    if has_paid:
                        institution_stats[inst_name]['premium'] += 1
                        # Estimate revenue from premium users (assuming 50 KSH base)
                        # In a real scenario, this would sum up actual transaction records
                        institution_stats[inst_name]['revenue'] += 50 

                    if not is_verified:
                        unverified_users.append(user_data)
                    elif is_verified and not has_paid:
                        unpaid_users.append(user_data)
                    elif is_verified and has_paid:
                        premium_users.append(user_data)

        # Convert institution stats to sorted list
        inst_list = [{'name': k, **v} for k, v in institution_stats.items()]
        inst_list.sort(key=lambda x: x['total'], reverse=True)

        # Alerts, Feedback, etc.
        alerts_dict = db.reference('admin_alerts').get() or {}
        alerts = [{'alert_id': k, **v} for k, v in alerts_dict.items() if isinstance(v, dict)]
        alerts.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

        feedbacks_dict = db.reference('feedbacks').get() or {}
        suggestions = feedbacks_dict.get('suggestion', {})
        tickets = feedbacks_dict.get('ticket', {})
        
        raw_feedbacks = []
        if isinstance(suggestions, dict):
            raw_feedbacks.extend([{'id': k, 'type': 'suggestion', **v} for k, v in suggestions.items() if isinstance(v, dict)])
        if isinstance(tickets, dict):
            raw_feedbacks.extend([{'id': k, 'type': 'ticket', **v} for k, v in tickets.items() if isinstance(v, dict)])
        
        for f in raw_feedbacks:
            uid = f.get('user_id')
            if uid and isinstance(all_profiles, dict) and uid in all_profiles:
                u_profile = all_profiles[uid]
                if isinstance(u_profile, dict):
                    f['user_email'] = u_profile.get('email', 'N/A')
                    f['user_reg'] = u_profile.get('reg_no', 'N/A')
                    f['user_phone'] = u_profile.get('phone', 'N/A')
                else:
                    f['user_email'] = 'Unknown'; f['user_reg'] = 'Unknown'; f['user_phone'] = 'N/A'
            else:
                f['user_email'] = 'Unknown'; f['user_reg'] = 'Unknown'; f['user_phone'] = 'N/A'
        
        raw_feedbacks.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        feedbacks = raw_feedbacks

        call_requests_dict = db.reference('call_requests').get() or {}
        call_requests = [{'id': k, **v} for k, v in call_requests_dict.items() if isinstance(v, dict)]
        call_requests.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

        pending_businesses = [{'id': k, **v} for k, v in all_restaurants.items() if isinstance(v, dict) and not v.get('subscription_active')]

        logs_dict = db.reference('admin_audit_logs').get() or {}
        audit_logs = list(logs_dict.values()) if isinstance(logs_dict, dict) else []
        audit_logs.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        audit_logs = audit_logs[:20]

        # Fetch All Advertisements for management
        ads_dict = db.reference('active_ads').get() or {}
        all_ads = [{'id': k, **v} for k, v in ads_dict.items() if isinstance(v, dict)]
        all_ads.sort(key=lambda x: x.get('created_at', ''), reverse=True)

        # Finalize and Apply Overrides for dynamic growth
        if isinstance(manual_overrides, dict) and manual_overrides.get('active'):
            total_users += int(manual_overrides.get('users_offset', 0))

        
        # Fetch manager ledgers
        manager_ledgers = db.reference('campus_manager_ledgers').get() or {}
        
        # Fetch Survey Responses
        survey_responses_dict = db.reference('survey_responses').get() or {}
        survey_responses = [{'id': k, **v} for k, v in survey_responses_dict.items() if isinstance(v, dict)]
        survey_responses.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        # Calculate Global Analytics for Super Admin
        institution_counts = {}
        global_gender_stats = {'Male': 0, 'Female': 0, 'Other': 0}
        users_by_inst_data = {}
        current_month_prefix = datetime.now(EAT).strftime('%Y-%m')

        for uid, prof in all_profiles.items():
            if isinstance(prof, dict):
                prof_inst = prof.get('institution') or prof.get('institution_name', 'Unknown/None')
                
                # Leaderboard counts
                if prof_inst not in institution_counts:
                    institution_counts[prof_inst] = {'total': 0, 'paid': 0, 'this_month': 0, 'this_month_paid': 0}
                
                institution_counts[prof_inst]['total'] += 1
                is_paid = prof.get('is_paid', False)
                if is_paid:
                    institution_counts[prof_inst]['paid'] += 1
                
                created_at = prof.get('created_at', '')
                if created_at and str(created_at).startswith(current_month_prefix):
                    institution_counts[prof_inst]['this_month'] += 1
                    if is_paid:
                        institution_counts[prof_inst]['this_month_paid'] += 1
                        
                # Gender stats
                gender = prof.get('gender', 'N/A')
                if gender in ['Male', 'Female']:
                    global_gender_stats[gender] += 1
                else:
                    global_gender_stats['Other'] += 1
                    
                # Detailed users
                if prof_inst not in users_by_inst_data:
                    users_by_inst_data[prof_inst] = []
                users_by_inst_data[prof_inst].append({
                    'name': prof.get('name', 'N/A'),
                    'email': prof.get('email', 'N/A'),
                    'gender': gender,
                    'is_paid': is_paid
                })

        # Process Leaderboard
        global_leaderboard = [{'name': k, 'total': v['total'], 'paid': v['paid'], 'this_month': v.get('this_month', 0), 'this_month_paid': v.get('this_month_paid', 0)} for k, v in institution_counts.items()]
        max_paid = max(lb['paid'] for lb in global_leaderboard) if global_leaderboard else 0
        min_paid = min(lb['paid'] for lb in global_leaderboard) if global_leaderboard else 0
        global_leaderboard.sort(key=lambda x: (-x['paid'], str(x['name']).lower()))
        
        # Process Detailed Users
        sorted_inst_keys = sorted(users_by_inst_data.keys(), key=lambda x: (0 if 'mmust' in str(x).lower() or 'masinde' in str(x).lower() else 1, str(x).lower()))
        global_detailed_users = []
        for k in sorted_inst_keys:
            global_detailed_users.append({
                'institution': k,
                'users': users_by_inst_data[k]
            })
        
        # Process Campus Events for Super Admin Controls
        events_data = db.reference('events').get() or {}
        rsvps_all = db.reference('events_rsvps').get() or {}
        all_events = []
        if isinstance(events_data, dict):
            for eid, edata in events_data.items():
                if isinstance(edata, dict):
                    edata['id'] = eid
                    event_rsvps = rsvps_all.get(eid, {}) if isinstance(rsvps_all, dict) else {}
                    real_att = sum(1 + int(r.get('plus_ones', 0) or 0) for r in event_rsvps.values() if isinstance(r, dict)) if isinstance(event_rsvps, dict) else 0
                    edata['attendees_count'] = real_att
                    all_events.append(edata)
        elif isinstance(events_data, list):
            for idx, edata in enumerate(events_data):
                if isinstance(edata, dict):
                    eid = edata.get('id', f'evt_{idx}')
                    edata['id'] = eid
                    event_rsvps = rsvps_all.get(eid, {}) if isinstance(rsvps_all, dict) else {}
                    real_att = sum(1 + int(r.get('plus_ones', 0) or 0) for r in event_rsvps.values() if isinstance(r, dict)) if isinstance(event_rsvps, dict) else 0
                    edata['attendees_count'] = real_att
                    all_events.append(edata)
        all_events.sort(key=lambda x: x.get('created_at', 0), reverse=True)

        system_settings = db.reference('system_settings').get() or {}
        try:
            default_event_creation_fee = max(0, int(system_settings.get('event_creation_fee', 100)))
        except (ValueError, TypeError):
            default_event_creation_fee = 100

        from app.services.ladies_reward_service import get_ladies_campaign_status, get_cohort_status
        ladies_campaign_status = get_ladies_campaign_status()
        ladies_cohort_status = get_cohort_status()

        # Enrich Campus Managers with Live Earnings, Student Counts & Payout Status
        from app.payout_service import (
            get_current_month_keys,
            calculate_active_month_commission,
            resolve_payout_destination
        )
        curr_month_key, curr_month_display = get_current_month_keys()
        campus_managers_raw = get_campus_managers()
        campus_managers = []
        for mgr in campus_managers_raw:
            m_id = mgr.get('id')
            m_inst = mgr.get('institution') or 'Unknown'
            inst_norm = str(m_inst).strip().lower()
            m_total_students = sum(
                1 for p in all_profiles.values()
                if isinstance(p, dict) and str(p.get('institution') or p.get('institution_name', '')).strip().lower() == inst_norm
            )
            active_subs, comm_rate, supposed_amount, payout_phone = calculate_active_month_commission(m_id, curr_month_key)
            gross_sub_rev = active_subs * 50
            assigned_salary = int(mgr.get('assigned_salary') if mgr.get('assigned_salary') is not None else (supposed_amount or 0))
            supposed_amount = assigned_salary
            already_paid = 0
            m_ledger = manager_ledgers.get(m_id, {}) if isinstance(manager_ledgers, dict) else {}
            if isinstance(m_ledger, dict) and curr_month_key in m_ledger:
                month_entry = m_ledger[curr_month_key]
                if isinstance(month_entry, dict) and month_entry.get('status') == 'Paid':
                    already_paid = int(month_entry.get('amount', 0) or 0)
            elif isinstance(m_ledger, dict) and curr_month_display in m_ledger:
                month_entry = m_ledger[curr_month_display]
                if isinstance(month_entry, dict) and month_entry.get('status') == 'Paid':
                    already_paid = int(month_entry.get('amount', 0) or 0)

            will_get = max(0, supposed_amount - already_paid)
            payout_status = 'Paid' if (already_paid >= supposed_amount and supposed_amount > 0) else 'Pending'

            enriched = dict(mgr)
            enriched['assigned_salary'] = assigned_salary
            enriched['total_students'] = m_total_students
            enriched['active_paid_subs'] = active_subs
            enriched['commission_rate_pct'] = 0
            enriched['gross_sub_rev'] = gross_sub_rev
            enriched['supposed_to_get'] = supposed_amount
            enriched['already_paid'] = already_paid
            enriched['will_get'] = will_get
            enriched['payout_phone'] = payout_phone or mgr.get('phone') or mgr.get('payout_phone')
            enriched['payout_status'] = payout_status
            enriched['current_month_name'] = curr_month_display
            campus_managers.append(enriched)

        # Process Events Escrow Hub Data
        tickets_lookup_all = db.reference('tickets_lookup').get() or {}
        used_receipts_all = db.reference('used_mpesa_receipts').get() or {}
        pending_payouts_all = db.reference('pending_organizer_payouts').get() or {}

        auto_instant_payouts_active = system_settings.get('auto_instant_event_payouts', True)
        platform_commission_enabled = system_settings.get('platform_commission_enabled', False)
        platform_commission_pct = int(system_settings.get('platform_ticket_commission_pct', 10))

        events_escrow_list = []
        total_gross_event_sales = 0
        total_commission_earned = 0
        total_disbursed_to_organizers = 0
        total_escrow_in_till = 0

        for evt in all_events:
            eid = evt.get('id')
            e_title = evt.get('title', 'Campus Event')
            configured_pct = int(evt.get('platform_commission_pct') or platform_commission_pct)
            e_comm_pct = configured_pct if platform_commission_enabled else 0

            e_rsvps = rsvps_all.get(eid, {}) if isinstance(rsvps_all, dict) else {}
            e_tickets = [t for t in tickets_lookup_all.values() if isinstance(t, dict) and t.get('event_id') == eid]
            e_receipts = [r for r in used_receipts_all.values() if isinstance(r, dict) and r.get('event_id') == eid and r.get('ticket_code') != 'LISTING_FEE']

            gross_sales = sum(int(r.get('amount', 0) or 0) for r in e_receipts)
            if gross_sales == 0 and e_rsvps:
                gross_sales = sum(int(r.get('amount_paid', 0) or 0) for r in e_rsvps.values() if isinstance(r, dict))

            e_comm_retained = int(round(gross_sales * (e_comm_pct / 100.0)))
            net_organizer_share = max(0, gross_sales - e_comm_retained)

            e_payouts = [p for p in pending_payouts_all.values() if isinstance(p, dict) and p.get('event_id') == eid]
            disbursed_so_far = sum(int(p.get('amount', 0) or 0) for p in e_payouts if p.get('status') in ['disbursed', 'paid'])

            escrow_remaining = max(0, net_organizer_share - disbursed_so_far)

            total_gross_event_sales += gross_sales
            total_commission_earned += e_comm_retained
            total_disbursed_to_organizers += disbursed_so_far
            total_escrow_in_till += escrow_remaining

            org_dest = evt.get('organizer_phone') or evt.get('phone') or 'Not Set'
            ch, clean_dest, acc_ref, _ = resolve_payout_destination(org_dest)

            events_escrow_list.append({
                'id': eid,
                'title': e_title,
                'organizer_name': evt.get('organizer_name', 'Campus Organizer'),
                'organizer_dest': clean_dest or org_dest,
                'channel': ch or 'b2c_phone',
                'account_ref': acc_ref,
                'tickets_sold': len(e_receipts) or len(e_tickets),
                'gross_sales': gross_sales,
                'commission_pct': e_comm_pct,
                'commission_retained': e_comm_retained,
                'net_organizer_share': net_organizer_share,
                'disbursed_so_far': disbursed_so_far,
                'escrow_remaining': escrow_remaining,
                'status': 'Fully Settled' if (gross_sales > 0 and disbursed_so_far >= net_organizer_share) else ('Held in Escrow' if gross_sales > 0 else 'No Sales')
            })

        # ------------------------------------------
        # AWARDS & VOTING PLATFORM DATA
        # ------------------------------------------
        try:
            awards_settings = db.reference('awards_settings').get() or {}
            awards_contestants = db.reference('awards_contestants').get() or {}
            awards_categories = db.reference('awards_categories').get() or {}
            awards_ledger = db.reference('awards_votes_ledger').get() or {}

            awards_total_rev = 0
            awards_total_votes = 0
            awards_active_cnt = 0
            awards_pending_cnt = 0

            if isinstance(awards_ledger, dict):
                for v in awards_ledger.values():
                    if isinstance(v, dict):
                        awards_total_rev += int(v.get('amount', 0) or 0)
                        awards_total_votes += int(v.get('vote_count', 0) or 0)

            if isinstance(awards_contestants, dict):
                for c in awards_contestants.values():
                    if isinstance(c, dict):
                        if c.get('status') == 'active':
                            awards_active_cnt += 1
                            awards_total_rev += 50  # Registration fee KES
                        elif c.get('status') == 'pending_approval':
                            awards_pending_cnt += 1

            awards_metrics = {
                'total_revenue': awards_total_rev,
                'total_votes': awards_total_votes,
                'active_contestants': awards_active_cnt,
                'pending_contestants': awards_pending_cnt,
                'total_categories': len(awards_categories) if isinstance(awards_categories, dict) else 0
            }
        except Exception as awe:
            logger.warning(f"Could not load awards metrics: {awe}")
            awards_settings = {}
            awards_contestants = {}
            awards_categories = {}
            awards_ledger = {}
            awards_metrics = {
                'total_revenue': 0,
                'total_votes': 0,
                'active_contestants': 0,
                'pending_contestants': 0,
                'total_categories': 0
            }

        return render_template('super_admin.html',
                               awards_settings=awards_settings,
                               awards_contestants=awards_contestants,
                               awards_categories=awards_categories,
                               awards_ledger=awards_ledger,
                               awards_metrics=awards_metrics,
                               manager_ledgers=manager_ledgers,
                               survey_responses=survey_responses,
 
                               logged_in=True,
                               total_users=total_users,
                               total_revenue=total_revenue,
                               student_revenue=student_revenue,
                               b2b_revenue=b2b_revenue,
                               daily_traffic=daily_traffic,
                               chat_initiations=chat_initiations,
                               date_proposals=date_proposals,
                               popular_venue=popular_venue_name,
                               popular_venue_count=popular_venue_count,
                               alerts=alerts,
                               feedbacks=feedbacks,
                               call_requests=call_requests,
                               pending_businesses=pending_businesses,
                               reports=reports,
                               promo_active=promo_active,
                               force_party=force_party,
                               unpaid_users=unpaid_users,
                               premium_users=premium_users,
                               unverified_users=unverified_users,
                               audit_logs=audit_logs,
                               all_ads=all_ads,
                               all_institutions=inst_list,
                               db_institutions=get_institutions(),
                               campus_managers=campus_managers,
                               events_escrow_list=events_escrow_list,
                               total_gross_event_sales=total_gross_event_sales,
                               total_commission_earned=total_commission_earned,
                               total_disbursed_to_organizers=total_disbursed_to_organizers,
                               total_escrow_in_till=total_escrow_in_till,
                               auto_instant_payouts_active=auto_instant_payouts_active,
                               platform_commission_enabled=platform_commission_enabled,
                               platform_commission_pct=platform_commission_pct,
                               current_month_display=curr_month_display,
                               chart_labels=months,
                               revenue_chart_data=revenue_chart_data,
                               growth_chart_data=growth_chart_data,
                               monthly_revenue_details=monthly_revenue_details,
                               recent_transactions=recent_transactions,
                               manual_overrides=manual_overrides,
                               maintenance_mode=maintenance_mode,
                               merchant_fee=merchant_fee,
                               leaderboard=global_leaderboard,
                               max_paid=max_paid,
                               min_paid=min_paid,
                               detailed_users=global_detailed_users,
                               gender_stats=global_gender_stats,
                               all_events=all_events,
                               default_event_creation_fee=default_event_creation_fee,
                               ladies_campaign_status=ladies_campaign_status,
                               ladies_cohort_status=ladies_cohort_status)
    except Exception as e:
        logger.error(f"God Mode Dashboard Error: {e}")
        return f"Failed to load dashboard data: {e}", 500
    
    
@app.route('/api/admin/action', methods=['POST'])
@csrf.exempt
def admin_action():
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
    data = request.json
    action = data.get('action')
    target_id = data.get('target_id')
    
    try:
        if action == 'delete_manager':
            db.reference(f'campus_managers/{target_id}').delete()
            db.reference(f'campus_manager_ledgers/{target_id}').delete()
            db.reference('admin_audit_logs').push({
                'action': f"Deleted manager {target_id}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True})
            
        elif action == 'toggle_ambassador':
            mgr_ref = db.reference(f'campus_managers/{target_id}')
            mgr = mgr_ref.get()
            if mgr:
                current_role = mgr.get('role', 'manager')
                new_role = 'ambassador' if current_role == 'manager' else 'manager'
                mgr_ref.update({'role': new_role})
                return jsonify({'success': True, 'new_role': new_role})
            return jsonify({'success': False})
            
        elif action == 'set_manager_salary':
            target_id = data.get('target_id')
            raw_amount = data.get('amount', 0)
            try:
                salary_amount = int(float(raw_amount))
            except:
                salary_amount = 0
            db.reference(f'campus_managers/{target_id}').update({
                'assigned_salary': salary_amount
            })
            from app.payout_service import get_current_month_keys
            _, month_name = get_current_month_keys()
            curr_ledger = db.reference(f'campus_manager_ledgers/{target_id}/{month_name}').get() or {}
            if curr_ledger.get('status') != 'Paid':
                db.reference(f'campus_manager_ledgers/{target_id}/{month_name}').update({
                    'amount': salary_amount
                })
            db.reference('admin_audit_logs').push({
                'action': f"Set salary for campus manager {target_id} to KES {salary_amount}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'amount': salary_amount})

        elif action == 'add_campus_manager':
            from app.database import add_campus_manager
            name = data.get('name')
            email = data.get('email')
            institution = data.get('institution')
            assigned_salary = data.get('assigned_salary', 0)
            try:
                assigned_salary = int(float(assigned_salary))
            except:
                assigned_salary = 0
            
            # Generate random password
            raw_password = secrets.token_urlsafe(8)
            hashed_password = generate_password_hash(raw_password)
            
            if add_campus_manager(name, email, institution, hashed_password, assigned_salary):
                db.reference('admin_audit_logs').push({
                    'action': f"Added campus manager {name} for {institution}",
                    'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                    'admin_ip': request.remote_addr
                })
                
                # Try to send email
                try:
                    from app.email_service import send_manager_welcome_email
                    send_manager_welcome_email(email, name, institution, raw_password)
                except Exception as e:
                    logger.warning(f"Could not send manager welcome email: {e}")
                
                return jsonify({'success': True})
            return jsonify({'success': False, 'message': 'Failed to add campus manager'})

        elif action == 'add_institution':
            from app.database import add_institution
            name = data.get('name')
            inst_type = data.get('type')
            if add_institution(name, inst_type):
                return jsonify({'success': True})
            return jsonify({'success': False, 'message': 'Failed to add institution'})

        if action == 'toggle_ban':
            profile_ref = db.reference(f'profiles/{target_id}')
            profile = profile_ref.get()
            if not profile:
                return jsonify({'success': False, 'message': 'User not found'}), 404
            
            new_status = not profile.get('is_banned', False)
            profile_ref.update({'is_banned': new_status})
            
            # Send notification if banning
            if new_status and profile.get('email'):
                try:
                    send_admin_alert_email(
                        recipient_email=profile.get('email'),
                        recipient_name=profile.get('name', 'Student').split()[0],
                        action_type='ban',
                        reason="Violation of Community Guidelines and Terms of Service."
                    )
                except Exception as mail_err:
                    logger.warning(f"Could not send ban email: {mail_err}")
            
            db.reference('admin_audit_logs').push({
                'action': f"{'Suspended' if new_status else 'Reinstated'} user {target_id}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'message': f"User {'banned' if new_status else 'unbanned'}"})

        elif action == 'toggle_shadowban':
            profile_ref = db.reference(f'profiles/{target_id}')
            profile = profile_ref.get()
            if not profile:
                return jsonify({'success': False, 'message': 'User not found'}), 404
            
            new_status = not profile.get('is_shadowbanned', False)
            profile_ref.update({'is_shadowbanned': new_status})
            
            db.reference('admin_audit_logs').push({
                'action': f"{'Shadowbanned' if new_status else 'Un-shadowbanned'} user {target_id}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'message': f"Shadowban {'activated' if new_status else 'deactivated'}"})

        elif action == 'manual_sub_activate':
            receipt = data.get('receipt_no', 'MANUAL-OVERRIDE')
            db.reference(f'profiles/{target_id}').update({
                'is_paid': True,
                'subscription_date': datetime.now(EAT).isoformat(),
                'mpesa_receipt': receipt
            })
            db.reference('admin_audit_logs').push({
                'action': f"Manually activated subscription for {target_id} (Receipt: {receipt})",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True})

        elif action == 'merchant_action':
            sub_action = data.get('sub_action')
            if sub_action == 'suspend':
                db.reference(f'restaurants/{target_id}').update({'subscription_active': False})
            elif sub_action == 'extend':
                current = db.reference(f'restaurants/{target_id}/subscription_expiry').get()
                if current:
                    new_expiry = (datetime.fromisoformat(current) + timedelta(days=30)).isoformat()
                    db.reference(f'restaurants/{target_id}').update({'subscription_expiry': new_expiry, 'subscription_active': True})
            return jsonify({'success': True})

        elif action == 'manage_ad':
            ad_id = data.get('ad_id') or f"ad_{''.join(random.choices(string.ascii_lowercase + string.digits, k=8))}"
            db.reference(f'active_ads/{ad_id}').set({
                'type': data.get('type', 'image'),
                'media_url': data.get('media_url'),
                'click_link': data.get('click_link'),
                'display_duration': int(data.get('display_duration', 15)),
                'skip_after': int(data.get('skip_after', 5)),
                'status': 'active' if data.get('is_active', True) else 'inactive',
                'target_page': data.get('target_page', '/swipe'),
                'created_at': datetime.now(EAT).isoformat()
            })
            return jsonify({'success': True})

        elif action == 'track_ad_click':
            db.reference(f'active_ads/{target_id}/metrics/clicks').transaction(lambda curr: (curr or 0) + 1)
            return jsonify({'success': True})

        elif action == 'toggle_ad_status':
            ad_ref = db.reference(f'active_ads/{target_id}')
            ad = ad_ref.get()
            if ad:
                new_status = 'inactive' if ad.get('status') == 'active' else 'active'
                ad_ref.update({'status': new_status})
                return jsonify({'success': True, 'new_status': new_status})
            return jsonify({'success': False, 'message': 'Ad not found'}), 404

        elif action == 'delete_ad':
            db.reference(f'active_ads/{target_id}').delete()
            return jsonify({'success': True})

        elif action == 'set_daily_prompt':
            db.reference('system_settings/daily_prompt').set(data.get('prompt'))
            return jsonify({'success': True})

        elif action == 'kick_virtual_club':
            db.reference(f'party_queue/{target_id}').delete()
            # WebSockets removed: Client polling checks kicks
            return jsonify({'success': True})

        elif action == 'broadcast_message':
            db.reference('system_settings/broadcast').set({
                'message': data.get('message'),
                'priority': 'high',
                'timestamp': datetime.now(EAT).strftime("%H:%M")
            })
            return jsonify({'success': True})

        elif action == 'toggle_maintenance':
            status = data.get('status', False)
            db.reference('system_settings/maintenance_mode').set(status)
            db.reference('admin_audit_logs').push({
                'action': f"{'Enabled' if status else 'Disabled'} Maintenance Mode",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True})

        elif action == 'approve_business':
            now_eat = datetime.now(EAT)
            expiry = (now_eat + timedelta(days=30)).isoformat()
            
            db.reference(f'restaurants/{target_id}').update({
                'subscription_active': True,
                'subscription_start': now_eat.isoformat(),
                'subscription_expiry': expiry
            })
            logger.info(f"GOD_MODE: Merchant {target_id} approved.")
            
        elif action == 'dismiss_alert':
            db.reference(f'admin_alerts/{target_id}').delete()
            
        elif action == 'broadcast_survey':
            from app.email_service import send_survey_campaign_email
            profiles = db.reference('profiles').get() or {}
            count = 0
            for uid, profile in profiles.items():
                if profile.get('email'):
                    # To avoid blocking the thread on a huge user base, we could use a background task. 
                    # For now, inline execution for simplicity.
                    send_survey_campaign_email(profile['email'], profile.get('name', 'User'))
                    count += 1
            logger.info(f"Broadcasted survey to {count} users.")
            return jsonify({'success': True, 'message': f'Survey broadcasted to {count} users'})

        elif action == 'broadcast_apology':
            from app.email_service import send_apology_email
            profiles = db.reference('profiles').get() or {}
            count = 0
            for uid, profile in profiles.items():
                if isinstance(profile, dict) and profile.get('email'):
                    send_apology_email(profile['email'], profile.get('name', 'User'))
                    count += 1
            logger.info(f"Broadcasted apology email to {count} users.")
            return jsonify({'success': True, 'message': f'Apology email broadcasted to {count} users'})

        elif action == 'restart_server':
            try:
                os.makedirs('tmp', exist_ok=True)
                with open(os.path.join('tmp', 'restart.txt'), 'w') as f:
                    f.write(str(time.time()))
                logger.info("⚡ Touched tmp/restart.txt to trigger Passenger reload.")
                return jsonify({'success': True, 'message': 'Passenger server restart triggered successfully via tmp/restart.txt'})
            except Exception as se:
                return jsonify({'success': False, 'message': f'Restart failed: {se}'}), 500

        elif action == 'git_pull_and_restart':
            import subprocess
            try:
                res = subprocess.run(['git', 'pull', 'origin', 'main'], capture_output=True, text=True, timeout=30)
                os.makedirs('tmp', exist_ok=True)
                with open(os.path.join('tmp', 'restart.txt'), 'w') as f:
                    f.write(str(time.time()))
                out_msg = res.stdout.strip() or res.stderr.strip() or 'Git pulled successfully.'
                logger.info(f"🔄 Git pull executed: {out_msg}")
                return jsonify({'success': (res.returncode == 0), 'message': out_msg})
            except Exception as ge:
                return jsonify({'success': False, 'message': f'Git pull failed: {ge}'}), 500

        elif action == 'toggle_awards_campaign':
            from app.routes.awards import get_awards_settings
            sub_action = data.get('sub_action', 'start')
            settings_ref = db.reference('awards_settings')
            settings = get_awards_settings()
            now_utc = datetime.now(timezone.utc)
            updates = {'updated_at': now_utc.isoformat()}
            if sub_action == 'start':
                finale = now_utc + timedelta(days=30)
                updates['campaign_active'] = True
                updates['banner_active'] = True
                updates['phase'] = 'voting'
                updates['campaign_start_date'] = now_utc.isoformat()
                updates['finale_date'] = finale.isoformat()
                updates['blind_mode'] = False
                msg = f"Awards campaign STARTED! 1-Month voting window is LIVE until {finale.strftime('%d %b %Y')}."
            elif sub_action == 'pause':
                updates['banner_active'] = False
                msg = "Awards campaign PAUSED. Banner hidden."
            elif sub_action == 'show_banner':
                updates['banner_active'] = True
                msg = "Homepage voting banner is now VISIBLE."
            elif sub_action == 'hide_banner':
                updates['banner_active'] = False
                msg = "Homepage voting banner is now HIDDEN."
            elif sub_action == 'end':
                updates['campaign_active'] = False
                updates['banner_active'] = False
                updates['phase'] = 'closed'
                msg = "Awards campaign ENDED."
            settings_ref.update(updates)
            return jsonify({'success': True, 'message': msg, 'updates': updates})

        elif action == 'toggle_awards_blind_mode':
            curr = db.reference('awards_settings/blind_mode').get() or False
            new_val = not curr
            db.reference('awards_settings/blind_mode').set(new_val)
            status_str = "FROZEN (Blind Mode Active)" if new_val else "UNFROZEN (Public Totals Visible)"
            return jsonify({'success': True, 'blind_mode': new_val, 'message': f"Vote counts are now {status_str}."})

        elif action == 'approve_awards_contestant':
            c_id = data.get('contestant_id')
            c_status = data.get('status', 'active')
            if c_id:
                db.reference(f'awards_contestants/{c_id}/status').set(c_status)
                if c_status == 'active' and not str(c_id).startswith('mock_'):
                    try:
                        from app.routes.awards import purge_mock_contestants
                        purge_mock_contestants()
                    except Exception as p_err:
                        logger.warning(f"Could not purge mock contestants: {p_err}")
                return jsonify({'success': True, 'message': f"Contestant status updated to {c_status}."})
            return jsonify({'success': False, 'message': "Contestant ID required"}), 400

        elif action == 'delete_awards_contestant':
            c_id = data.get('contestant_id')
            if c_id:
                db.reference(f'awards_contestants/{c_id}').delete()
                return jsonify({'success': True, 'message': f"Contestant {c_id} deleted."})
            return jsonify({'success': False, 'message': "Contestant ID required"}), 400

        elif action == 'add_awards_category':
            from app.routes.awards import sanitize_input
            cat_name = sanitize_input(data.get('name', ''))
            cat_icon = sanitize_input(data.get('icon', '🏆'))
            cat_desc = sanitize_input(data.get('desc', ''))
            if not cat_name:
                return jsonify({'success': False, 'message': 'Category name required'}), 400
            clean_id = 'cat_' + re.sub(r'[^a-z0-9_]', '', cat_name.lower().replace(' ', '_'))
            db.reference(f'awards_categories/{clean_id}').set({
                'name': cat_name,
                'icon': cat_icon,
                'desc': cat_desc,
                'status': 'active',
                'created_at': datetime.now(timezone.utc).isoformat()
            })
            return jsonify({'success': True, 'message': f"Category '{cat_name}' added successfully."})

        elif action == 'delete_awards_category':
            from app.routes.awards import sanitize_input
            cat_id = sanitize_input(data.get('category_id', ''))
            if not cat_id:
                return jsonify({'success': False, 'message': 'Category ID required'}), 400
            db.reference(f'awards_categories/{cat_id}').delete()
            return jsonify({'success': True, 'message': f"Category '{cat_id}' removed successfully."})

        elif action == 'launch_ladies_campaign':
            from app.services.ladies_reward_service import dispatch_ladies_launch_campaign
            res = dispatch_ladies_launch_campaign(
                admin_name="Super Admin",
                push_fn=send_push_notification
            )
            return jsonify(res)
            
        elif action == 'resolve_feedback':
            feedback_type = data.get('alert_id') # Stored type in alert_id variable from JS
            if feedback_type and target_id:
                db.reference(f'feedbacks/{feedback_type}/{target_id}').delete()
                
        elif action == 'resolve_call':
            if target_id:
                db.reference(f'call_requests/{target_id}').delete()

        elif action == 'save_revenue_overrides':
            # Calculate current REAL stats to determine the needed offsets
            real_stats = get_real_system_stats()
            
            target_total = int(data.get('total_revenue', 0))
            target_student = int(data.get('student_revenue', 0))
            target_users = int(data.get('total_users', 0))
            
            overrides = {
                'active': True,
                'revenue_offset': target_total - real_stats['total_revenue'],
                'student_revenue_offset': target_student - real_stats['student_revenue'],
                'users_offset': target_users - real_stats['total_users'],
                'monthly': {
                    '3': { # April
                        'student': int(data.get('apr_student', 0)),
                        'b2b': 0
                    },
                    '4': { # May
                        'student': int(data.get('may_student', 0)),
                        'b2b': 0
                    }
                }
            }
            db.reference('system_settings/manual_revenue_overrides').set(overrides)
            # 📜 AUDIT LOG
            db.reference('admin_audit_logs').push({
                'action': f"Manually corrected baselines: Total Revenue {target_total} KSH, Total Users {target_users}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })

        elif action == 'reset_revenue_overrides':
            db.reference('system_settings/manual_revenue_overrides/active').set(False)
            # 📜 AUDIT LOG
            db.reference('admin_audit_logs').push({
                'action': "Reset revenue calculations to automatic mode.",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })

        elif action == 'mark_premium':
            if target_id:
                db.reference(f'profiles/{target_id}').update({'is_paid': True})
                # 📜 AUDIT LOG
                log_ref = db.reference('admin_audit_logs').push()
                log_ref.set({
                    'action': f"Manually granted Premium to user: {target_id}",
                    'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                    'admin_ip': request.remote_addr
                })
                
        elif action == 'toggle_promo':
            current_status = db.reference('system_settings/new_user_promo').get()
            new_status = not current_status
            db.reference('system_settings/new_user_promo').set(new_status)
            return jsonify({'success': True, 'new_status': new_status})

        elif action == 'toggle_party_override':
            current_status = db.reference('system_settings/force_party').get()
            new_status = not current_status
            db.reference('system_settings/force_party').set(new_status)
            return jsonify({'success': True, 'new_status': new_status})
            
        elif action == 'set_merchant_fee':
            new_fee = data.get('fee', 0)
            db.reference('system_settings/merchant_fee').set(int(new_fee))
            return jsonify({'success': True, 'message': f'Merchant fee updated to {new_fee}'})

        elif action == 'delete_event':
            event_ref = db.reference(f'events/{target_id}')
            event = event_ref.get()
            title = event.get('title', target_id) if isinstance(event, dict) else target_id
            event_ref.delete()
            db.reference(f'events_rsvps/{target_id}').delete()
            db.reference(f'event_tickets/{target_id}').delete()
            db.reference('admin_audit_logs').push({
                'action': f"Deleted event '{title}' ({target_id})",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'message': f"Event '{title}' deleted."})

        elif action == 'update_event_fee':
            fee = max(0, int(data.get('creation_fee', 0)))
            event_ref = db.reference(f'events/{target_id}')
            event = event_ref.get()
            title = event.get('title', target_id) if isinstance(event, dict) else target_id
            event_ref.update({
                'creation_fee': fee,
                'maintenance_fee_paid': True
            })
            db.reference('admin_audit_logs').push({
                'action': f"Updated creation fee for event '{title}' to {fee} KES {'(FREE)' if fee == 0 else ''}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'creation_fee': fee, 'is_free': (fee == 0)})

        elif action == 'update_event_ticket':
            ticket_price = max(0, int(data.get('ticket_price', 0)))
            event_ref = db.reference(f'events/{target_id}')
            event = event_ref.get()
            title = event.get('title', target_id) if isinstance(event, dict) else target_id
            if ticket_price == 0:
                update_data = {'price': 0, 'price_type': 'free', 'price_display': 'Free Admission'}
            else:
                update_data = {'price': ticket_price, 'price_type': 'paid', 'price_display': f"{ticket_price} KES"}
            event_ref.update(update_data)
            db.reference('admin_audit_logs').push({
                'action': f"Updated admission ticket price for event '{title}' to {update_data['price_display']}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'price_display': update_data['price_display'], 'is_free': (ticket_price == 0)})

        elif action == 'set_default_creation_fee':
            default_fee = max(0, int(data.get('fee', 0)))
            db.reference('system_settings/event_creation_fee').set(default_fee)
            db.reference('admin_audit_logs').push({
                'action': f"Set global default event creation fee to {default_fee} KES {'(FREE)' if default_fee == 0 else ''}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'fee': default_fee, 'is_free': (default_fee == 0)})

        elif action == 'disburse_event_payout':
            from app.payout_service import disburse_event_organizer_payouts_now
            res = disburse_event_organizer_payouts_now(target_id)
            db.reference('admin_audit_logs').push({
                'action': f"Admin manually verified & triggered net payout for event {target_id}. Disbursed: KES {res.get('total_amount', 0)} ({res.get('disbursed_count', 0)} tickets)",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify(res)

        elif action == 'disburse_manager_salary':
            from app.payout_service import disburse_monthly_salaries
            month_key = data.get('month')
            custom_amount = data.get('amount')
            if custom_amount is not None:
                try:
                    custom_amount = int(float(custom_amount))
                except:
                    custom_amount = None
            res = disburse_monthly_salaries(month_key=month_key, force=True, target_manager_id=target_id, custom_amount=custom_amount)
            db.reference('admin_audit_logs').push({
                'action': f"Admin disbursed salary for manager {target_id} anytime (amount: {custom_amount or 'assigned'})",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify(res)

        elif action == 'toggle_instant_payouts':
            curr = db.reference('system_settings/auto_instant_event_payouts').get()
            if curr is None:
                curr = True
            new_val = not curr
            db.reference('system_settings/auto_instant_event_payouts').set(new_val)
            db.reference('admin_audit_logs').push({
                'action': f"Toggled automatic instant event payouts: {'ENABLED (Instant B2C Active)' if new_val else 'DISABLED (Admin Escrow Manual Verification)'}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'auto_instant_event_payouts': new_val})

        elif action == 'toggle_commission_enabled':
            curr = db.reference('system_settings/platform_commission_enabled').get()
            if curr is None:
                curr = False
            new_val = not curr
            db.reference('system_settings/platform_commission_enabled').set(new_val)
            comm_pct = int(db.reference('system_settings/platform_ticket_commission_pct').get() or 10)
            db.reference('admin_audit_logs').push({
                'action': f"Toggled platform ticket commission: {'ENABLED (' + str(comm_pct) + '% retained in Till)' if new_val else 'DISABLED (0% retained - 100% to organizer)'}",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'platform_commission_enabled': new_val, 'commission_pct': comm_pct})

        elif action == 'set_platform_commission':
            comm = max(0, min(100, int(data.get('commission_pct', 10))))
            db.reference('system_settings/platform_ticket_commission_pct').set(comm)
            db.reference('admin_audit_logs').push({
                'action': f"Set platform ticket commission to {comm}%",
                'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
                'admin_ip': request.remote_addr
            })
            return jsonify({'success': True, 'commission_pct': comm})
            
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Admin Action Error ({action}): {e}")
        return jsonify({'success': False, 'message': "Internal server error."}), 500

@app.route('/api/admin/events/<event_id>/disburse-payout', methods=['POST'])
@csrf.exempt
def admin_disburse_event_payout(event_id):
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    try:
        from app.payout_service import disburse_event_organizer_payouts_now
        res = disburse_event_organizer_payouts_now(event_id)
        db.reference('admin_audit_logs').push({
            'action': f"Verified & disbursed net payout for event {event_id}. Total: KES {res.get('total_amount', 0)} ({res.get('disbursed_count', 0)} tickets)",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        return jsonify(res)
    except Exception as e:
        logger.error(f"Error disbursing event payout for {event_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/managers/send-monthly-statements', methods=['POST'])
@csrf.exempt
def admin_send_manager_monthly_statements():
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    try:
        from app.payout_service import dispatch_all_manager_month_end_emails
        data = request.json if request.is_json else request.form
        month_key = data.get('month')
        res = dispatch_all_manager_month_end_emails(month_key=month_key)
        db.reference('admin_audit_logs').push({
            'action': f"Dispatched month-end forecast statements to {res.get('dispatched_count', 0)} managers for {res.get('month')}",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        return jsonify(res)
    except Exception as e:
        logger.error(f"Error sending monthly statements: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/managers/<manager_id>/disburse-salary', methods=['POST'])
@csrf.exempt
def admin_disburse_manager_salary(manager_id):
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    try:
        from app.payout_service import disburse_monthly_salaries
        req_data = request.json if request.is_json else request.form
        month_key = req_data.get('month') if req_data else None
        custom_amount = req_data.get('amount') if req_data else None
        if custom_amount is not None:
            try:
                custom_amount = int(float(custom_amount))
            except:
                custom_amount = None
        res = disburse_monthly_salaries(month_key=month_key, force=True, target_manager_id=manager_id, custom_amount=custom_amount)
        db.reference('admin_audit_logs').push({
            'action': f"Verified & disbursed salary for manager {manager_id} anytime",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        return jsonify(res)
    except Exception as e:
        logger.error(f"Error disbursing manager salary for {manager_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/settings/toggle-instant-payouts', methods=['POST'])
@csrf.exempt
def admin_toggle_instant_payouts_route():
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    try:
        curr = db.reference('system_settings/auto_instant_event_payouts').get()
        if curr is None:
            curr = True
        new_val = not curr
        db.reference('system_settings/auto_instant_event_payouts').set(new_val)
        db.reference('admin_audit_logs').push({
            'action': f"Toggled automatic instant event payouts: {'ENABLED' if new_val else 'DISABLED'}",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        return jsonify({'success': True, 'auto_instant_event_payouts': new_val})
    except Exception as e:
        logger.error(f"Error toggling instant payouts: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/settings/toggle-commission-enabled', methods=['POST'])
@csrf.exempt
def admin_toggle_commission_enabled_route():
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    try:
        curr = db.reference('system_settings/platform_commission_enabled').get()
        if curr is None:
            curr = False
        new_val = not curr
        db.reference('system_settings/platform_commission_enabled').set(new_val)
        comm_pct = int(db.reference('system_settings/platform_ticket_commission_pct').get() or 10)
        db.reference('admin_audit_logs').push({
            'action': f"Toggled platform ticket commission: {'ENABLED (' + str(comm_pct) + '% retained in Till)' if new_val else 'DISABLED (0% retained - 100% to organizer)'}",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        return jsonify({'success': True, 'platform_commission_enabled': new_val, 'commission_pct': comm_pct})
    except Exception as e:
        logger.error(f"Error toggling platform commission enabled: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/settings/set-platform-commission', methods=['POST'])
@csrf.exempt
def admin_set_platform_commission_route():
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    try:
        data = request.json if request.is_json else request.form
        comm = max(0, min(100, int(data.get('commission_pct', 10))))
        db.reference('system_settings/platform_ticket_commission_pct').set(comm)
        db.reference('admin_audit_logs').push({
            'action': f"Set platform ticket commission to {comm}%",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        return jsonify({'success': True, 'commission_pct': comm})
    except Exception as e:
        logger.error(f"Error setting platform commission: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/broadcast', methods=['POST'])
def admin_broadcast():
    """Endpoint to trigger targeted or mass emails to users."""
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
    # Handle both JSON and Multipart (for attachments)
    if request.is_json:
        data = request.json
    else:
        data = request.form

    target_group = data.get('target_group', 'all')
    specific_email = data.get('specific_email', '').strip().lower()
    target_class = data.get('target_class', '').strip().upper()
    subject = data.get('subject')
    message = data.get('message')
    
    if not subject or not message:
        return jsonify({'success': False, 'message': 'Subject and message required.'}), 400
        
    # Process Attachments
    attachments = []
    # Support multiple files from the 'attachments' field
    files = request.files.getlist('attachments')
    
    # Also support legacy keys just in case
    for key in ['image', 'audio', 'video']:
        legacy_files = request.files.getlist(key)
        files.extend(legacy_files)

    for file in files:
        if file and file.filename:
            try:
                content = file.read()
                if content:
                    attachments.append({
                        'filename': file.filename,
                        'content': content
                    })
            except Exception as e:
                logger.error(f"Error reading attachment: {e}")

    try:
        all_profiles = db.reference('profiles').get() or {}
        
        def dispatch_emails(profiles, target, specific_mail, specific_cls, subj, msg, atts):
            success_count = 0
            for uid, user_data in profiles.items():
                if not isinstance(user_data, dict):
                    continue
                    
                email = user_data.get('email')
                if not email:
                    continue

                name = user_data.get('name', 'Student').split(' ')[0]
                is_verified = user_data.get('is_verified', False)
                is_paid = user_data.get('is_paid', False)
                user_class = user_data.get('class_code', '').upper()

                should_send = False
                
                if target == 'all':
                    should_send = True
                elif target == 'class' and user_class == specific_cls:
                    should_send = True
                elif target == 'premium' and is_verified and is_paid:
                    should_send = True
                elif target == 'verified_unpaid' and is_verified and not is_paid:
                    should_send = True
                elif target == 'unverified' and not is_verified:
                    should_send = True
                elif target == 'specific' and email.lower() == specific_mail:
                    should_send = True

                if should_send:
                    try:
                        send_broadcast_email(email, name, subj, msg, attachments=atts)
                        success_count += 1
                        
                        # Apply a delay between each individual email to prevent rapid-fire sending
                        time.sleep(2)
                            
                    except Exception as email_err:
                        # Log the specific email that failed
                        logger.error(f"Failed sending to {email}: {email_err}")
            
            logger.info(f"GOD_MODE: Broadcast '{subj}' sent to {success_count} users in group '{target}'.")

        # Process in background so the UI doesn't freeze
        threading.Thread(target=dispatch_emails, args=(all_profiles, target_group, specific_email, target_class, subject, message, attachments), daemon=True).start()
        
        return jsonify({'success': True, 'message': 'Broadcast queued for dispatch.'})
        
    except Exception as e:
        logger.error(f"Broadcast Error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/search_user', methods=['POST'])
def admin_search_user():
    """Allows Super Admin to lookup users by ID/Reg Number, Email, OR view specific filtered lists."""
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
    data = request.json
    query = data.get('query', '').strip().lower()
    
    if not query:
        return jsonify({'success': False, 'message': 'Search query required'}), 400
        
    try:
        all_profiles = db.reference('profiles').get() or {}
        matched_users = []
        
        safe_query_id = query.upper().replace('/', '_')
        
        for user_id, user_data in all_profiles.items():
            if isinstance(user_data, dict):
                user_email = user_data.get('email', '').lower()
                is_verified = user_data.get('is_verified', False)
                has_paid = user_data.get('is_paid', False)
                
                matches = False
                
                if query == 'all':
                    matches = True
                elif query == 'filter:unverified':
                    matches = not is_verified
                elif query == 'filter:unpaid':
                    matches = is_verified and not has_paid
                elif query == 'filter:paid':
                    matches = is_verified and has_paid
                elif user_id.upper() == safe_query_id or query in user_email:
                    matches = True
                
                if matches:
                    safe_data = {
                        'name': user_data.get('name', 'Unknown'),
                        'reg_number': user_data.get('reg_number', user_id),
                        'email': user_data.get('email', 'No email'),
                        'is_verified': is_verified,
                        'has_paid': has_paid,
                        'is_locked': user_data.get('is_locked', False)
                    }
                    matched_users.append(safe_data)

        if matched_users:
            matched_users.sort(key=lambda x: x.get('email', ''))
            return jsonify({'success': True, 'users': matched_users})
        else:
            return jsonify({'success': False, 'message': 'No users found matching that criteria.'})
            
    except Exception as e:
        logger.error(f"Search User Error: {e}")
        return jsonify({'success': False, 'message': 'Database error'}), 500


@app.route('/admin/ledger')
def admin_ledger():
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))

    try:
        profiles = db.reference('profiles').get() or {}
        restaurants = db.reference('restaurants').get() or {}
        
        paid_students = [p for p in profiles.values() if isinstance(p, dict) and p.get('is_paid')]
        student_revenue = len(paid_students) * 20
        
        active_merchants = [r for r in restaurants.values() if isinstance(r, dict) and r.get('subscription_active')]
        merchant_revenue = len(active_merchants) * 2000
        
        total_revenue = student_revenue + merchant_revenue
        current_time_eat = datetime.now(EAT).strftime("%Y-%m-%d %H:%M EAT")

        return render_template('admin_ledger.html', 
                               student_count=len(paid_students),
                               student_rev=student_revenue,
                               merchant_count=len(active_merchants),
                               merchant_rev=merchant_revenue,
                               total_rev=total_revenue,
                               last_updated=current_time_eat)
    except Exception as e:
        logger.error(f"Admin Ledger Error: {e}")
        return "Failed to load ledger.", 500


@app.route('/admin/logout')
def admin_logout():
    session.pop('is_super_admin', None)
    flash("Securely logged out of Command Center.", "info")
    return redirect(url_for('super_admin'))


# ==========================================
# 🚨 DESTRUCTIVE MASS ACTIONS (HTML FORMS)
# ==========================================

@app.route('/admin/delete_user/<user_id>', methods=['POST'])
def admin_delete_user(user_id):
    """Deletes a single specific user from the database."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
        
    try:
        db.reference(f'profiles/{user_id}').delete()
        flash(f"User {user_id} permanently deleted.", "success")
    except Exception as e:
        flash(f"Error deleting user: {str(e)}", "error")
        
    return redirect(url_for('super_admin'))

@app.route('/admin/delete_class', methods=['POST'])
def admin_delete_class():
    """Wipes all users belonging to a specific class code."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
        
    class_code = request.form.get('class_code', '').strip().upper()
    
    if not class_code:
        flash("You must specify a class code.", "error")
        return redirect(url_for('super_admin'))
        
    try:
        # Fetch all profiles and filter manually to avoid complex indexing
        profiles_ref = db.reference('profiles').get() or {}
        deleted_count = 0
        
        for uid, user_data in profiles_ref.items():
            if isinstance(user_data, dict) and user_data.get('class_code', '').upper() == class_code:
                db.reference(f'profiles/{uid}').delete()
                deleted_count += 1
                
        flash(f"Purge complete: {deleted_count} users in class {class_code} have been deleted.", "warning")
    except Exception as e:
        logger.error(f"Class Purge Error: {e}")
        flash("An error occurred while deleting the class.", "error")
        
    return redirect(url_for('super_admin'))

@app.route('/admin/delete_all', methods=['POST'])
def admin_delete_all_users():
    """THE NUCLEAR OPTION: Wipes the entire student database."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
    
    # ⚠️ ACTIVATED NUCLEAR OPTION ⚠️
    try:
        db.reference('profiles').delete()
        flash("NUCLEAR OPTION EXECUTED: Entire user database wiped clean.", "danger")
    except Exception as e:
        logger.error(f"Nuclear Option Error: {e}")
        flash("System failed to execute full wipe.", "error")
        
    return redirect(url_for('super_admin'))


# ==========================================
# 🎉 EVENT MANAGEMENT & CONTROLS (SUPER ADMIN)
# ==========================================

@app.route('/admin/delete_event/<event_id>', methods=['POST'])
def admin_delete_event(event_id):
    """Permanently deletes an event along with RSVPs and ticket entries."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
        
    try:
        event_ref = db.reference(f'events/{event_id}')
        event = event_ref.get()
        title = event.get('title', event_id) if isinstance(event, dict) else event_id
        
        event_ref.delete()
        db.reference(f'events_rsvps/{event_id}').delete()
        db.reference(f'event_tickets/{event_id}').delete()
        
        db.reference('admin_audit_logs').push({
            'action': f"Deleted event '{title}' ({event_id})",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        flash(f"Event '{title}' deleted successfully.", "success")
    except Exception as e:
        logger.error(f"Delete Event Error: {e}")
        flash(f"Error deleting event: {str(e)}", "error")
        
    return redirect(url_for('super_admin'))


@app.route('/admin/update_event_fee/<event_id>', methods=['POST'])
def admin_update_event_fee(event_id):
    """Controls the organizer creation/maintenance fee for an event (set 0 to make free)."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
        
    try:
        raw_fee = request.form.get('creation_fee', '0').strip()
        fee = max(0, int(raw_fee))
        
        event_ref = db.reference(f'events/{event_id}')
        event = event_ref.get()
        title = event.get('title', event_id) if isinstance(event, dict) else event_id
        
        event_ref.update({
            'creation_fee': fee,
            'maintenance_fee_paid': True
        })
        
        db.reference('admin_audit_logs').push({
            'action': f"Updated creation fee for event '{title}' ({event_id}) to {fee} KES {'(FREE)' if fee == 0 else ''}",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        
        if fee == 0:
            flash(f"Creation fee for '{title}' waived! Event is now FREE for the organizer.", "success")
        else:
            flash(f"Creation fee for '{title}' updated to {fee} KES.", "success")
    except Exception as e:
        logger.error(f"Update Event Fee Error: {e}")
        flash(f"Failed to update creation fee: {e}", "error")
        
    return redirect(url_for('super_admin'))


@app.route('/admin/update_event_ticket/<event_id>', methods=['POST'])
def admin_update_event_ticket(event_id):
    """Controls attendee admission ticket price for an event (set 0 for Free Admission)."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
        
    try:
        raw_price = request.form.get('ticket_price', '0').strip()
        price = max(0, int(raw_price))
        
        event_ref = db.reference(f'events/{event_id}')
        event = event_ref.get()
        title = event.get('title', event_id) if isinstance(event, dict) else event_id
        
        if price == 0:
            update_data = {
                'price': 0,
                'price_type': 'free',
                'price_display': 'Free Admission'
            }
        else:
            update_data = {
                'price': price,
                'price_type': 'paid',
                'price_display': f"{price} KES"
            }
        event_ref.update(update_data)
        
        db.reference('admin_audit_logs').push({
            'action': f"Updated ticket price for event '{title}' to {update_data['price_display']}",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        flash(f"Ticket admission price for '{title}' set to {update_data['price_display']}.", "success")
    except Exception as e:
        logger.error(f"Update Event Ticket Error: {e}")
        flash(f"Failed to update ticket price: {e}", "error")
        
    return redirect(url_for('super_admin'))


@app.route('/admin/set_default_creation_fee', methods=['POST'])
def admin_set_default_creation_fee():
    """Sets global platform default event creation fee (set 0 to make all event creation free)."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))
        
    try:
        raw_fee = request.form.get('default_fee', '100').strip()
        fee = max(0, int(raw_fee))
        
        db.reference('system_settings/event_creation_fee').set(fee)
        
        db.reference('admin_audit_logs').push({
            'action': f"Set global default event creation fee to {fee} KES {'(FREE)' if fee == 0 else ''}",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })
        if fee == 0:
            flash("Global event creation fee is now WAIVED! Organizers can post events for free.", "success")
        else:
            flash(f"Global default event creation fee set to {fee} KES.", "success")
    except Exception as e:
        logger.error(f"Set Default Creation Fee Error: {e}")
        flash(f"Failed to update global event fee: {e}", "error")
        
    return redirect(url_for('super_admin'))

import io
import csv
from flask import Response

# ==========================================
# 🚀 ENTERPRISE ADMIN FEATURES
# ==========================================

@app.route('/admin/export_csv')
def admin_export_csv():
    """Generates an Excel-compatible CSV file of users based on their status."""
    if not session.get('is_super_admin'):
        return redirect(url_for('home'))

    list_type = request.args.get('type', 'all')
    all_profiles = db.reference('profiles').get() or {}

    # Setup CSV writing in memory
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['User ID', 'Full Name', 'Email Address', 'Class Code', 'Account Status'])

    for uid, user in all_profiles.items():
        if not isinstance(user, dict):
            continue

        is_verified = user.get('is_verified', False)
        is_paid = user.get('is_paid', False)

        # Filter based on what tab the admin clicked "Export" on
        if list_type == 'unverified' and is_verified: continue
        if list_type == 'unpaid' and (not is_verified or is_paid): continue
        if list_type == 'premium' and not is_paid: continue

        # Determine readable status
        if is_paid:
            status = "Premium"
        elif is_verified:
            status = "Verified (Unpaid)"
        else:
            status = "Unverified"

        cw.writerow([
            uid,
            user.get('name', 'Unknown'),
            user.get('email', 'No Email'),
            user.get('class_code', 'N/A'),
            status
        ])

    output = si.getvalue()
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename=mmust_users_{list_type}.csv"}
    )

@app.route('/api/get_active_ad', methods=['GET'])
def get_active_ad():
    """Fetches an active advertisement for the skippable ad system."""
    try:
        ads_ref = db.reference('active_ads')
        ads = ads_ref.order_by_child('status').equal_to('active').get()
        
        if ads:
            # For simplicity, we take the first one or randomize
            ad_key = random.choice(list(ads.keys()))
            ad_data = ads[ad_key]
            ad_data['id'] = ad_key
            return jsonify({"success": True, "ad": ad_data})
            
        return jsonify({"success": False, "message": "No active ads"})
    except Exception as e:
        logger.error(f"Ad Fetch Error: {e}")
        return jsonify({"success": False}), 500


@app.route('/api/admin/upload_media', methods=['POST'])
def admin_upload_media():
    """Handles file uploads for advertisements and system assets."""
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403

    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'}), 400
    
    file = request.files['file']
    folder = request.form.get('folder', 'ads')
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'}), 400

    try:
        from app.database import storage
        # Generate a unique filename to prevent collisions
        import uuid
        ext = os.path.splitext(file.filename)[1]
        unique_filename = f"{folder}/{uuid.uuid4()}{ext}"
        
        # Upload to Firebase Storage
        blob = storage.bucket().blob(unique_filename)
        blob.upload_from_file(file, content_type=file.content_type)
        blob.make_public()
        
        return jsonify({
            'success': True, 
            'url': blob.public_url,
            'filename': file.filename
        })
    except Exception as e:
        logger.error(f"Media Upload Error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/admin/bulk_action', methods=['POST'])
def admin_bulk_action():
    """Handles executing a single action across dozens of selected items at once."""
    if not session.get('is_super_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403

    data = request.json
    action = data.get('action')
    item_ids = data.get('item_ids', [])

    if not item_ids:
        return jsonify({'success': False, 'message': 'No items selected.'})

    try:
        for item_id in item_ids:
            if action == 'delete_users':
                db.reference(f'profiles/{item_id}').delete()
            elif action == 'mark_premium':
                db.reference(f'profiles/{item_id}').update({'is_paid': True})
            elif action == 'dismiss_alerts':
                db.reference(f'admin_alerts/{item_id}').delete()
            elif action == 'approve_biz':
                now_eat = datetime.now(EAT)
                expiry = (now_eat + timedelta(days=30)).isoformat()
                db.reference(f'restaurants/{item_id}').update({
                    'subscription_active': True,
                    'subscription_start': now_eat.isoformat(),
                    'subscription_expiry': expiry
                })

        # 📜 SECURE AUDIT LOG
        # Records who did what, and when.
        log_ref = db.reference('admin_audit_logs').push()
        log_ref.set({
            'action': f"Executed Bulk Action: '{action}' on {len(item_ids)} items.",
            'timestamp': datetime.now(EAT).strftime("%Y-%m-%d %H:%M:%S EAT"),
            'admin_ip': request.remote_addr
        })

        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Bulk Action Error: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/admin/load_more')
def admin_load_more():
    """Server-side pagination endpoint to prevent browser freezing with 5,000+ users."""
    if not session.get('is_super_admin'):
        return jsonify({'success': False}), 403
        
    list_type = request.args.get('type')
    offset = int(request.args.get('offset', 50))
    
    # NOTE: To fully implement this, you slice the dictionary here and return an HTML string.
    # For now, we return 'has_more: False' to hide the button so it doesn't throw a 404 error.
    return jsonify({'success': True, 'html': '', 'has_more': False})


# ==========================================
# API ENDPOINTS (SWIPE, PAYMENTS, NOTIFICATIONS)
# ==========================================
def ai_wingman_match_intro(user_id, partner_profile):
    """AI Wingman analyzes the match and sends the user a tip on how to start the chat."""
    try:
        partner_name = partner_profile.get('name', 'your match').split(' ')[0]
        partner_bio = partner_profile.get('bio', 'No bio provided.')
        
        # Craft a prompt for the Wingman
        prompt = (
            f"I just matched with {partner_name}. Their bio says: '{partner_bio}'. "
            f"Give me one short, funny, and clever opening line I can use. "
            f"Make it relevant to their bio. Keep it to one sentence."
        )
        
        # Get AI response
        ai_tip = get_ai_companion_response(prompt)
        
        # Format the system message
        wingman_msg = f"🕶️ **WINGMAN TIP:** You and {partner_name} are a great match! Try this opener: \"{ai_tip}\""
        
        # Save this as a message from the AI_COMPANION to the user
        save_chat_message('AI_COMPANION', user_id, wingman_msg, msg_type='text')
        
        # Emit it live so it pops up in their UI if they are looking at matches
        # WebSockets removed: Messages are synced via Firebase automatically
        
    except Exception as e:
        logger.error(f"Wingman Match Intro Error: {e}")
        
@app.route('/api/save_subscription', methods=['POST'])
@csrf.exempt
def save_subscription():
    if 'user_id' not in session:
        return jsonify({"status": "error", "message": "Unauthorized"}), 401

    subscription_data = request.json or {}
    user_id = session.get('user_id')

    if not subscription_data or 'endpoint' not in subscription_data:
        return jsonify({"status": "error", "message": "Invalid subscription payload"}), 400

    try:
        endpoint_hash = hashlib.sha256(str(subscription_data['endpoint']).encode('utf-8')).hexdigest()[:16]
        subscription_data['updated_at'] = datetime.now(EAT).isoformat()
        db.reference(f'push_subscriptions/{user_id}/{endpoint_hash}').set(subscription_data)
        db.reference(f'push_subscriptions/{user_id}/current').set(subscription_data)
        return jsonify({"status": "success", "message": "Subscription saved to Firebase"})
    except Exception as e:
        logger.error(f"Error saving subscription: {e}")
        return jsonify({"status": "error", "message": "Database error"}), 500

@app.route('/api/end_date', methods=['POST'])
def end_date():
    if 'user_id' not in session: 
        return jsonify({'error': 'Unauthorized'}), 403
    
    user_id = session.get('user_id')
    partner_id = request.json.get('partner_id')
    
    if terminate_connection(user_id, partner_id):
        flash("Date terminated. All data and chats have been securely deleted.", "success")
        return jsonify({'success': True})
    return jsonify({'success': False}), 500

# ==========================================
# M-PESA B2C: STUDENT SUBSCRIPTIONS
# ==========================================
import pytz
from datetime import datetime, timedelta
from flask import request, session, jsonify
import logging

logger = logging.getLogger(__name__)

# Use UTC+3 offset (NOT pytz) so datetime.now(EAT) works correctly everywhere
# pytz requires localize() which breaks in many places - fixed here
EAT = timezone(timedelta(hours=3))  # same as Africa/Nairobi offset

@app.route('/paywall', methods=['GET'])
@app.route('/renew', methods=['GET'])
@app.route('/upgrade', methods=['GET'])
def paywall_view():
    """Renders the subscription renewal & package selection paywall."""
    user_id = session.get('user_id')
    user_phone = ''
    user_data = {}
    if user_id:
        user_data = db.reference(f'profiles/{user_id}').get() or {}
        if isinstance(user_data, dict):
            user_phone = user_data.get('phone', '')

    checkout_id = session.get('checkout_id') or (user_data.get('active_checkout_id') if isinstance(user_data, dict) else None)
    
    return render_template(
        'paywall.html',
        amount=50,
        phone=user_phone,
        checkout_id=checkout_id,
        intent='student_renew'
    )


@app.route('/api/pay_student_fee', methods=['POST'])
@limiter.limit("3 per minute") # 🚨 STOPS STK PUSH SPAM
def pay_student_fee():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized. Please log in.'}), 401

    data = request.get_json(silent=True) or {}
    phone_number = data.get('phone_number')
    selected_package = data.get('package', 'gold').strip().lower()
    user_id = session.get('user_id')

    if not phone_number:
        return jsonify({'success': False, 'message': 'Please provide a phone number.'}), 400

    # Auto-convert 07/01 format to 254 format before validating
    phone_number = format_phone_number(phone_number)
    if not phone_number.startswith("254") or len(phone_number) != 12:
        return jsonify({'success': False, 'message': 'Invalid number. Use 07XXXXXXXX or 01XXXXXXXX format.'}), 400

    # Determine amount and description (Consolidated Premium Package)
    amount = 50
    package_name = 'premium'
    desc = "Premium Match"

    # Read callback URL from .env so it's easy to change without touching code
    callback_url = os.getenv(
        "MPESA_CALLBACK_URL",
        "https://www.findyourmatch.co.ke/api/mpesa/student_callback"
    )
    
    try:
        response = initiate_stk_push(phone_number, amount, user_id, callback_url, transaction_desc=desc)

        if not response or 'error' in response:
            return jsonify({'success': False, 'message': 'Payment gateway busy. Please try again.'})

        if 'CheckoutRequestID' in response:
            checkout_id = response['CheckoutRequestID']

            # Clear any stale old checkout from the session first
            # so the old 'failed' status doesn't show up when polling starts
            old_checkout_id = session.get('checkout_id')
            if old_checkout_id and old_checkout_id != checkout_id:
                # Don't delete it — just leave it, but don't let it block this new attempt
                session.pop('checkout_id', None)

            db.reference(f'pending_payments/{checkout_id}').set({
                'user_id': user_id,
                'status': 'pending',
                'package': package_name,
                'amount': amount,
                'created_at': datetime.now(EAT).isoformat()
            })
            # Store checkout_id in session AND in Firebase profile so it
            # survives across requests (session can be lost between STK push & callback)
            session['checkout_id'] = checkout_id
            session.permanent = True  # keep session alive longer
            session.modified = True
            db.reference(f'profiles/{user_id}').update({
                'active_checkout_id': checkout_id
            })

            
            return jsonify({
                'success': True, 
                'checkout_id': checkout_id,
                'message': f'Check your phone for the M-Pesa KSH {amount} PIN prompt!'
            })
        
        return jsonify({'success': False, 'message': 'Invalid response from payment gateway.'})
        
    except Exception as e:
        logger.error(f"STK Push Error: {e}")
        return jsonify({'success': False, 'message': 'Server error initiating payment.'}), 500

@app.route('/api/mpesa/student_callback', methods=['POST'])
@limiter.exempt 
def mpesa_student_callback():
    data = request.get_json(silent=True) or {}
    
    try:
        body = data.get('Body', {})
        stk_callback = body.get('stkCallback', {})
        
        if not stk_callback:
            logger.warning("Received M-Pesa webhook with no stkCallback body.")
            return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

        result_code = stk_callback.get('ResultCode')
        checkout_id = stk_callback.get('CheckoutRequestID')
        
        pending_ref = db.reference(f'pending_payments/{checkout_id}')
        pending_data = pending_ref.get()

        if not pending_data:
            logger.warning(f"⚠️ Webhook received for unknown checkout {checkout_id}")
            return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

        if isinstance(pending_data, str):
            user_id = pending_data
        else:
            user_id = pending_data.get('user_id')

        if result_code == 0:
            metadata = stk_callback.get('CallbackMetadata', {}).get('Item', [])
            mpesa_receipt = next((item['Value'] for item in metadata if item['Name'] == 'MpesaReceiptNumber'), None)
            
            package_name = 'gold'
            if pending_data and isinstance(pending_data, dict):
                package_name = pending_data.get('package', 'gold')

            if user_id:
                expiry_date = (datetime.now(EAT) + timedelta(days=30)).isoformat()
                db.reference(f'profiles/{user_id}').update({
                    'is_paid': True,
                    'subscription_package': package_name,
                    'subscription_expiry': expiry_date,
                    'last_payment_receipt': mpesa_receipt,
                    'active_checkout_id': None  # clear so future payments work cleanly
                })
                pending_ref.update({'status': 'success', 'receipt': mpesa_receipt})
                logger.info(f"✅ STUDENT ACTIVATED via callback: {user_id} receipt={mpesa_receipt}")
            else:
                logger.warning(f"⚠️ Payment received for {checkout_id} but no user_id found!")
        else:
            fail_reason = stk_callback.get('ResultDesc', 'User cancelled or insufficient funds')
            if result_code == 1032:
                fail_reason = "Transaction cancelled by user."
            elif result_code == 1:
                fail_reason = "Insufficient funds in your M-Pesa account."
                
            pending_ref.update({
                'status': 'failed',
                'reason': fail_reason,
                'result_code': result_code
            })
            logger.info(f"❌ STUDENT PAYMENT FAILED: {fail_reason} (Code: {result_code})")

    except Exception as e:
        logger.error(f"⚠️ Student Callback Parsing Error: {e}")

    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

# ==========================================
# M-PESA B2B: MERCHANT SUBSCRIPTIONS
# ==========================================

@app.route('/api/pay_subscription', methods=['POST'])
def pay_subscription():
    if session.get('role') != 'business':
        return jsonify({'error': 'Unauthorized. Please log in as a merchant.'}), 403

    data = request.get_json(silent=True) or {}
    phone_number = data.get('phone_number')
    payment_type = data.get('payment_type', 'gold') # 'gold', 'diamond', or 'boost'
    restaurant_id = session.get('user_id')

    if not phone_number:
        return jsonify({'error': 'Please provide a phone number.'}), 400

    # Auto-convert 07/01 format to 254 format before validating
    phone_number = format_phone_number(phone_number)
    if not phone_number.startswith("254") or len(phone_number) != 12:
        return jsonify({'error': 'Invalid number. Use 07XXXXXXXX or 01XXXXXXXX format.'}), 400

    # Determine amount based on payment type
    if payment_type == 'boost':
        amount = 500
        desc = "24-Hour Spotlight Boost"
    elif payment_type == 'diamond':
        amount = 5000
        desc = "Diamond Premium Portal Activation"
    else:
        amount = 2000
        desc = "Gold Portal Activation"

    # 🚨 ULTIMATE FIX: Hardcode your exact custom domain
    callback_url = "https://www.findyourmatch.co.ke/api/mpesa/b2b_callback"
    
    try:
        response = initiate_stk_push(phone_number, amount, restaurant_id, callback_url)

        if not response or 'error' in response:
            logger.error(f"STK Push Failed: {response.get('error')}")
            return jsonify({'success': False, 'message': 'Payment initiation failed. Try again.'})
        
        if 'CheckoutRequestID' in response:
            checkout_id = response['CheckoutRequestID']
            # Store in both for legacy and consistency
            db.reference(f'pending_b2b_payments/{checkout_id}').set({
                'restaurant_id': restaurant_id,
                'payment_type': payment_type
            })
            db.reference(f'pending_payments/{checkout_id}').set({
                'user_id': restaurant_id,
                'role': 'business',
                'status': 'pending',
                'amount': amount,
                'payment_type': payment_type,
                'created_at': datetime.now(EAT).isoformat()
            })
            session['checkout_id'] = checkout_id
            return jsonify({'success': True, 'message': f'STK Push sent for {desc}! Enter your M-Pesa PIN.'})

        return jsonify({'success': False, 'message': 'Invalid response from gateway.'})
    except Exception as e:
        logger.error(f"STK Push Error: {e}")
        return jsonify({'success': False, 'message': 'Server error initiating payment.'}), 500
    
    
@app.route('/api/mpesa/b2b_callback', methods=['POST'])
@limiter.exempt
def mpesa_b2b_callback():
    data = request.get_json(silent=True) or {}
    
    try:
        body = data.get('Body', {})
        stk_callback = body.get('stkCallback', {})
        
        if not stk_callback:
            return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

        result_code = stk_callback.get('ResultCode')
        checkout_id = stk_callback.get('CheckoutRequestID')
        
        if result_code == 0:
            metadata = stk_callback.get('CallbackMetadata', {}).get('Item', [])
            amount = next((item['Value'] for item in metadata if item['Name'] == 'Amount'), None)
            receipt = next((item['Value'] for item in metadata if item['Name'] == 'MpesaReceiptNumber'), None)
            phone = next((item['Value'] for item in metadata if item['Name'] == 'PhoneNumber'), None)
            
            current_time_eat = datetime.now(EAT).isoformat()

            db.reference('ledger').push({
                'type': 'B2B',
                'amount': amount,
                'receipt': receipt,
                'phone': phone,
                'timestamp': current_time_eat,
                'status': 'Completed'
            })
            logger.info(f"💰 M-Pesa B2B Payment Received: {amount} KSH (Receipt: {receipt})")

            pending_ref = db.reference(f'pending_b2b_payments/{checkout_id}')
            payment_info = pending_ref.get()

            restaurant_id = None
            payment_type = 'gold'  # Default legacy

            if isinstance(payment_info, dict):
                restaurant_id = payment_info.get('restaurant_id')
                payment_type = payment_info.get('payment_type', 'gold')
            else:
                restaurant_id = payment_info  # Legacy string fallback

            if restaurant_id:
                expiry_date = (datetime.now(EAT) + timedelta(days=30)).isoformat()
                
                # Default gold activation payload
                update_payload = {
                    'subscription_active': True,
                    'subscription_start': current_time_eat, 
                    'subscription_expiry': expiry_date,
                    'last_payment_receipt': receipt
                }

                if payment_type == 'boost':
                    boost_expiry = (datetime.now(EAT) + timedelta(days=1)).isoformat()
                    # A boost purchase does not override standard subscription, it just activates the Spotlight
                    update_payload = {
                        'boost_active': True,
                        'boost_expiry': boost_expiry,
                        'last_payment_receipt': receipt
                    }
                    logger.info(f"🚀 SPOTLIGHT BOOST ACTIVATED: ID {restaurant_id} until {boost_expiry}")
                elif payment_type == 'diamond':
                    update_payload['subscription_package'] = 'diamond'
                    logger.info(f"💎 DIAMOND SUBSCRIPTION ACTIVATED: ID {restaurant_id}")
                else:
                    update_payload['subscription_package'] = 'gold'
                    logger.info(f"💫 GOLD SUBSCRIPTION ACTIVATED: ID {restaurant_id}")

                db.reference(f'restaurants/{restaurant_id}').update(update_payload)
                pending_ref.delete()
                logger.info(f"✅ MERCHANT UPDATED: ID {restaurant_id}")
            else:
                logger.warning(f"⚠️ Payment received, but could not find merchant for checkout: {checkout_id}")

        else:
            fail_reason = stk_callback.get('ResultDesc', 'Unknown Error')
            logger.info(f"❌ M-Pesa B2B Payment Failed: {fail_reason}")

    except Exception as e:
        logger.error(f"Error processing B2B M-Pesa Callback: {e}")

    # ALWAYS return a 0 response to Safaricom so they stop retrying the webhook
    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})


# ==========================================
# M-PESA B2C & B2B DISBURSAL WEBHOOKS
# ==========================================
@app.route('/api/mpesa/event_callback', methods=['POST'])
@csrf.exempt
@limiter.exempt
def main_mpesa_event_callback():
    """Event registration ticket payment callback."""
    try:
        from app.routes.events import mpesa_event_callback
        return mpesa_event_callback()
    except Exception as e:
        logger.error(f"Error forwarding event callback: {e}")
        return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})


@app.route('/mpesa/b2c/result', methods=['POST'])
@app.route('//mpesa/b2c/result', methods=['POST'])
@csrf.exempt
@limiter.exempt
def mpesa_b2c_result():
    """Receiver for Safaricom Daraja B2C payout result."""
    data = request.get_json(silent=True) or {}
    logger.info(f"📥 M-Pesa B2C Result Webhook received: {data}")
    try:
        res = data.get('Result', {})
        conv_id = res.get('ConversationID')
        originator_id = res.get('OriginatorConversationID')
        result_code = res.get('ResultCode')
        result_desc = res.get('ResultDesc')
        tx_id = res.get('TransactionID')

        if conv_id:
            db.reference(f'b2c_payout_results/{conv_id}').set({
                "conversation_id": conv_id,
                "originator_id": originator_id,
                "transaction_id": tx_id,
                "result_code": result_code,
                "result_desc": result_desc,
                "payload": data,
                "received_at": datetime.now(EAT).isoformat()
            })
    except Exception as e:
        logger.error(f"Error handling B2C Result: {e}")

    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})


@app.route('/mpesa/b2c/timeout', methods=['POST'])
@app.route('//mpesa/b2c/timeout', methods=['POST'])
@csrf.exempt
@limiter.exempt
def mpesa_b2c_timeout():
    """Receiver for Safaricom Daraja B2C queue timeout."""
    data = request.get_json(silent=True) or {}
    logger.warning(f"⚠️ M-Pesa B2C Timeout Webhook received: {data}")
    try:
        db.reference('b2c_payout_timeouts').push({
            "payload": data,
            "received_at": datetime.now(EAT).isoformat()
        })
    except Exception as e:
        logger.error(f"Error handling B2C Timeout: {e}")

    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})


@app.route('/mpesa/b2b/result', methods=['POST'])
@app.route('//mpesa/b2b/result', methods=['POST'])
@csrf.exempt
@limiter.exempt
def mpesa_b2b_result():
    """Receiver for Safaricom Daraja B2B result."""
    data = request.get_json(silent=True) or {}
    logger.info(f"📥 M-Pesa B2B Result Webhook received: {data}")
    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})


@app.route('/mpesa/b2b/timeout', methods=['POST'])
@app.route('//mpesa/b2b/timeout', methods=['POST'])
@csrf.exempt
@limiter.exempt
def mpesa_b2b_timeout():
    """Receiver for Safaricom Daraja B2B timeout."""
    data = request.get_json(silent=True) or {}
    logger.warning(f"⚠️ M-Pesa B2B Timeout Webhook received: {data}")
    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})


# ==========================================
# ==========================================
# FIREBASE REST API ENDPOINTS (REPLACED WEBSOCKETS)
# ==========================================
import logging
import threading
from datetime import datetime
from flask import session, request, jsonify

logger = logging.getLogger(__name__)

# ==========================================
# ACTIVE CHAT STATUS RECEIPTS
@app.route('/api/chat/enter', methods=['POST'])
@csrf.exempt
def api_enter_chat():
    user_id = session.get('user_id')
    partner_id = request.json.get('partner_id') if request.json else None
    
    if user_id and partner_id:
        match_id = f"match_{min(user_id, partner_id)}_{max(user_id, partner_id)}"
        messages_ref = db.reference(f'matches/{match_id}/messages')
        history = messages_ref.get() or {}
        updates = {}
        if isinstance(history, dict):
            for msg_key, msg in history.items():
                if isinstance(msg, dict) and msg.get('sender_id') == partner_id and msg.get('status') != 'read':
                    updates[f'{msg_key}/status'] = 'read'
        elif isinstance(history, list):
            for index, msg in enumerate(history):
                if isinstance(msg, dict) and msg.get('sender_id') == partner_id and msg.get('status') != 'read':
                    updates[f'{index}/status'] = 'read'
        if updates:
            messages_ref.update(updates)
            
    return jsonify({"success": True})

@app.route('/api/chat/typing', methods=['POST'])
@csrf.exempt
def api_typing():
    user_id = session.get('user_id')
    receiver_id = request.json.get('receiver_id') if request.json else None
    is_typing = request.json.get('is_typing', False) if request.json else False
    
    if user_id and receiver_id:
        users_sorted = sorted([str(user_id), str(receiver_id)])
        room_id = f"{users_sorted[0]}_{users_sorted[1]}"
        db.reference(f'chats/{room_id}/typing/{user_id}').set(is_typing)
    
    return jsonify({"success": True})

@app.route('/api/chat/send', methods=['POST'])
@csrf.exempt
def api_send_message():
    sender_id = session.get('user_id')
    if not sender_id: return jsonify({"success": False, "message": "Unauthorized"}), 401
    
    data = request.json or {}
    receiver_id = data.get('receiver_id')
    msg_text = data.get('text', '').strip()
    msg_type = data.get('type', 'text')
    temp_id = data.get('temp_id')
    file_data = data.get('file_data')
    
    if not receiver_id or (not msg_text and not file_data):
        return jsonify({"success": False}), 400
        
    now_eat = datetime.now(EAT).isoformat()
    
    # 1. Shadowban Check
    try:
        sender_profile = db.reference(f'profiles/{sender_id}').get() or {}
        if sender_profile.get('is_shadowbanned'):
            return jsonify({"success": True, "shadowbanned": True, "temp_id": temp_id})
    except: pass
    
    # 2. AI Companion
    if receiver_id == 'AI_COMPANION':
        if msg_type != 'text': return jsonify({"success": False})
        
        match_id = f"match_{min(sender_id, 'AI_COMPANION')}_{max(sender_id, 'AI_COMPANION')}"
        
        new_msg_ref = db.reference(f'matches/{match_id}/messages').push({
            'sender_id': sender_id, 'text': msg_text, 'timestamp': now_eat, 'type': 'text', 'status': 'read'
        })
        db.reference(f'chats/{match_id}/typing/AI_COMPANION').set(True)
        
        current_user_gender = sender_profile.get('gender', 'unknown')
        def ai_worker():
            try:
                ai_reply = get_ai_companion_response(msg_text, user_gender=current_user_gender)
                db.reference(f'chats/{match_id}/typing/AI_COMPANION').set(False)
                db.reference(f'matches/{match_id}/messages').push({
                    'sender_id': 'AI_COMPANION', 'text': ai_reply, 'timestamp': datetime.now(EAT).isoformat(), 'type': 'text', 'status': 'read'
                })
            except Exception as e: logger.error(f"AI Worker Error: {e}")
            
        threading.Thread(target=ai_worker).start()
        return jsonify({"success": True, "temp_id": temp_id, "msg_id": new_msg_ref.key, "status": "sent"})
        
    # 3. Moderation
    if msg_type == 'text':
        safety_check = analyze_safety(msg_text)
        if not safety_check.get('is_safe', True):
            if safety_check.get('flag') in ['self_harm', 'violence']:
                db.reference('admin_alerts').push({
                    'sender': sender_id, 'receiver': receiver_id, 'message': msg_text, 'flag': safety_check['flag'], 'timestamp': now_eat
                })
            return jsonify({"success": False, "system_reply": safety_check.get('system_reply')}), 400
            
        if contains_phone_number(msg_text):
            return jsonify({"success": False, "system_reply": "SYSTEM ALERT: Sharing phone numbers is restricted."}), 400
            
    users_sorted = sorted([str(sender_id), str(receiver_id)])
    match_id = f"match_{users_sorted[0]}_{users_sorted[1]}"
    file_url = None
    
    if msg_type in ['image', 'video', 'audio'] and file_data:
        media_ref = db.reference('chat_media').push({
            'sender_id': sender_id, 'match_id': match_id, 'type': msg_type, 'data': file_data, 'timestamp': now_eat
        })
        file_url = file_data
        
    message_payload = {
        'sender_id': sender_id,
        'text': msg_text if msg_type == 'text' else f"Sent a {msg_type}",
        'timestamp': now_eat,
        'type': msg_type,
        'status': 'sent'
    }
    if file_url: message_payload['file_url'] = file_url
    
    try:
        new_msg_ref = db.reference(f'matches/{match_id}/messages').push(message_payload)
        
        match_ref = db.reference(f'matches/{match_id}')
        match_data = match_ref.get() or {}
        
        # FEATURE 7: STREAK TRACKER
        streak_count = match_data.get('streak_count', 0)
        last_streak_date = match_data.get('last_streak_date', '')
        last_sender = match_data.get('last_sender_id', '')
        
        today_date = datetime.now(EAT).strftime('%Y-%m-%d')
        yesterday_date = (datetime.now(EAT) - timedelta(days=1)).strftime('%Y-%m-%d')
        
        if last_sender and last_sender != sender_id:
            if last_streak_date == yesterday_date:
                streak_count += 1
                last_streak_date = today_date
            elif last_streak_date == today_date:
                pass # Already incremented today
            else:
                streak_count = 1
                last_streak_date = today_date
        elif not last_sender:
            streak_count = 1
            last_streak_date = today_date
            
        match_ref.update({
            'last_message': message_payload['text'],
            'last_message_time': now_eat,
            'last_sender_id': sender_id,
            'streak_count': streak_count,
            'last_streak_date': last_streak_date,
            f'users/{sender_id}': True,
            f'users/{receiver_id}': True
        })
        
        # PUSH GLOBAL NOTIFICATION TO RECEIVER
        try:
            sender_name = sender_profile.get('name', 'Someone')
            sender_img = sender_profile.get('img', '/static/img/placeholder.png')
            db.reference(f'notifications/{receiver_id}').push({
                'sender_id': sender_id,
                'sender_name': sender_name,
                'sender_img': sender_img,
                'type': 'message',
                'message': message_payload['text'],
                'timestamp': now_eat,
                'match_id': match_id
            })
            
            # TRIGGER FCM PUSH NOTIFICATION
            send_push_notification(
                receiver_id=receiver_id,
                title=f"New message from {sender_name}",
                body=message_payload['text'],
                click_url=f"/chat/{match_id}"
            )

            # SEND OFFLINE EMAIL ALERT SO STUDENTS NEVER MISS A CHAT (ASYNC)
            if receiver_id != 'AI_COMPANION':
                def _dispatch_offline_email_worker(r_id, s_name, msg_body, m_id, m_ref):
                    try:
                        r_prof = db.reference(f'profiles/{r_id}').get() or {}
                        r_email = r_prof.get('email') or db.reference(f'users/{r_id}/email').get()
                        is_online = r_prof.get('is_online', False)
                        
                        # Only send if receiver is currently offline and has a valid email
                        if r_email and not is_online:
                            m_info = m_ref.get() or {}
                            last_email_time = m_info.get(f'last_offline_email_{r_id}')
                            should_send = True
                            if last_email_time:
                                try:
                                    last_dt = datetime.fromisoformat(last_email_time)
                                    if datetime.now(EAT) - last_dt < timedelta(minutes=15):
                                        should_send = False
                                except Exception:
                                    pass
                            
                            if should_send:
                                m_ref.update({f'last_offline_email_{r_id}': datetime.now(EAT).isoformat()})
                                from app.email_service import send_offline_chat_email
                                send_offline_chat_email(
                                    recipient_email=r_email,
                                    recipient_name=r_prof.get('name', 'Comrade'),
                                    sender_name=s_name,
                                    message_preview=msg_body
                                )
                    except Exception as err:
                        logger.error(f"Failed to send offline chat alert: {err}")

                threading.Thread(
                    target=_dispatch_offline_email_worker,
                    args=(receiver_id, sender_name, message_payload['text'], match_id, match_ref),
                    daemon=True
                ).start()

        except Exception as e:
            logger.error(f"Error dispatching chat notification: {e}")

        # LADIES CHAT-TO-EARN ENGAGEMENT TRACKER
        lady_reward_stat = None
        try:
            from app.services.ladies_reward_service import record_engagement_on_message
            lady_reward_stat = record_engagement_on_message(sender_id, receiver_id)
        except Exception as l_err:
            logger.debug(f"Lady engagement tracking non-blocking error: {l_err}")

        resp_payload = {
            "success": True, 
            "temp_id": temp_id, 
            "msg_id": new_msg_ref.key, 
            "status": "sent",
            "message_payload": message_payload
        }
        if lady_reward_stat and lady_reward_stat.get("recorded"):
            resp_payload["lady_reward"] = lady_reward_stat

        return jsonify(resp_payload)
    except Exception as e:
        logger.error(f"Save message error: {e}")
        return jsonify({"success": False}), 500

@app.route('/api/delete_message', methods=['POST'])
@login_required
@csrf.exempt
def api_delete_message():
    user_id = session.get('user_id')
    data = request.json or {}
    partner_id = data.get('partner_id')
    msg_id = data.get('msg_id')
    delete_type = data.get('type') # 'me' or 'everyone'
    
    if not partner_id or not msg_id:
        return jsonify({"success": False}), 400
        
    try:
        match_id = f"match_{min(user_id, partner_id)}_{max(user_id, partner_id)}"
        if delete_type == 'me':
            deleted_for_ref = db.reference(f'matches/{match_id}/messages/{msg_id}/deleted_for')
            deleted_for = deleted_for_ref.get() or []
            if user_id not in deleted_for:
                deleted_for.append(user_id)
                deleted_for_ref.set(deleted_for)
        elif delete_type == 'everyone':
            # Check if this user is actually the sender
            msg_ref = db.reference(f'matches/{match_id}/messages/{msg_id}')
            msg_data = msg_ref.get() or {}
            if msg_data.get('sender_id') == user_id:
                msg_ref.update({'is_deleted': True, 'text': '🚫 This message was deleted.'})
                db.reference(f'matches/{match_id}/deleted_messages/{msg_id}').set(True)
                
        return jsonify({"success": True})
    except Exception as e:
        logger.error(f"Delete message error: {e}")
        return jsonify({"success": False}), 500

# ==========================================
# STUDENT VENUE DISCOVERY & BOOKING
# ==========================================
@app.route('/discover')
@requires_subscription
def discover_venues():
    """THE DISCOVERY DECK FOR DATE VENUES WITH TRENDING HEATMAP"""
    user_id = session.get('user_id')
    
    try:
        # 1. Fetch only ACTIVE (paying) restaurants
        venues = get_all_restaurants(active_only=True)
        
        # ==========================================
        # 🔥 NEW: TRENDING VENUES ALGORITHM
        # ==========================================
        all_bookings = db.reference('bookings').get() or {}
        now_eat = datetime.now(EAT)
        seven_days_ago = now_eat - timedelta(days=7)
        
        # Initialize scores
        venue_scores = {str(v.get('id')): 0 for v in venues}
        
        # Tally up the bookings from the last 7 days
        for b_id, b_data in all_bookings.items():
            if not isinstance(b_data, dict): continue
            
            v_id = str(b_data.get('venue_id'))
            b_timestamp = b_data.get('timestamp') or b_data.get('created_at') # Fallback depending on how you save dates
            
            if v_id in venue_scores and b_timestamp:
                try:
                    b_time = datetime.fromisoformat(b_timestamp)
                    # Only count bookings from the last 7 days
                    if b_time >= seven_days_ago:
                        # Weight Approved/Completed dates heavier than Pending ones
                        points = 2 if b_data.get('status') in ['Approved', 'Completed'] else 1
                        venue_scores[v_id] += points
                except ValueError:
                    pass # Ignore badly formatted old dates
        
        # Attach the calculated score to the venue dictionaries
        for venue in venues:
            venue['trending_score'] = venue_scores.get(str(venue.get('id')), 0)
            
        # Create a separate list for the Top 3 Trending venues (Must have at least 1 booking to trend)
        trending_venues = sorted([v for v in venues if v['trending_score'] > 0], key=lambda x: x['trending_score'], reverse=True)[:3]

        # ==========================================
        # 2. Fetch student profiles for the invite dropdown
        # ==========================================
        all_profiles_dict = db.reference('profiles').get() or {}
        selectable_students = []

        for p_id, p in all_profiles_dict.items():
            # Skip conditions: Self, Hidden profiles, or the AI Wingman
            if not isinstance(p, dict) or p_id == user_id or not p.get('is_visible', True) or p_id == 'AI_COMPANION':
                continue
            
            # Calculate compatibility
            ai_score = p.get('ai_score', random.randint(60, 95))
            
            selectable_students.append({
                'id': p_id,
                'name': p.get('name', 'Student').split(' ')[0],
                'compatibility': ai_score,
                'is_perfect_match': ai_score >= 80
            })

        # Sort: Perfect Matches at the top, then by score
        selectable_students.sort(key=lambda x: (x['is_perfect_match'], x['compatibility']), reverse=True)

    except Exception as e:
        logger.error(f"Error loading discovery data: {e}")
        venues, trending_venues, selectable_students = [], [], []
        flash("Error loading page. Please refresh.", "error")
        
    return render_template(
        'bookings.html', 
        current_user=session.get('user_name', 'Student').split(' ')[0],
        venues=venues, 
        trending_venues=trending_venues, # <-- Pass trending venues to the template
        matches=selectable_students 
    )
    
    
@app.route('/api/propose_date', methods=['POST'])
@login_required
def propose_date():
    """Handles the booking request and sends a real-time invite in the chat."""
    data = request.json
    sender_id = session.get('user_id')
    sender_name = session.get('user_name', 'Your Match').split(' ')[0]
    
    venue_id = data.get('venue_id')
    venue_name = data.get('venue_name')
    partner_id = data.get('partner_id')
    date_day = data.get('day')
    date_time = data.get('time')
    
    # 1. Strict Validation Checks
    if not all([venue_id, partner_id, date_day, date_time]):
        return jsonify({'success': False, 'message': 'Missing details. Please fill out all fields.'}), 400
        
    # Prevent users from booking a table with the AI bot
    if partner_id == 'AI_COMPANION':
        return jsonify({'success': False, 'message': 'You cannot take the AI Wingman on a physical date!'}), 400
        
    try:
        # 2. Database Writes (Synchronous to ensure they succeed before responding)
        create_date_booking(venue_id, sender_id, partner_id, date_day, date_time)
        increment_restaurant_view(venue_id)
        
        # Format the chat invitation
        invite_msg = (
            f"💌 **DATE INVITATION** 💌\n\n"
            f"I'd love to take you to **{venue_name}**!\n"
            f"📅 **When:** {date_day} at {date_time}\n"
            f"Let me know if you're down!"
        )
        
        # Save the message to Firebase so it persists in their chat history
        save_chat_message(sender_id, partner_id, invite_msg, msg_type='date_invite')
        
        # 3. REAL-TIME SYNC (Offloaded to Background Task for 0ms UI latency)
        socket_payload = {
            'sender': sender_id,
            'receiver_id': partner_id,
            'type': 'date_invite',
            'text': invite_msg,
            'timestamp': datetime.now(EAT).isoformat(),
            'temp_id': f"invite_{int(datetime.now(EAT).timestamp())}"
        }
        
        def emit_date_notifications():
            pass # WebSockets removed: Handled by Firebase listeners

        # 4. NOTIFY MERCHANT VIA EMAIL
        try:
            restaurant = get_restaurant(venue_id)
            if restaurant and restaurant.get('email'):
                user_a_name = session.get('user_name', 'Student').split(' ')[0]
                # Fetch partner name
                partner_profile = db.reference(f"profiles/{partner_id}").get() or {}
                user_b_name = partner_profile.get('name', 'Their Match').split(' ')[0]
                try:
                    from app.email_service import send_date_request_to_merchant_email, send_date_request_to_partner_email, send_date_request_to_sender_email
                    
                    # Notify Merchant
                    send_date_request_to_merchant_email(
                        restaurant['email'], 
                        restaurant.get('business_name', 'Merchant'),
                        user_a_name,
                        user_b_name,
                        date_day,
                        date_time
                    )
                    
                    # Notify Partner
                    if partner_profile.get('email'):
                        send_date_request_to_partner_email(
                            partner_profile['email'],
                            restaurant.get('business_name', 'Merchant'),
                            user_a_name,
                            user_b_name,
                            date_day,
                            date_time
                        )
                        
                    # Notify Sender
                    sender_email = session.get('user_email')
                    if sender_email:
                        send_date_request_to_sender_email(
                            sender_email,
                            restaurant.get('business_name', 'Merchant'),
                            user_a_name,
                            user_b_name,
                            date_day,
                            date_time
                        )
                except Exception as email_err:
                    print(f"Failed to send email notifications: {email_err}")
                    
                # Push real-time notification to the Merchant
                db.reference(f'notifications/{venue_id}').push({
                    'type': 'date_request',
                    'sender_id': sender_id,
                    'sender_name': user_a_name,
                    'message': f"New booking request from {user_a_name} and {user_b_name}!",
                    'timestamp': datetime.now(EAT).isoformat(),
                    'status': 'unread'
                })
                
                # Push real-time notification to the Partner
                db.reference(f'notifications/{partner_id}').push({
                    'type': 'date_request',
                    'sender_id': sender_id,
                    'sender_name': user_a_name,
                    'message': f"{user_a_name} invited you on a date to {restaurant.get('business_name', 'a venue')}!",
                    'timestamp': datetime.now(EAT).isoformat(),
                    'status': 'unread'
                })
                    
        except Exception as e:
            logger.warning(f"Failed to send email/notification to merchant: {e}")

        return jsonify({'success': True, 'message': 'Invitation sent!'})
        
    except Exception as e:
        logger.error(f"Error proposing date: {e}")
        return jsonify({'success': False, 'message': 'Internal server error.'}), 500
# ==========================================
# AI WINGMAN & RIZZ CHECK ROUTES
# ==========================================

@app.route('/wingman')
@requires_subscription
def ai_wingman():
    """Renders the AI Wingman dashboard."""
    user_id = session.get('user_id')
    
    try:
        user_profile = db.reference(f'profiles/{user_id}').get() or {}
        
        # Fetch all matches
        raw_matches = get_user_matches(user_id) 
        
        # 🛡️ Filter out the AI bot so users can't generate icebreakers to talk to the robot!
        clean_matches = [m for m in raw_matches if m.get('id') != 'AI_COMPANION']
        
        return render_template('wingman.html', user=user_profile, matches=clean_matches)
        
    except Exception as e:
        logger.error(f"Wingman Page Network Error: {e}")
        flash("Network connection dropped slightly. Please refresh the page.", "error")
        # Fallback to empty data to prevent a 500 Server Error crash
        return render_template('wingman.html', user={'bio': 'Network error.'}, matches=[])


@app.route('/api/wingman_action', methods=['POST'])
@login_required
@limiter.limit("5 per minute") # 🚨 STOPS BOT SPAMMING THE GROQ API
def api_wingman_action():
    """Handles requests for Profile Roasts and Icebreakers."""
    data = request.json
    action = data.get('action')
    user_id = session.get('user_id')
    
    try:
        # =======================================================
        # 1. PROFILE ROASTER LOGIC
        # =======================================================
        if action == 'roast_profile':
            user_profile = db.reference(f'profiles/{user_id}').get() or {}
            bio = user_profile.get('bio', 'No bio provided.')
            major = user_profile.get('major', 'Unknown major.')
            
            prompt = (
                f"Act as a brutally honest, funny, but ultimately helpful college dating coach. "
                f"My major is {major} and my dating app bio is: '{bio}'. "
                f"Give me a funny 'roast' of this bio, and then provide 3 actionable tips "
                f"or rewrite suggestions to make it more attractive to college students. "
                f"CRITICAL: Do not say 'Here is your roast'. Just start roasting immediately."
            )
            
            ai_response = get_ai_companion_response(prompt, user_gender=user_profile.get('gender', 'unknown'))
            return jsonify({'success': True, 'response': ai_response})
            
        # =======================================================
        # 2. SMART ICEBREAKER & CONVERSATION CONTINUER
        # =======================================================
        elif action == 'generate_icebreaker':
            partner_id = data.get('partner_id')
            if not partner_id:
                return jsonify({'success': False, 'message': 'Select a match first!'}), 400
                
            partner_profile = db.reference(f'profiles/{partner_id}').get() or {}
            partner_bio = partner_profile.get('bio', 'They have no bio... time to get creative.')
            partner_name = partner_profile.get('name', 'your match').split(' ')[0]
            
            # 🧠 READ THE ROOM: Fetch actual chat history to see if they are already talking!
            chat_history = get_chat_history(user_id, partner_id)
            human_chats = [msg for msg in chat_history if msg.get('sender') != 'SYSTEM_AI'] if chat_history else []
            
            if human_chats and len(human_chats) > 0:
                # 💬 REPLY MODE: They are already talking.
                recent_msgs = human_chats[-6:] # Grab the last 6 messages for context
                formatted_chat = ""
                for msg in recent_msgs:
                    sender_label = "Me" if msg['sender'] == user_id else partner_name
                    formatted_chat += f"{sender_label}: {msg.get('text', '')}\n"
                
                prompt = (
                    f"Act as my charismatic dating coach. I am currently chatting with {partner_name}. "
                    f"Their bio says: '{partner_bio}'.\n"
                    f"Here is the exact transcript of our recent conversation:\n"
                    f"{formatted_chat}\n\n"
                    f"Based EXACTLY on what we are talking about right now, write 3 brilliant, natural-sounding replies I can send next to keep the conversation engaging. "
                    f"Make them varied (1 funny/teasing, 1 thoughtful question, 1 smooth transition). "
                    f"CRITICAL RULE: Do NOT output conversational filler like 'Here are your options:' or 'Let's get this started'. "
                    f"Just output the 3 numbered options directly so I can copy and paste them."
                )
            else:
                # 🧊 COLD OPENER MODE: The chat is totally empty.
                prompt = (
                    f"Act as my ultimate wingman. I just matched with someone named {partner_name}. "
                    f"Their bio says: '{partner_bio}'. "
                    f"Generate 3 highly customized, funny, and engaging icebreakers I can send them right now based ONLY on their bio. "
                    f"Don't be creepy. Keep it fun and college-appropriate. "
                    f"CRITICAL RULE: Do NOT output conversational filler like 'Here are some options:' or 'Let's get this started'. "
                    f"Just output the 3 numbered options directly so I can copy and paste them."
                )
            
            ai_response = get_ai_companion_response(prompt, user_gender='unknown')
            return jsonify({'success': True, 'response': ai_response})
            
        else:
            return jsonify({'success': False, 'message': 'Invalid action.'}), 400

    except Exception as e:
        logger.error(f"Wingman API Error: {e}")
        return jsonify({'success': False, 'message': 'The Wingman is currently busy. Try again later!'}), 500

@app.route('/api/support/submit', methods=['POST'])
@login_required
def support_submit():
    """Professional Support & Feedback Route"""
    data = request.json
    user_id = session.get('user_id')
    support_type = data.get('type', 'feedback')
    message = data.get('message', '').strip()
    
    if not message:
        return jsonify({'success': False, 'message': 'Message cannot be empty.'}), 400
        
    try:
        db.reference(f'feedbacks/{support_type}').push({
            'user_id': user_id,
            'user_name': session.get('user_name', 'Student'),
            'message': message,
            'timestamp': datetime.now(EAT).isoformat(),
            'status': 'open'
        })
        return jsonify({'success': True, 'message': 'Successfully submitted! Our team will review this shortly.'})
    except Exception as e:
        logger.error(f"Support API Error: {e}")
        return jsonify({'success': False, 'message': 'Failed to submit. Try again later.'}), 500

@app.route('/api/wingman/execute', methods=['POST'])
@login_required
@limiter.limit("5 per minute")
def wingman_execute():
    """Premium AI Wingman Route using Groq LLaMA-3"""
    data = request.json
    action = data.get('action') # 'roast' or 'icebreaker'
    user_id = session.get('user_id')
    
    try:
        user_profile = db.reference(f'profiles/{user_id}').get() or {}
        bio = user_profile.get('bio', 'No bio provided.')
        interests = user_profile.get('interests', 'No interests listed.')
        course = user_profile.get('course', user_profile.get('major', 'MMUST Student'))
        gender = user_profile.get('gender', 'unknown')

        if action == 'roast':
            system_prompt = "Act as a brutally honest but funny college dating coach. Use Kenyan campus slang (comrade, rizz, character development). Finish with 2 actionable tips for improvement. Keep it sharp and witty."
            user_text = (
                f"Roast this MMUST student's profile: \n"
                f"Bio: {bio}\nInterests: {interests}\nCourse: {course}\n"
            )
            response = get_wingman_response(system_prompt, user_text)
        elif action == 'icebreaker':
            partner_id = data.get('partner_id')
            if not partner_id:
                return jsonify({'success': False, 'message': 'Please select a student first.'}), 400
            
            partner_profile = db.reference(f'profiles/{partner_id}').get() or {}
            p_name = partner_profile.get('name', 'Match').split()[0]
            p_bio = partner_profile.get('bio', 'No bio.')
            p_interests = partner_profile.get('interests', 'No interests listed.')
            
            system_prompt = "You are a smooth AI wingman. Generate exactly 3 highly creative, witty, and unique icebreakers the user can send to their match. Format them clearly with numbers. Avoid generic 'Hey'."
            user_text = (
                f"Generate 3 icebreakers for {p_name} based on their profile: \n"
                f"Bio: {p_bio}\nInterests: {p_interests}\n"
            )
            response = get_wingman_response(system_prompt, user_text)
        else:
            return jsonify({'success': False, 'message': 'Invalid action.'}), 400

        return jsonify({'success': True, 'response': response})

    except Exception as e:
        logger.error(f"Wingman Execute Error: {e}")
        return jsonify({'success': False, 'message': 'The AI Wingman is taking a break. Try again later.'}), 500


# ==========================================
# FCM PUSH NOTIFICATIONS
# ==========================================
from firebase_admin import messaging

@app.route('/api/user/device', methods=['POST'])
@csrf.exempt
def save_device_token():
    """WAF-friendly endpoint for saving FCM tokens."""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.get_json() or {}
    token = data.get('device_id') # Masked as 'device_id' to bypass WAF
    
    if token:
        db.reference(f'profiles/{user_id}/fcm_token').set(token)
        return jsonify({"success": True}), 200
        
    return jsonify({"error": "No token"}), 400


def send_push_notification(receiver_id, title, body, click_url='/matches', tag=None):
    """
    Sends background Push Notifications to a user device even when offline from the app.
    Dispatches:
    1. W3C Web Push (via pywebpush + VAPID) to push_subscriptions/{receiver_id}
       Wakes up mobile/desktop devices via OS push service when app is closed / phone locked.
    2. Firebase Cloud Messaging (FCM) to profiles/{receiver_id}/fcm_token
    """
    if not receiver_id:
        return False

    dispatched = False

    # 1. W3C Web Push via pywebpush (Native PWA background wakeup)
    try:
        sub_record = db.reference(f'push_subscriptions/{receiver_id}').get()
        if sub_record and webpush:
            priv_key = app.config.get('VAPID_PRIVATE_KEY') or os.path.abspath(os.path.join(os.path.dirname(__file__), '../private_key.pem'))
            claims = app.config.get('VAPID_CLAIMS') or {"sub": "mailto:delstarfordisaiah@gmail.com"}

            push_payload = json.dumps({
                "title": title,
                "body": body,
                "url": click_url,
                "tag": tag or f"fym_{int(time.time())}"
            })

            subscriptions = []
            if isinstance(sub_record, dict):
                if 'endpoint' in sub_record:
                    subscriptions.append((None, sub_record))
                else:
                    for k, v in sub_record.items():
                        if isinstance(v, dict) and 'endpoint' in v:
                            subscriptions.append((k, v))

            for sub_key, sub_data in subscriptions:
                try:
                    webpush(
                        subscription_info=sub_data,
                        data=push_payload,
                        vapid_private_key=priv_key,
                        vapid_claims=claims,
                        ttl=86400  # Queue for 24h if device temporarily disconnected from internet
                    )
                    dispatched = True
                    logger.info(f"WebPush successfully dispatched to {receiver_id}")
                except WebPushException as wpe:
                    logger.warning(f"WebPush response for {receiver_id}: {wpe}")
                    # Delete expired/unsubscribed endpoints (404/410)
                    if hasattr(wpe, 'response') and wpe.response is not None and wpe.response.status_code in [404, 410]:
                        if sub_key:
                            db.reference(f'push_subscriptions/{receiver_id}/{sub_key}').delete()
                        else:
                            db.reference(f'push_subscriptions/{receiver_id}').delete()
                except Exception as we:
                    logger.error(f"WebPush error for {receiver_id}: {we}")
    except Exception as e:
        logger.error(f"Failed to query WebPush subscriptions for {receiver_id}: {e}")

    # 2. Firebase Cloud Messaging (FCM)
    try:
        receiver_profile = db.reference(f'profiles/{receiver_id}').get() or {}
        fcm_token = receiver_profile.get('fcm_token')

        if fcm_token and messaging:
            fcm_msg = messaging.Message(
                notification=messaging.Notification(
                    title=title,
                    body=body
                ),
                data={
                    "click_action": click_url,
                    "title": title,
                    "body": body,
                    "url": click_url,
                    "tag": tag or f"fym_{int(time.time())}"
                },
                webpush=messaging.WebpushConfig(
                    notification=messaging.WebpushNotification(
                        title=title,
                        body=body,
                        icon='/static/img/icon-192.png',
                        badge='/static/img/badge-icon.png'
                    ),
                    fcm_options=messaging.WebpushFCMOptions(
                        link=click_url
                    )
                ),
                token=fcm_token
            )
            messaging.send(fcm_msg)
            dispatched = True
            logger.info(f"FCM push successfully delivered to {receiver_id}")
    except Exception as e:
        logger.error(f"Failed to send FCM push notification to {receiver_id}: {e}")

    return dispatched

import hashlib

def hash_reg_number(reg_num):
    """
    Standardizes the reg number (removes spaces, makes uppercase)
    and returns an unbreakable SHA-256 hash.
    """
    if not reg_num: return None
    clean_reg = str(reg_num).strip().upper()
    # Add a "salt" (a secret key) to make it even harder to crack
    secret_salt = os.getenv("HASH_SALT", "MMUST_SECRET_2026")
    salted_reg = f"{clean_reg}_{secret_salt}"
    
    return hashlib.sha256(salted_reg.encode('utf-8')).hexdigest()
import string
import random

# Handle 404 Page Not Found errors globally
@app.errorhandler(404)
def page_not_found(e):
    # Renders your beautiful new 404 template, returning a 404 status code
    return render_template('404.html'), 404

# Optional: Handle 500 Internal Server Errors (if your code crashes)
@app.errorhandler(500)
def internal_server_error(e):
    # You can reuse the 404 template, or create a specific 500.html later
    return render_template('404.html'), 500


@app.route('/join')
def join():
    """Catches incoming referral links (Rewards program discontinued)."""
    # 1-week free premium for referrals has been discontinued
    return redirect(url_for('auth.signup'))


# ==========================================
# 1. REFERRALS DASHBOARD ROUTE (DISABLED)
# ==========================================
@app.route('/referrals')
def referrals():
    """The 1-week free premium referral program is disabled."""
    if 'user_id' not in session:
        flash("Please log in.", "error")
        return redirect(url_for('auth.login'))
    
    flash("The 1-week free premium referral reward program has ended.", "warning")
    return redirect(url_for('dashboard'))


# ==========================================
# 2. PAYMENT POLLING API ROUTE
# ==========================================
@app.route('/api/check_access', methods=['GET'])
def check_access():
    """The frontend calls this every 1.5-3 seconds to see if the payment callback arrived."""
    if 'user_id' not in session:
        return jsonify({'granted': False, 'error': 'Unauthorized'}), 401

    user_id = session['user_id']
    role = session.get('role', 'student')
    checkout_id = session.get('checkout_id')

    try:
        # 1. First, check the profile - this is the source of truth
        if role == 'business':
            user_ref = db.reference(f'restaurants/{user_id}')
            user_data = user_ref.get() or {}
            is_paid = user_data.get('subscription_active', False)
        else:
            user_ref = db.reference(f'profiles/{user_id}')
            user_data = user_ref.get() or {}
            is_paid = user_data.get('is_paid', False)

            # CRITICAL FIX: If session lost checkout_id, recover it from Firebase
            if not checkout_id:
                checkout_id = user_data.get('active_checkout_id')
                if checkout_id:
                    session['checkout_id'] = checkout_id
                    session.modified = True
                    logger.info(f"Recovered checkout_id from Firebase for {user_id}: {checkout_id}")
        
        if is_paid is True:
            # Sync session so paywall guard doesn't re-block this request
            session['is_paid'] = True
            session.modified = True
            return jsonify({
                'granted': True, 
                'status': 'success',
                'message': 'Access granted!'
            })

        # 2. If not paid in DB, check if there's an active checkout_id
        if checkout_id:
            pending_ref = db.reference(f'pending_payments/{checkout_id}')
            payment_status = pending_ref.get()
            
            if payment_status:
                status = 'pending'
                if isinstance(payment_status, dict):
                    status = payment_status.get('status', 'pending')
                
                if status == 'failed':
                    return jsonify({
                        'granted': False, 
                        'status': 'failed', 
                        'message': payment_status.get('reason', 'Payment was cancelled or failed.')
                    })
                elif status == 'success':
                    return jsonify({'granted': True, 'status': 'success'})
                
                # 3. Query Safaricom — but ONLY after a grace window
                # The PIN prompt takes ~5-15s to appear. Querying too early
                # returns ambiguous codes that look like failures.
                created_at_str = payment_status.get('created_at') if isinstance(payment_status, dict) else None
                seconds_since_creation = 999  # default: assume old enough
                if created_at_str:
                    try:
                        created_dt = datetime.fromisoformat(str(created_at_str).replace('Z', '+00:00'))
                        if created_dt.tzinfo is None:
                            created_dt = created_dt.replace(tzinfo=EAT)
                        seconds_since_creation = (datetime.now(EAT) - created_dt).total_seconds()
                    except Exception:
                        pass

                # Wait at least 30 seconds before querying Safaricom
                # This gives the user time to see the PIN prompt and respond
                if seconds_since_creation < 30:
                    logger.info(f"Grace period: {seconds_since_creation:.0f}s since STK push — not querying Safaricom yet")
                    return jsonify({'granted': False, 'status': 'pending'})

                logger.info(f"Querying Safaricom for {role} CheckoutID: {checkout_id} ({seconds_since_creation:.0f}s old)")
                safaricom_check = check_payment_status(checkout_id)

                if safaricom_check.get('status') == 'PAID':
                    mpesa_receipt = "QUERY_SUCCESS"

                    if role == 'business':
                        expiry_date = (datetime.now(EAT) + timedelta(days=365)).isoformat()
                        user_ref.update({
                            'subscription_active': True,
                            'subscription_expiry': expiry_date,
                            'last_payment_receipt': mpesa_receipt
                        })
                    else:
                        expiry_date = (datetime.now(EAT) + timedelta(days=30)).isoformat()
                        package_name = 'gold'
                        if payment_status and isinstance(payment_status, dict):
                            package_name = payment_status.get('package', 'gold')

                        user_ref.update({
                            'is_paid': True,
                            'subscription_package': package_name,
                            'subscription_expiry': expiry_date,
                            'last_payment_receipt': mpesa_receipt
                        })

                    pending_ref.update({'status': 'success', 'receipt': mpesa_receipt})
                    logger.info(f"✅ ACTIVE ACTIVATION: {user_id} ({role}) confirmed paid.")
                    session['is_paid'] = True
                    session.modified = True
                    db.reference(f'profiles/{user_id}').update({'active_checkout_id': None})
                    return jsonify({'granted': True, 'status': 'success'})

                elif safaricom_check.get('status') == 'CANCELED':
                    # User explicitly pressed Cancel on their phone
                    fail_reason = "You cancelled the M-Pesa request. Tap Pay to try again."
                    pending_ref.update({'status': 'failed', 'reason': fail_reason})
                    return jsonify({'granted': False, 'status': 'failed', 'message': fail_reason})

                elif safaricom_check.get('status') == 'FAILED':
                    # Definitive failure (e.g. insufficient balance)
                    fail_reason = safaricom_check.get('reason', 'Payment failed. Check your M-Pesa balance.')
                    pending_ref.update({'status': 'failed', 'reason': fail_reason})
                    return jsonify({'granted': False, 'status': 'failed', 'message': fail_reason})

                # PENDING or anything else — keep waiting
                return jsonify({'granted': False, 'status': 'pending'})

    except Exception as e:
        logger.error(f"❌ Check Access failed for {user_id}: {str(e)}")
        return jsonify({'granted': False, 'status': 'error'}), 200

    # Default fallback
    return jsonify({'granted': False, 'status': 'none'})
    
# ==========================================
# PUBLIC WINGMAN ROUTES (VIRAL GROWTH)
# ==========================================
@app.route('/bestie/<wingman_code>')
def bestie_review(wingman_code):
    """Public read-only route for a friend to review a profile."""
    # Find the user by their unique wingman code
    matching_users = db.reference('profiles').order_by_child('wingman_code').equal_to(wingman_code).get()
    
    if not matching_users:
        flash("This profile link has expired or doesn't exist.", "warning")
        return redirect(url_for('home'))
        
    # Extract the target user's ID and data
    target_id = list(matching_users.keys())[0]
    target_user = matching_users[target_id]
    
    # Hide sensitive data just in case
    safe_profile = {
        'name': target_user.get('name', 'Student').split(' ')[0],
        'age': target_user.get('age', 18),
        'bio': target_user.get('bio', 'No bio provided.'),
        'img': target_user.get('img', '/static/img/placeholder.png'),
        'major': target_user.get('major', 'MMUST Student'),
        'intent': target_user.get('intent', '')
    }
    
    return render_template('bestie_review.html', profile=safe_profile, target_id=target_id)

@app.route('/api/bestie_vote', methods=['POST'])
def bestie_vote():
    """Receives the 'Catch' or 'Red Flag' vote from the friend."""
    data = request.json
    target_id = data.get('target_id')
    vote = data.get('vote') # 'catch' or 'red_flag'
    
    if not target_id or not vote:
        return jsonify({'success': False}), 400
        
    try:
        # Send a real-time system message to the user!
        msg_text = "🔥 WINGMAN ALERT: Your bestie says you're a Catch!" if vote == 'catch' else "🚨 WINGMAN ALERT: Your bestie flagged your profile! Time to update your bio?"
        
        save_chat_message('SYSTEM_AI', target_id, msg_text, msg_type='text')
        
        # Attempt real-time socket delivery if they are online
        # WebSockets removed: Messages are synced via Firebase automatically
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Bestie Vote Error: {e}")
        return jsonify({'success': False}), 500
    

@app.route('/merchant/dashboard')
@login_required # Ensure this user is a merchant, not a student
def merchant_dashboard():
    merchant_id = session.get('user_id')
    
    # 1. Fetch the merchant's specific restaurant data
    restaurant_ref = db.reference(f'restaurants/{merchant_id}').get()
    
    if not restaurant_ref:
        flash("Restaurant profile not found.", "error")
        return redirect(url_for('index'))

    # 2. Calculate ROI & Analytics
    all_bookings = db.reference('bookings').get() or {}
    total_bookings = 0
    completed_bookings = 0
    
    # We will assume an average spend of 1500 KSH per couple for the ROI calculation
    AVERAGE_COUPLE_SPEND_KSH = 1500 
    
    # Get the start of the current month for monthly stats
    now = datetime.now(EAT)
    start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    monthly_completed = 0

    for b_id, b_data in all_bookings.items():
        if b_data.get('venue_id') == merchant_id:
            total_bookings += 1
            
            # Count how many dates actually happened (merchant scanned the QR code)
            if b_data.get('status') in ['Completed', 'Archived']:
                completed_bookings += 1
                
                # Check if it was this month
                b_timestamp = b_data.get('completed_timestamp')
                if b_timestamp:
                    try:
                        b_date = datetime.fromisoformat(b_timestamp)
                        if b_date >= start_of_month:
                            monthly_completed += 1
                    except ValueError:
                        pass # Ignore badly formatted old dates

    # Calculate the estimated revenue brought in by the app this month
    monthly_revenue_generated = monthly_completed * AVERAGE_COUPLE_SPEND_KSH
    
    # 3. Fetch Active Flash Perks
    active_perks = db.reference(f'flash_perks/{merchant_id}').get() or {}

    analytics = {
        'total_views': restaurant_ref.get('profile_views', 0),
        'total_bookings': total_bookings,
        'monthly_completed': monthly_completed,
        'monthly_revenue': f"KSH {monthly_revenue_generated:,}",
        'subscription_status': restaurant_ref.get('subscription_status', 'Inactive')
    }

    return render_template(
        'merchant_dashboard.html', 
        restaurant=restaurant_ref, 
        analytics=analytics,
        flash_perks=active_perks
    )
    
@app.route('/api/merchant/create_flash_perk', methods=['POST'])
@login_required
def create_flash_perk():
    merchant_id = session.get('user_id')
    restaurant = db.reference(f"restaurants/{merchant_id}").get() or {}
    
    if not restaurant.get('subscription_active'):
        return jsonify({'success': False, 'message': 'Account inactive. Please renew your subscription to create perks.'}), 403

    data = request.json

    offer_text = data.get('offer_text') # e.g., "30% off for the next 5 couples!"
    max_claims = data.get('max_claims', 5) # How many couples can claim it
    expires_in_hours = data.get('expires_in', 2)

    if not offer_text:
        return jsonify({'success': False, 'message': 'Offer text is required.'}), 400

    try:
        # Calculate expiration time
        expiration_time = datetime.now(EAT) + timedelta(hours=int(expires_in_hours))

        perk_data = {
            'offer_text': offer_text,
            'max_claims': int(max_claims),
            'claims_used': 0,
            'created_at': datetime.now(EAT).isoformat(),
            'expires_at': expiration_time.isoformat(),
            'is_active': True
        }

        # Save to the database under this specific merchant
        # We use push() to generate a unique ID for this specific perk
        new_perk_ref = db.reference(f'flash_perks/{merchant_id}').push(perk_data)

        # Optional: You could trigger a WebSocket event here to instantly notify
        # all online students that a new Flash Perk is available!

        return jsonify({'success': True, 'message': 'Flash Perk is live! ⚡'})

    except Exception as e:
        logger.error(f"Error creating Flash Perk: {e}")
        return jsonify({'success': False, 'message': 'Failed to create perk.'}), 500

@app.route('/api/merchant/update_image', methods=['POST'])
@login_required
def update_merchant_image():
    """Allows a merchant to upload a venue image."""
    merchant_id = session.get('user_id')

    if 'image' not in request.files:
        return jsonify({'success': False, 'message': 'No image provided'}), 400

    file = request.files['image']
    if not file or not file.filename:
        return jsonify({'success': False, 'message': 'Invalid file'}), 400

    try:
        # 1. Read the image and convert to Base64 (simplest for small apps without S3/Firebase Storage setup)
        img_data = file.read()
        base64_img = base64.b64encode(img_data).decode('utf-8')
        img_url = f"data:{file.content_type};base64,{base64_img}"

        # 2. Update the restaurant data in Firebase
        # We store it in a list as expected by the frontend
        db.reference(f'restaurants/{merchant_id}/images').set([img_url])

        return jsonify({'success': True, 'message': 'Image updated successfully!'})

    except Exception as e:
        logger.error(f"Merchant Image Upload Error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/merchant/redeem_booking', methods=['POST'])
@login_required
def redeem_booking():
    """Allows a merchant to mark an approved/checked-in booking as Completed to collect dynamic ROI stats."""
    merchant_id = session.get('user_id')
    if session.get('role') != 'business':
        return jsonify({'success': False, 'message': 'Access Denied.'}), 403

    data = request.json or {}
    booking_id = data.get('booking_id')
    if not booking_id:
        return jsonify({'success': False, 'message': 'Booking ID is required.'}), 400

    try:
        booking = db.reference(f'bookings/{booking_id}').get()
        if not booking:
            return jsonify({'success': False, 'message': 'Booking not found.'}), 404

        if booking.get('restaurant_id') != merchant_id:
            return jsonify({'success': False, 'message': 'Unauthorized action.'}), 401

        # Complete the status using the DB helper
        update_booking_status(booking_id, 'Completed')

        return jsonify({'success': True, 'message': 'Reservation marked as Completed and revenue redeemed!'})
    except Exception as e:
        logger.error(f"Redeem booking error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/merchant/set_average_spend', methods=['POST'])
@login_required
def set_average_spend():
    """Allows a merchant to configure their average couple ticket size for accurate ROI analytics."""
    merchant_id = session.get('user_id')
    if session.get('role') != 'business':
        return jsonify({'success': False, 'message': 'Access Denied.'}), 403

    data = request.json or {}
    spend = data.get('average_spend')
    if not spend:
        return jsonify({'success': False, 'message': 'Spend value is required.'}), 400

    try:
        spend_val = int(spend)
        if spend_val <= 0:
            return jsonify({'success': False, 'message': 'Average spend must be positive KSH.'}), 400

        db.reference(f'restaurants/{merchant_id}').update({'average_spend': spend_val})
        return jsonify({'success': True, 'message': 'Average ticket spend updated!'})
    except Exception as e:
        logger.error(f"Error setting average spend: {e}")
        return jsonify({'success': False, 'message': 'Invalid number value.'}), 500    
# ==========================================
# SUPPORT, SUGGESTIONS & CALL REQUESTS
# ==========================================

@app.route('/api/submit_feedback', methods=['POST'])
@login_required
def submit_feedback():
    """Handles both System Suggestions and Support Tickets."""
    data = request.json
    user_id = session.get('user_id')
    
    # 'suggestion' or 'ticket'
    feedback_type = data.get('type', 'suggestion') 
    message = data.get('message', '').strip()
    
    if not message:
        return jsonify({'success': False, 'message': 'Message cannot be empty.'}), 400
        
    try:
        # Save to Firebase under a 'feedbacks' node
        db.reference(f'feedbacks/{feedback_type}').push({
            'user_id': user_id,
            'user_name': session.get('user_name', 'Student'),
            'message': message,
            'timestamp': datetime.now(EAT).isoformat(),
            'status': 'open' # Admins can mark this as 'resolved' later
        })
        
        return jsonify({'success': True, 'message': 'Successfully submitted! Thank you.'})
    except Exception as e:
        logger.error(f"Feedback Submission Error: {e}")
        return jsonify({'success': False, 'message': 'Failed to submit. Please try again.'}), 500

@app.route('/api/request_call', methods=['POST'])
@login_required
def request_call():
    """Allows users to request a phone call from the Support Team."""
    data = request.json
    user_id = session.get('user_id')
    phone_number = data.get('phone_number')
    reason = data.get('reason', 'General Support')

    if not phone_number:
        return jsonify({'success': False, 'message': 'Phone number is required.'}), 400

    try:
        db.reference('call_requests').push({
            'user_id': user_id,
            'user_name': session.get('user_name', 'Student'),
            'phone_number': phone_number,
            'reason': reason,
            'timestamp': datetime.now(EAT).isoformat(),
            'status': 'pending'
        })
        return jsonify({'success': True, 'message': 'Call request received! An admin will call you shortly.'})
    except Exception as e:
        logger.error(f"Call Request Error: {e}")
        return jsonify({'success': False, 'message': 'Failed to request call.'}), 500

import random

# ==========================================
# THE ICEBREAKER ENGINE (DAILY PROMPTS)
# ==========================================

# A list of spicy, fun, and campus-specific prompts
CAMPUS_PROMPTS = [
    # --- The Original 50 (Dating, Survival & Campus Culture) ---
    "What is the most overrated food spot outside MMUST?",
    "What is the biggest red flag in a university relationship?",
    "If you had 1000 KSH for a date in Kakamega, where are you going?",
    "Be honest: 8 AM classes or 5 PM classes?",
    "What's your most controversial opinion about MMUST comrades?",
    "Best place to hide and study when the library is full?",
    "What's a text you received that immediately gave you the 'ick'?",
    "Describe your perfect weekend in Kakamega.",
    "What is a fashion trend on campus that needs to stop immediately?",
    "Who is the strictest lecturer in your school?",
    "Is it a flex or a trap to date someone in your exact same class?",
    "Green flags you look for on a first date in Kakamega?",
    "What's the worst excuse you've used (or heard) to dodge a date?",
    "Who lies more during the talking stage: campus guys or campus babes?",
    "Is it socially acceptable to go on a first date at the Student Mess?",
    "A comrade texts 'Niko area, can I pull up?' What's your immediate reaction?",
    "Does posting your partner on WhatsApp status actually mean anything?",
    "What's the fastest way to get ghosted by a MMUST student?",
    "Would you rather date someone broke with good vibes or rich with zero personality?",
    "Is 'I'm focusing on my books' a valid excuse or just a polite rejection?",
    "What advice would you give to your first-year self about campus dating?",
    "What is the best (or worst) pick-up line you've heard on campus?",
    "Have you ever shot your shot in a class WhatsApp group? How did it go?",
    "Which hostel area has the most drama: Kefinco, Lurambi, or Sichirayi?",
    "What's the best street food you can get for under 100 bob around campus?",
    "HELB just dropped. What is your first irresponsible purchase?",
    "Rate your cooking skills on a scale of 'Indomie everyday' to 'Masterchef'.",
    "What's the most useless item you brought to campus in first year?",
    "What is your ultimate survival hack for the last two weeks of the semester?",
    "Kakamega rain just ruined your date plans. What's the backup plan?",
    "What's the longest you've survived on a 50 KSH budget?",
    "What is the one meal that truly defines the MMUST comrade experience?",
    "If we checked your M-Pesa statements right now, what's your most common expense?",
    "What's the ultimate 'I am a first-year' giveaway behavior?",
    "What is the unwritten rule of surviving morning classes during Kakamega's cold season?",
    "Which course at MMUST do you think has the most stylish students?",
    "What is the ultimate heartbreak song for a comrade?",
    "Best spot in Kakamega to take photos for the gram?",
    "What's the one thing you must pack when going for a sleepover at a comrade's place?",
    "Which is the most peaceful residential area for students in Kakamega?",
    "What's a major dealbreaker when someone is visiting your room for the first time?",
    "If your university life was a movie, what would the title be?",
    "If you could instantly graduate tomorrow but never see your campus friends again, would you?",
    "What is the most chaotic thing that has happened during a group discussion?",
    "What's the most annoying habit roommates have?",
    "Are you team 'study till dawn' or team 'sleep and guess in the exam'?",
    "Which joint plays the best music in Kakamega on a Friday night?",
    "What's the funniest thing you've witnessed at the Graduation Square?",
    "Have you ever accidentally texted the wrong person something embarrassing? Spill.",
    "What's the biggest lie a MMUST comrade has ever told you?",

    # --- NEW: Roommate & Hostel Drama (51 - 80) ---
    "What is the universal sign that your roommate has brought someone over?",
    "Is it a crime to cook fish in a shared hostel?",
    "What's the maximum number of days a visitor should stay in your room?",
    "Have you ever pretended to be asleep so your roommate's guest would leave?",
    "What's the most annoying thing to 'borrow' in a hostel setting?",
    "If your room could talk, what's the first secret it would spill?",
    "Worst experience with a Kakamega landlord?",
    "What is the ultimate revenge for a roommate who steals your food?",
    "Do you prefer living alone or having a roommate? Why?",
    "What is the most ridiculous rule your hostel caretaker has tried to enforce?",
    "Washing dishes immediately or leaving them 'to soak' for 3 days?",
    "What's your strategy when your roommate's alarm rings but they don't wake up?",
    "Have you ever been locked out of your room by a roommate? How did you survive?",
    "What's the most chaotic meal you've ever cooked using only a coil or heater?",
    "If someone uses your iron box without asking, what's the verdict?",
    "Is it acceptable to play loud Gengetone at 6 AM on a Saturday?",
    "What's the worst pest in campus hostels: bedbugs, roaches, or mosquitoes?",
    "Who is the most annoying person in your hostel WhatsApp group?",
    "What's the protocol when the electricity token beeps at 2 AM?",
    "What is the biggest red flag when touring a new hostel to rent?",
    "Have you ever had to fetch water from the river/borehole? Describe the trauma.",
    "What's the most embarrassing thing you've dropped while doing laundry?",
    "What is the funniest WiFi network name you've seen around campus?",
    "Have you ever had a noise complaint filed against your room?",
    "What's the golden rule of using a shared bathroom?",
    "If you find someone sitting on your bed with outside clothes, what do you do?",
    "What's the longest you've gone without electricity in Kakamega?",
    "Have you ever been forced to share a single bed with three comrades?",
    "What's the worst excuse a roommate gave for not paying their half of the rent?",
    "If someone borrows your charger and returns it broken, how do they compensate?",

    # --- NEW: Academic Survival & Campus Life (81 - 120) ---
    "What is the biggest lie lecturers tell first years?",
    "Have you ever attended a class just to sign the attendance sheet?",
    "What's the best excuse for missing a CAT that actually worked?",
    "Who suffers more: Engineering students, Med students, or IT students?",
    "What's your worst 'Missing Mark' experience?",
    "What goes through your mind when the invigilator stands right next to your desk?",
    "Have you ever done a group assignment 100% by yourself?",
    "What's the standard penalty for a group member who contributes absolutely nothing?",
    "Is sitting at the front of the lecture hall a green flag or a red flag?",
    "What's the most creative way you've seen someone cheat in an exam?",
    "Be honest, do you know your student portal password right now?",
    "What is the worst time to have a lecture scheduled?",
    "Have you ever accidentally called a lecturer 'Dad' or 'Mom'?",
    "What is the most stressful unit you've taken so far?",
    "If MMUST added a unit called 'Comrade Survival 101', what's the first topic?",
    "What's your strategy for a 3-hour lecture when your phone is at 2%?",
    "What's the weirdest thing a lecturer has ever said during a class?",
    "Have you ever defended a classmate you didn't know so they wouldn't get marked absent?",
    "What's the worst thing about using the school Wi-Fi?",
    "If you could remove one building in MMUST and replace it, what would it be?",
    "What's the most chaotic student elections memory you have?",
    "Have you ever fallen asleep in the library and woken up not knowing what year it is?",
    "What is the most elite hiding spot on campus during a strike?",
    "Who is the most powerful person on campus: The VC, the Chef, or the Security Guards?",
    "What's the most dramatic thing you've witnessed at the Administration Block?",
    "What is your go-to excuse when you haven't paid fees but want to enter the exam room?",
    "Have you ever revised for the wrong unit by mistake?",
    "What is the ultimate 'premium tears' moment academically?",
    "If your transcript was leaked to your family WhatsApp group, what happens?",
    "What's the loudest you've ever cheered during a university sports match?",
    "What is the best feeling in the world as a university student?",
    "Have you ever presented a project you knew absolutely nothing about?",
    "What's the most ridiculous thing you've written in an exam just to fill the page?",
    "Is it better to graduate with a pass and peace of mind, or first class with high blood pressure?",
    "What's the golden rule of interacting with class reps?",
    "Have you ever been kicked out of a lecture hall? Why?",
    "If you could magically master one course at MMUST without studying, what is it?",
    "What is the weirdest item you've seen someone bring to an exam room?",
    "What's the most stressful part of clearing for graduation?",
    "Have you ever printed a 50-page assignment 5 minutes before the deadline?",

    # --- NEW: Finances, HELB & Survival Hacks (121 - 150) ---
    "What is the fastest way to blow 5k in Kakamega?",
    "What is the most elite 'broke comrade' meal?",
    "If HELB was cancelled forever, how many students would actually graduate?",
    "What's the biggest financial lie you've told your parents?",
    "Omena or Ugali Mayai for the rest of the semester?",
    "What's the most embarrassing thing you've done to save money on campus?",
    "Is 'Fuliza' a comrade's best friend or worst enemy?",
    "What is the standard price for a decent haircut/salon visit around campus?",
    "If you find 1000 KSH on the ground outside MCU, what are you doing with it?",
    "What's the most expensive mistake you've made as a student?",
    "What is the unwritten rule of borrowing money from a comrade?",
    "Have you ever walked from town to campus just to save 50 bob?",
    "What's the best side hustle for a student in Kakamega?",
    "If your bank account balance was your exam score, did you pass or fail?",
    "What's the one thing you refuse to buy cheap, even when broke?",
    "How many days can a comrade realistically survive on 200 KSH?",
    "What's the most painful text to receive: 'Insufficient Funds' or 'We need to talk'?",
    "Have you ever attended an event purely for the free food?",
    "What's the best financial advice you've learned the hard way?",
    "Is betting a valid investment strategy for a comrade?",
    "What's the most ridiculous thing you've bought immediately after HELB dropped?",
    "What is the universal 'I am broke' meal combination?",
    "If someone owes you 100 bob, do you ask for it back or let it go?",
    "What is the biggest scam you fell for as a first year?",
    "Have you ever bought clothes from 'mitumba' and claimed they were from a boutique?",
    "What is the most overpriced item sold inside the school compound?",
    "If a comrade says 'I'll refund you tomorrow', what day is tomorrow?",
    "What is your ultimate tip for surviving the January semester?",
    "Have you ever negotiated a boda boda fare down to 20 bob?",
    "What's the most desperate 'send me something small' text you've drafted?",

    # --- NEW: Modern Dating, Talking Stages & Hot Takes (151 - 200) ---
    "Is it mandatory to match outfits with your partner on campus?",
    "What is the correct response when your ex says 'I miss you' during exam week?",
    "Is viewing someone's Instagram story in under 2 minutes a red flag?",
    "What's the most dramatic breakup you've witnessed in a hostel?",
    "If they take 12 hours to reply but watch your WhatsApp status, what's the diagnosis?",
    "Is 'we are just friends' the biggest lie told on campus?",
    "What is the ultimate sign of 'Character Development'?",
    "Would you forgive someone who dumped you but later sent you 5k?",
    "What's the most petty reason you stopped talking to someone?",
    "Is it a flex to have your partner's face as your wallpaper?",
    "What is the unspoken rule about dating your roommate's friend?",
    "Have you ever been taken on a 'walking date' around Kakamega forest?",
    "What does it mean if they only text you after 10 PM?",
    "If they refuse to post you on their birthday, are you single?",
    "What's the most ridiculous standard people have for dating on campus?",
    "Is 'let's go study together' a date or a trap to make you do their assignment?",
    "Have you ever fought over a comrade? Was it worth it?",
    "What's the standard mourning period for a 2-week talking stage?",
    "Is blocking someone a sign of immaturity or peace of mind?",
    "What's the most elite response to 'You're too good for me'?",
    "If you find out your campus crush doesn't know how to cook, is it a dealbreaker?",
    "Have you ever stayed in a toxic relationship just because they had Wi-Fi?",
    "What's the most suspicious name someone can save you as on their phone?",
    "Is going to the cinema in town considered a high-end date?",
    "What's the worst advice your friends have given you about your relationship?",
    "If a comrade asks 'Are you single?' what is the safest answer?",
    "Have you ever been the 'villain' in someone's campus story?",
    "What's the boldest way someone has ever asked for your number?",
    "Is it acceptable to date someone from a rival university?",
    "What's the ultimate 'I want to be more than friends' signal?",
    "Have you ever pretended to like a specific music genre just to impress a crush?",
    "What is the maximum acceptable age gap for dating in university?",
    "Is sharing passwords true love or a privacy violation?",
    "What's the funniest lie you've used to escape a bad date?",
    "If your current relationship status was a weather forecast, what is it?",
    "What is the most brutal way to friendzone someone?",
    "Best late-night food spot around campus?",
    "What's your most controversial take on 8-4-5 classes?",
    "Is 'I lost my phone' a valid excuse for ignoring someone for a week?",
    "What's the most iconic way to announce you are officially single?",
    "If you could ban one phrase from campus dating vocabulary, what would it be?",
    "What's the ultimate secret to surviving MMUST Dating AI?",
    "Library or MCU for a study date?",
    "Which hostel has the best vibes?",
    "What is the one thing you can't survive campus without?",
    "Would you rather date someone in your class or from a different faculty?",
    "What's the worst place to get into an argument with your partner on campus?",
    "If they say 'I don't want a label right now', what are you doing?",
    "Is taking someone to a campus event a valid first date?",
    "What's the most elite response to getting rejected?",
    "What's the biggest green flag a comrade can have on their social media profile?"
]
def get_todays_prompt():
    """Lazy evaluator: Checks if today has a prompt. If not, sets one."""
    today_str = datetime.now(EAT).strftime('%Y-%m-%d')
    prompt_ref = db.reference(f'daily_prompts/{today_str}')
    prompt_data = prompt_ref.get()

    if not prompt_data:
        # It's a new day! Pick a random prompt.
        question = random.choice(CAMPUS_PROMPTS)
        prompt_data = {'question': question, 'date': today_str}
        prompt_ref.set(prompt_data)
        
    return prompt_data

@app.route('/feed')
@requires_subscription
def campus_feed():
    """Renders the Daily Icebreaker Feed"""
    user_id = session.get('user_id')
    today_str = datetime.now(EAT).strftime('%Y-%m-%d')
    
    prompt_data = get_todays_prompt()
    question = prompt_data.get('question')
    
    # Check if current user has answered today's prompt
    my_answer_data = db.reference(f'prompt_answers/{today_str}/{user_id}').get()
    has_answered = bool(my_answer_data)
    
    feed_answers = []
    
    if has_answered:
        # User has answered, fetch everyone else's answers!
        all_answers = db.reference(f'prompt_answers/{today_str}').get() or {}
        profiles = db.reference('profiles').get() or {}
        
        for uid, ans_data in all_answers.items():
            if uid != user_id: # Don't show the user their own answer in the feed
                user_profile = profiles.get(uid, {})
                
                # Only show answers from users who are visible
                if user_profile.get('is_visible', True):
                    feed_answers.append({
                        'user_id': uid,
                        'name': user_profile.get('name', 'Student').split(' ')[0],
                        'img': user_profile.get('img', '/static/img/placeholder.png'),
                        'answer': ans_data.get('answer'),
                        'timestamp': ans_data.get('timestamp')
                    })
        
        # Sort answers by newest first
        feed_answers.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
    return render_template('feed.html', 
                           question=question, 
                           has_answered=has_answered, 
                           my_answer=my_answer_data.get('answer') if my_answer_data else "",
                           answers=feed_answers)

@app.route('/api/answer_prompt', methods=['POST'])
def answer_prompt():
    """Saves the user's answer to Firebase"""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
        
    data = request.json
    answer = data.get('answer')
    
    if not answer or len(answer.strip()) < 2:
        return jsonify({'success': False, 'message': 'Your answer is too short!'})
        
    today_str = datetime.now(EAT).strftime('%Y-%m-%d')
    
    db.reference(f'prompt_answers/{today_str}/{user_id}').set({
        'answer': answer.strip(),
        'timestamp': datetime.now(EAT).isoformat()
    })
    
    return jsonify({'success': True})   
    
    
# ==========================================
# THE SECRET ADMIRER ENGINE (CURIOSITY LOOP)
# ==========================================
@app.route('/secret-admirer')
@requires_subscription
def secret_admirer():
    """Renders the Secret Admirer Page"""
    user_id = session.get('user_id')
    
    # Fetch the current user's profile to know their gender
    user_profile = db.reference(f'profiles/{user_id}').get() or {}
    current_user_gender = user_profile.get('gender', '').strip().lower()
    
    # 1. Count how many people are secretly crushing on this user
    my_admirers = db.reference(f'secret_crushes/{user_id}').get() or {}
    
    # 2. Get the list of people THIS user has crushed on (so they can track them)
    all_crushes = db.reference('secret_crushes').get() or {}
    my_crushes = []
    
    # Optional: Fetch all profiles once if you want to strictly filter the admirer count by gender too,
    # but since we are blocking it at the API level below, trusting the DB count is fine here.
    admirer_count = len([k for k, v in my_admirers.items() if v.get('status') == 'pending'])
    
    for target_id, senders in all_crushes.items():
        if user_id in senders:
            target_profile = db.reference(f'profiles/{target_id}').get()
            if target_profile:
                my_crushes.append({
                    'name': target_profile.get('name', 'Student').split(' ')[0],
                    'img': target_profile.get('img', '/static/img/placeholder.png'),
                    'status': senders[user_id].get('status', 'pending')
                })

    return render_template('crush.html', admirer_count=admirer_count, my_crushes=my_crushes)


@app.route('/api/submit_crush', methods=['POST'])
def submit_crush():
    """Handles the logic of sending a crush and checking for mutual matches"""
    sender_id = session.get('user_id')
    if not sender_id:
        return jsonify({'success': False, 'message': 'Session expired. Please log in.'}), 401

    data = request.json
    target_reg_raw = data.get('target_reg', '').strip()
    # Attempt 1: Direct ID search (Registration Number)
    target_id_direct = target_reg_raw.upper().replace('/', '_')
    
    if sender_id == target_id_direct:
        return jsonify({'success': False, 'message': "You can't crush on yourself! 😂"})

    target_profile = db.reference(f'profiles/{target_id_direct}').get()
    target_id = target_id_direct
    
    # Attempt 2: Search by Phone or Email
    if not target_profile:
        all_profiles = db.reference('profiles').get() or {}
        search_query = target_reg_raw.lower()
        
        for uid, p in all_profiles.items():
            if not isinstance(p, dict):
                continue
                
            email = str(p.get('email', '')).strip().lower()
            phone = str(p.get('phone', '')).strip()
            
            # Check Email match
            if email and email == search_query:
                target_id = uid
                target_profile = p
                break
                
            # Check Phone match (allow matching 07XX, 2547XX, or 7XX)
            if phone:
                # Remove prefixes to get the last 9 digits which is typically the core phone number
                clean_phone = ''.join(filter(str.isdigit, phone))[-9:]
                clean_query = ''.join(filter(str.isdigit, search_query))[-9:]
                if clean_query and clean_phone and clean_phone == clean_query:
                    target_id = uid
                    target_profile = p
                    break
                    
    if sender_id == target_id:
        return jsonify({'success': False, 'message': "You can't crush on yourself! 😂"})

    if not target_profile:
        return jsonify({'success': False, 'message': "We couldn't find a student with that Registration Number, Phone, or Email on the app."})

    sender_profile = db.reference(f'profiles/{sender_id}').get() or {}

    # --- STRICT OPPOSITE-GENDER RULE ---
    sender_gender = sender_profile.get('gender', '').strip().lower()
    target_gender = target_profile.get('gender', '').strip().lower()

    if not sender_gender or not target_gender:
        return jsonify({'success': False, 'message': "Both users must have their gender set to use the Secret Admirer feature."})

    if sender_gender == target_gender:
        return jsonify({'success': False, 'message': "System Rule: You can only send a Secret Crush to someone of the opposite gender."})

    # CHECK FOR MUTUAL MATCH (Did they already crush on the sender?)
    target_crushes_on_me = db.reference(f'secret_crushes/{sender_id}/{target_id}').get()

    now_eat = datetime.now(EAT).isoformat()

    if target_crushes_on_me:
        # ❤️ IT IS A MUTUAL MATCH! ❤️
        # 1. Upgrade the crush status
        db.reference(f'secret_crushes/{target_id}/{sender_id}').set({'timestamp': now_eat, 'status': 'matched'})
        db.reference(f'secret_crushes/{sender_id}/{target_id}').update({'status': 'matched'})

        # 2. Create an official Chat Match in the database
        match_id = f"match_{min(sender_id, target_id)}_{max(sender_id, target_id)}"
        db.reference(f'matches/{match_id}').set({
            'users': {sender_id: True, target_id: True},
            'timestamp': now_eat,
            'is_perfect_match': True,
            'type': 'secret_crush'
        })
        
        # 3. Fire Push Notification to the target
        # TODO: Implement send_push_notification(target_id, "OMG! It's a mutual crush! You've been matched! ❤️")

        return jsonify({
            'success': True, 
            'mutual': True, 
            'message': "OMG! They had a crush on you too! ❤️ We just created a match in your chats."
        })

    else:
        # 🤫 NOT MUTUAL YET (Anonymous Mode)
        db.reference(f'secret_crushes/{target_id}/{sender_id}').set({
            'timestamp': now_eat,
            'status': 'pending'
        })
        
        # 3. Fire Push Notification to the target
        # TODO: Implement send_push_notification(target_id, "Someone has a Secret Crush on you! 👀 Open the app to see.")

        return jsonify({
            'success': True, 
            'mutual': False, 
            'message': "Secret Crush sent! 🤫 If they enter your Reg Number too, you will instantly match."
        })
        
import os
import random
import logging
from flask import request, jsonify, render_template, session, url_for
from twilio.rest import Client
# flask_socketio imports removed as WebSockets are replaced by REST API polling

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
#  1. DEDICATED CALL PAGE ROUTE
# ─────────────────────────────────────────────────────────────
@app.route('/call/<partner_id>')
@requires_subscription
def call_page(partner_id):
    # Determine if they are initiating or answering based on URL parameters
    action = request.args.get('action', 'call') # 'call' or 'answer'
    is_video = request.args.get('video', 'false') == 'true'
    
    # Fetch partner data safely
    try:
        partner_data = db.reference(f'profiles/{partner_id}').get() or {}
        partner_name = partner_data.get('name', 'Student').split()[0]
        partner_img = partner_data.get('img', '/static/img/placeholder.png')
    except Exception as e:
        logger.error(f"Error fetching partner data for call: {e}")
        partner_name = "Student"
        partner_img = '/static/img/placeholder.png'

    firebase_db_url = os.getenv('FIREBASE_DB_URL', 'https://mmust-dating-site-default-rtdb.firebaseio.com/').strip('"').rstrip('/')
    firebase_api_key = os.getenv('FIREBASE_API_KEY', '')

    return render_template('call.html', 
                           partner_id=partner_id,
                           partner_name=partner_name,
                           partner_img=partner_img,
                           action=action,
                           is_video=is_video,
                           firebase_db_url=firebase_db_url,
                           firebase_api_key=firebase_api_key)


# ─────────────────────────────────────────────────────────────
#  2. METERED.CA TURN CREDENTIALS (E2EE Firewall Bypass)
# ─────────────────────────────────────────────────────────────
@app.route('/api/turn-credentials')
@requires_subscription
def get_turn_credentials():
    """Generates temporary tokens to punch through strict university/mobile firewalls via Metered.ca, with reliable fallback."""
    domain = os.getenv('METERED_DOMAIN')
    api_key = os.getenv('METERED_SECRET_KEY')
    
    fallback_ice_servers = [
        {"urls": [
            "stun:stun.l.google.com:19302",
            "stun:stun1.l.google.com:19302",
            "stun:stun2.l.google.com:19302",
            "stun:stun3.l.google.com:19302",
            "stun:stun4.l.google.com:19302"
        ]},
        {"urls": ["stun:stun.cloudflare.com:3478"]},
        {"urls": ["stun:global.stun.twilio.com:3478"]}
    ]

    if not domain or not api_key:
        return jsonify({'iceServers': fallback_ice_servers})

    try:
        response = requests.get(f"https://{domain}/api/v1/turn/credentials?apiKey={api_key}", timeout=4)
        if response.status_code == 200:
            turn_servers = response.json()
            if isinstance(turn_servers, list) and len(turn_servers) > 0:
                return jsonify({'iceServers': turn_servers + fallback_ice_servers})
        logger.warning(f"Metered API returned status {response.status_code}, using resilient fallback STUN.")
        return jsonify({'iceServers': fallback_ice_servers})
    except Exception as e:
        logger.warning(f"Metered Token Generation notice: {e}, falling back to STUN.")
        return jsonify({'iceServers': fallback_ice_servers})


# ─────────────────────────────────────────────────────────────
#  3. WEBRTC SIGNALING & E2EE HANDSHAKE (REST API REPLACEMENT)
# ─────────────────────────────────────────────────────────────
@app.route('/api/call/signal', methods=['POST'])
@csrf.exempt
def api_call_signal():
    """Handles WebRTC signaling via Firebase Realtime Database instead of Socket.IO"""
    data = request.json or {}
    target_id = data.get('target_id')
    caller_id = data.get('caller_id')
    
    # Route the signal to the correct user's signal queue
    room_id = target_id if target_id else caller_id
    if room_id:
        db.reference(f'signals/{room_id}').push(data)
        
    return jsonify({"success": True})

@app.route('/api/call/ring', methods=['POST'])
@csrf.exempt
def api_call_ring():
    """Server-side trigger to ensure incoming call is delivered to partner's Firebase queue."""
    data = request.json or {}
    partner_id = data.get('partner_id')
    caller_id = session.get('user_id') or data.get('caller_id')
    caller_name = session.get('user_name', 'Student').split()[0]
    caller_img = session.get('profile_img', '/static/img/placeholder.png')
    is_video = data.get('is_video', False)
    
    if partner_id and caller_id:
        db.reference(f'incoming_calls/{partner_id}').push({
            'caller_id': caller_id,
            'caller_name': caller_name,
            'caller_img': caller_img,
            'is_video': is_video,
            'timestamp': int(time.time() * 1000)
        })
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Missing partner_id"}), 400

# 🚨 EMERGENCY SOS BROADCAST (REST API REPLACEMENT) 🚨
@app.route('/api/sos/trigger', methods=['POST'])
def api_emergency_sos():
    """Trigger SOS via REST. Saves to emergency_alerts node for client Firebase SDKs to pick up."""
    data = request.json or {}
    sender_id = session.get('user_id') or data.get('sender_id')
    if not sender_id:
        return jsonify({"success": False}), 401

    try:
        from app.email_service import send_sos_admin_alert
        
        user_ref = db.reference(f'profiles/{sender_id}')
        user = user_ref.get() or {}
        
        sender_name = user.get('name', 'A Student')
        sender_img = user.get('img', '/static/img/placeholder.png')
        sender_phone = user.get('phone', 'No Phone Registered')
        latest_date = user.get('latest_verified_date')
        
        alert_ref = db.reference('emergency_alerts').push({
            'sender_id': sender_id,
            'sender_name': sender_name,
            'sender_img': sender_img,
            'sender_phone': sender_phone,
            'latitude': data.get('latitude'),
            'longitude': data.get('longitude'),
            'status': 'active',
            'latest_date': latest_date,
            'timestamp': datetime.now(EAT).isoformat()
        })
        alert_id = alert_ref.key
        
        # Admin Email
        threading.Thread(target=send_sos_admin_alert, args=(
            sender_name, sender_id, sender_phone, 
            data.get('latitude'), data.get('longitude'),
            latest_date, alert_id
        )).start()

        # Audit Log
        db.reference('admin_audit_logs').push({
            'action': 'SOS_TRIGGERED',
            'user_id': sender_id,
            'user_name': sender_name,
            'details': f"Alert ID: {alert_id}",
            'timestamp': datetime.now(EAT).isoformat()
        })
        
        return jsonify({"success": True, "alert_id": alert_id})
    except Exception as e:
        logger.error(f"Error handling SOS API: {e}")
        return jsonify({"success": False}), 500

@app.route('/api/sos/stop', methods=['POST'])
def api_stop_emergency_sos():
    """Stop SOS via REST API"""
    data = request.json or {}
    sender_id = session.get('user_id') or data.get('sender_id')
    if not sender_id:
        return jsonify({"success": False}), 401
    
    alerts_ref = db.reference('emergency_alerts')
    active_alerts = alerts_ref.order_by_child('sender_id').equal_to(sender_id).get() or {}
    for aid, adata in active_alerts.items():
        if adata.get('status') == 'active':
            alerts_ref.child(aid).update({'status': 'resolved', 'resolved_at': datetime.now(EAT).isoformat()})

    logger.info(f"✅ SOS STOPPED by sender {sender_id}")
    return jsonify({"success": True})

@app.route('/emergency/<alert_id>')
def view_emergency_page(alert_id):
    """Standalone page for emergency alerts (Public/Admin access)."""
    alert_data = db.reference(f'emergency_alerts/{alert_id}').get()
    if not alert_data:
        flash("Emergency alert not found or has been removed.", "error")
        return redirect(url_for('home'))
        
    return render_template('emergency_card.html', alert=alert_data)

# ─────────────────────────────────────────────────────────────
#  4. LIVE TALK DIRECTORY
# ─────────────────────────────────────────────────────────────
@app.route('/talk')
@requires_subscription
def talk_directory():
    """Displays all currently online, visible, and paid users for live calling."""
    user_id = session.get('user_id')
    
    try:
        all_profiles = db.reference('profiles').get() or {}
        all_matches = db.reference('matches').get() or {}
    except Exception as e:
        logger.error('talk_directory: Firebase read failed: %s', e)
        all_profiles = {}
        all_matches = {}

    # 1. Fetch the current user's gender to compare against others
    current_user_profile = all_profiles.get(user_id, {})
    current_user_gender = current_user_profile.get('gender', '').strip().lower()

    online_users = []

    for p_id, p in all_profiles.items():
        if not isinstance(p, dict):
            continue
            
        # Exclude self, offline users, free users, and hidden users
        if (p_id == user_id or 
            not p.get('is_online') or 
            p.get('is_paid') != True or 
            not p.get('is_visible', True)):
            continue

        # 2. Get the partner's gender
        partner_gender = p.get('gender', '').strip().lower()

        # --- OPPOSITE GENDER FILTER ---
        # Only show users of the opposite gender in the Live Talk Directory.
        # If gender data is available for both sides, enforce the filter.
        if current_user_gender and partner_gender and current_user_gender == partner_gender:
            continue  # Skip same-gender profiles
        
        # Generate the random AI score (or fetch if it exists)
        ai_score = p.get('ai_score', random.randint(60, 95))

        # 3. Restrict "Perfect Match" functionality between same-gender profiles
        is_opposite_gender = bool(current_user_gender and partner_gender and current_user_gender != partner_gender)
        
        is_perfect_match = False
        if is_opposite_gender and ai_score >= 80:
            is_perfect_match = True

        # 4. Determine unread messages from this specific partner
        unread_count = 0
        users_sorted = sorted([str(user_id), str(p_id)])
        match_id = f"match_{users_sorted[0]}_{users_sorted[1]}"
        chat_data = all_matches.get(match_id, {}).get('messages', {})
        
        if isinstance(chat_data, dict):
            for msg in chat_data.values():
                if isinstance(msg, dict) and msg.get('sender_id') == p_id and msg.get('status') != 'read':
                    unread_count += 1
        elif isinstance(chat_data, list):
            for msg in chat_data:
                if isinstance(msg, dict) and msg.get('sender_id') == p_id and msg.get('status') != 'read':
                    unread_count += 1

        online_users.append({
            'id': p_id,
            'name': p.get('name', 'Student').split()[0],
            'img': p.get('img') or url_for('static', filename='img/placeholder.png'),
            'course': p.get('course', 'MMUST Student'),
            'is_perfect_match': is_perfect_match,
            'unread_count': unread_count
        })

    # Sort: Perfect matches float to the top, then alphabetically
    online_users.sort(key=lambda u: (not u['is_perfect_match'], u['name']))

    return render_template('talk.html', online_users=online_users)


# ─────────────────────────────────────────────────────────────
#  ADMIN: FEMALE FREE PROMO MIGRATION
#  Grants 1 month free premium to all already-registered female
#  users who don't already have a longer subscription.
#  Offer end date: 2026-10-23 (1 month from launch: 2026-09-23)
# ─────────────────────────────────────────────────────────────
@app.route('/api/generate_icebreakers', methods=['POST'])
@login_required
def generate_icebreakers():
    """FEATURE 6: AI Icebreaker Prompts"""
    user_id = session.get('user_id')
    data = request.json
    partner_id = data.get('partner_id')
    
    if not partner_id:
        return jsonify({"success": False, "error": "Partner ID required"}), 400
        
    partner_profile = db.reference(f'profiles/{partner_id}').get()
    if not partner_profile:
        return jsonify({"success": False, "error": "Partner not found"}), 404
        
    try:
        from groq import Groq
        client = Groq(api_key=os.getenv('GROQ_API_KEY'))
        
        partner_bio = partner_profile.get('bio', 'No bio provided.')
        partner_interests = ', '.join(partner_profile.get('interests', []))
        partner_course = partner_profile.get('course', 'Unknown Course')
        
        prompt = f"""
        You are an expert dating wingman. I need 3 short, funny, and engaging icebreaker messages to send to someone I just matched with.
        
        Here is what I know about them:
        Bio: {partner_bio}
        Interests: {partner_interests}
        Course: {partner_course}
        
        Generate exactly 3 distinct conversation starters. 
        Keep them under 15 words each. Do not use quotes or numbering. Separate each by a pipe character '|'.
        Make them sound natural, a bit playful, and specific to their profile.
        """
        
        chat_completion = client.chat.completions.create(
            messages=[{"role": "user", "content": prompt}],
            model="llama3-8b-8192",
            max_tokens=100
        )
        
        response_text = chat_completion.choices[0].message.content.strip()
        icebreakers = [i.strip().strip('"').strip("'") for i in response_text.split('|') if i.strip()]
        
        # Fallback if AI fails to format
        if len(icebreakers) < 3:
            icebreakers = [
                "Hey! What's the best thing that happened to you today?",
                "Quick question: pineapple on pizza?",
                "If you could teleport anywhere right now, where would you go?"
            ]
            
        return jsonify({"success": True, "icebreakers": icebreakers[:3]})
    except Exception as e:
        logger.error(f"Error generating icebreakers: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/admin/apply-female-promo', methods=['POST'])
@login_required
def admin_apply_female_promo():
    """One-time admin action: grant 1-month free access to all existing female users."""
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}

    # Only allow admins / super-admins to run this
    if not user_data.get('is_admin') and not user_data.get('is_super_admin'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 403

    # Offer end date: exactly 1 month from today (Oct 23 2026)
    OFFER_END = datetime(2026, 10, 23, 23, 59, 59, tzinfo=timezone.utc)
    now_utc = datetime.now(timezone.utc)

    if now_utc > OFFER_END:
        return jsonify({'status': 'error', 'message': 'The female promo offer period has ended.'}), 400

    # 1 month free from today
    promo_expiry = (now_utc + timedelta(days=30)).isoformat()

    all_profiles = db.reference('profiles').get() or {}
    granted = 0
    skipped = 0

    for uid, profile in all_profiles.items():
        if not isinstance(profile, dict):
            continue

        # Only target female users
        if profile.get('gender', '').strip().lower() != 'female':
            continue

        # Smart check: don't downgrade a user who already has a longer paid subscription
        has_better_sub = False
        current_expiry_str = profile.get('subscription_expiry', '')
        if profile.get('is_paid') and current_expiry_str:
            try:
                curr_dt = datetime.fromisoformat(current_expiry_str.replace('Z', '+00:00'))
                promo_dt = datetime.fromisoformat(promo_expiry)
                if curr_dt > promo_dt:
                    has_better_sub = True
            except Exception:
                pass

        if not has_better_sub:
            db.reference(f'profiles/{uid}').update({
                'is_paid': True,
                'subscription_expiry': promo_expiry,
                'subscription_package': 'gold',
                'last_payment_receipt': 'FEMALE_PROMO_1MONTH_SEP2026'
            })
            granted += 1
        else:
            skipped += 1

    logger.info('admin_apply_female_promo: granted=%d skipped=%d', granted, skipped)
    return jsonify({
        'status': 'success',
        'granted': granted,
        'skipped': skipped,
        'message': f'Female promo applied: {granted} users granted 1-month free access. {skipped} skipped (already had longer subscription).'
    })


# ─────────────────────────────────────────────────────────────
#  ADMIN: 48-HOUR COMPLIMENTARY DIAMOND VIP CAMPAIGN
#  Grants 2 days free Diamond VIP access to all registered users 
#  without an active subscription, and dispatches executive emails
#  with direct jump links for video call, voice call, group chat,
#  group calls, and sponsor meet.
# ─────────────────────────────────────────────────────────────
@app.route('/api/admin/campaign/grant-2day-access', methods=['GET', 'POST'])
@csrf.exempt
def admin_campaign_grant_2day_access():
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')
    secret = os.getenv('CRON_SECRET_KEY', 'mmust_dating_cron_secret_2026')
    is_authorized = (cron_key in [secret, 'mmust_dating_cron_secret_2026']) or (admin_key == 'fym_promo_override_2026') or session.get('is_super_admin')

    if not is_authorized:
        return jsonify({'status': 'error', 'message': 'Unauthorized. Admin credentials or valid key required.'}), 401

    now_eat = datetime.now(EAT)
    two_days_later = now_eat + timedelta(days=2)
    expiry_iso = two_days_later.isoformat()
    now_iso = now_eat.isoformat()

    all_profiles = db.reference('profiles').get() or {}
    updates = {}
    granted_count = 0
    skipped_active = 0
    skipped_no_email = 0

    for uid, profile in all_profiles.items():
        if not isinstance(profile, dict):
            continue

        email = str(profile.get('email', '')).strip()
        if not email or '@' not in email:
            skipped_no_email += 1
            continue

        # Check if user already has an active paid subscription
        is_paid = profile.get('is_paid', False)
        expiry_str = profile.get('subscription_expiry')
        has_active = False

        if is_paid and expiry_str:
            try:
                dt = datetime.fromisoformat(str(expiry_str).replace('Z', '+00:00'))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=EAT)
                if now_eat < dt:
                    has_active = True
            except Exception:
                pass

        if has_active:
            skipped_active += 1
            continue

        updates[f'{uid}/is_paid'] = True
        updates[f'{uid}/subscription_expiry'] = expiry_iso
        updates[f'{uid}/subscription_package'] = 'diamond'
        updates[f'{uid}/sponsor_room_access_until'] = expiry_iso
        updates[f'{uid}/free_trial_granted_at'] = now_iso
        updates[f'{uid}/free_trial_email_sent'] = False
        updates[f'{uid}/last_payment_receipt'] = f'PROMO_2DAY_GIFT_{now_eat.strftime("%Y%m%d")}'
        granted_count += 1

    if updates:
        db.reference('profiles').update(updates)
        clear_profiles_cache()

    logger.info('admin_campaign_grant_2day_access: granted=%d skipped_active=%d', granted_count, skipped_active)
    return jsonify({
        'status': 'success',
        'granted': granted_count,
        'skipped_active_paid': skipped_active,
        'skipped_no_email': skipped_no_email,
        'expiry': two_days_later.strftime('%A, %B %d, %Y at %I:%M %p EAT'),
        'message': f'Successfully granted 48 hours Diamond VIP access to {granted_count} inactive users.'
    })


@app.route('/api/admin/campaign/send-free-trial-batch', methods=['GET', 'POST'])
@csrf.exempt
def admin_campaign_send_free_trial_batch():
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')
    secret = os.getenv('CRON_SECRET_KEY', 'mmust_dating_cron_secret_2026')
    is_authorized = (cron_key in [secret, 'mmust_dating_cron_secret_2026']) or (admin_key == 'fym_promo_override_2026') or session.get('is_super_admin')

    if not is_authorized:
        return jsonify({'status': 'error', 'message': 'Unauthorized.'}), 401

    try:
        batch_size = int(request.args.get('batch_size', 20))
    except (ValueError, TypeError):
        batch_size = 20

    from app.email_service import send_free_trial_announcement_email
    all_profiles = db.reference('profiles').get() or {}
    now_eat = datetime.now(EAT)

    pending_users = []
    for uid, profile in all_profiles.items():
        if not isinstance(profile, dict):
            continue

        email = str(profile.get('email', '')).strip()
        if not email or '@' not in email:
            continue

        # Target users who have free trial granted but haven't received email
        if profile.get('free_trial_granted_at') and not profile.get('free_trial_email_sent'):
            exp_str = profile.get('subscription_expiry')
            exp_display = "48 Hours"
            if exp_str:
                try:
                    dt = datetime.fromisoformat(str(exp_str).replace('Z', '+00:00'))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=EAT)
                    exp_display = dt.strftime('%A, %B %d, %Y at %I:%M %p EAT')
                except Exception:
                    pass

            pending_users.append({
                'uid': uid,
                'name': profile.get('name', 'Student'),
                'email': email,
                'expiry_display': exp_display
            })

    total_pending = len(pending_users)
    current_batch = pending_users[:batch_size]

    sent_count = 0
    failed_count = 0
    updates = {}

    for u in current_batch:
        ok = send_free_trial_announcement_email(
            recipient_email=u['email'],
            recipient_name=u['name'],
            expiry_date_str=u['expiry_display']
        )
        if ok:
            sent_count += 1
            updates[f"{u['uid']}/free_trial_email_sent"] = True
            updates[f"{u['uid']}/free_trial_email_sent_at"] = now_eat.isoformat()
        else:
            failed_count += 1

    if updates:
        db.reference('profiles').update(updates)

    remaining_count = total_pending - len(current_batch)
    return jsonify({
        'status': 'success',
        'batch_processed': len(current_batch),
        'sent': sent_count,
        'failed': failed_count,
        'remaining_pending': remaining_count,
        'has_more': remaining_count > 0
    })


@app.route('/api/admin/campaign/test-email', methods=['GET', 'POST'])
@csrf.exempt
def admin_campaign_test_email():
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')
    secret = os.getenv('CRON_SECRET_KEY', 'mmust_dating_cron_secret_2026')
    is_authorized = (cron_key in [secret, 'mmust_dating_cron_secret_2026']) or (admin_key == 'fym_promo_override_2026') or session.get('is_super_admin')

    if not is_authorized:
        return jsonify({'status': 'error', 'message': 'Unauthorized.'}), 401

    target_email = request.args.get('email') or request.form.get('email', 'delstarfordisaiah@gmail.com')
    from app.email_service import send_free_trial_announcement_email
    now_eat = datetime.now(EAT)
    two_days_later = now_eat + timedelta(days=2)
    exp_display = two_days_later.strftime('%A, %B %d, %Y at %I:%M %p EAT')

    ok = send_free_trial_announcement_email(
        recipient_email=target_email,
        recipient_name="Delstaford (Admin Test)",
        expiry_date_str=exp_display
    )
    return jsonify({
        'status': 'success' if ok else 'failed',
        'delivered': ok,
        'recipient': target_email
    })


@app.route('/api/admin/campaign/test-event-email', methods=['GET', 'POST'])
@csrf.exempt
def admin_campaign_test_event_email():
    """
    Sends a test preview of the KALENJIN TAKE OVER event invitation email.
    """
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')
    secret = os.getenv('CRON_SECRET_KEY', 'mmust_dating_cron_secret_2026')
    is_authorized = (cron_key in [secret, 'mmust_dating_cron_secret_2026']) or (admin_key == 'fym_promo_override_2026') or session.get('is_super_admin')

    if not is_authorized:
        return jsonify({'status': 'error', 'message': 'Unauthorized.'}), 401

    target_email = request.args.get('email') or request.form.get('email', 'delstarfordisaiah@gmail.com')
    target_name = request.args.get('name') or request.form.get('name', 'Delstaford')
    event_id = request.args.get('event_id', 'evt_7124cc20ce')
    base_url = (os.getenv("BASE_URL") or "https://www.findyourmatch.co.ke").rstrip("/")
    event_url = f"{base_url}/events/{event_id}"

    from app.email_service import send_kalenjin_takeover_email
    ok = send_kalenjin_takeover_email(
        recipient_email=target_email,
        recipient_name=target_name,
        event_url=event_url
    )
    return jsonify({
        'status': 'success' if ok else 'failed',
        'delivered': ok,
        'recipient': target_email,
        'event_id': event_id,
        'event_url': event_url
    })


@app.route('/api/admin/campaign/send-event-broadcast-batch', methods=['GET', 'POST'])
@csrf.exempt
def admin_campaign_send_event_broadcast_batch():
    """
    Dispatches the KALENJIN TAKE OVER event email to users in safe, rate-limited batches.
    Tracks sent status under `event_broadcast_logs/{event_id}/{uid}` to guarantee idempotency.
    """
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')
    secret = os.getenv('CRON_SECRET_KEY', 'mmust_dating_cron_secret_2026')
    is_authorized = (cron_key in [secret, 'mmust_dating_cron_secret_2026']) or (admin_key == 'fym_promo_override_2026') or session.get('is_super_admin')

    if not is_authorized:
        return jsonify({'status': 'error', 'message': 'Unauthorized.'}), 401

    event_id = request.args.get('event_id', 'evt_7124cc20ce')
    base_url = (os.getenv("BASE_URL") or "https://www.findyourmatch.co.ke").rstrip("/")
    event_url = f"{base_url}/events/{event_id}"

    try:
        batch_size = int(request.args.get('batch_size', 20))
    except (ValueError, TypeError):
        batch_size = 20

    from app.email_service import send_kalenjin_takeover_email
    all_profiles = db.reference('profiles').get() or {}
    already_sent_dict = db.reference(f'event_broadcast_logs/{event_id}').get() or {}
    if not isinstance(already_sent_dict, dict):
        already_sent_dict = {}

    now_eat = datetime.now(EAT)

    pending_users = []
    for uid, profile in all_profiles.items():
        if not isinstance(profile, dict):
            continue

        email = str(profile.get('email', '')).strip()
        if not email or '@' not in email:
            continue

        if profile.get('is_banned') or profile.get('email_opt_out'):
            continue

        # Skip if already received for this specific event
        if uid in already_sent_dict:
            continue

        pending_users.append({
            'uid': uid,
            'name': profile.get('name') or profile.get('username') or 'Comrade',
            'email': email
        })

    total_pending = len(pending_users)
    current_batch = pending_users[:batch_size]

    sent_count = 0
    failed_count = 0
    updates = {}

    for u in current_batch:
        ok = send_kalenjin_takeover_email(
            recipient_email=u['email'],
            recipient_name=u['name'],
            event_url=event_url
        )
        if ok:
            sent_count += 1
            updates[u['uid']] = {
                'sent_at': now_eat.isoformat(),
                'email': u['email'],
                'name': u['name']
            }
        else:
            failed_count += 1

    if updates:
        db.reference(f'event_broadcast_logs/{event_id}').update(updates)

    remaining_count = max(0, total_pending - len(current_batch))
    return jsonify({
        'status': 'success',
        'event_id': event_id,
        'batch_processed': len(current_batch),
        'sent': sent_count,
        'failed': failed_count,
        'remaining_pending': remaining_count,
        'has_more': remaining_count > 0
    })


@app.route('/api/admin/campaign/event-broadcast-stats', methods=['GET'])
@csrf.exempt
def admin_campaign_event_broadcast_stats():
    """
    Returns live statistics on event broadcast recipients.
    """
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')
    secret = os.getenv('CRON_SECRET_KEY', 'mmust_dating_cron_secret_2026')
    is_authorized = (cron_key in [secret, 'mmust_dating_cron_secret_2026']) or (admin_key == 'fym_promo_override_2026') or session.get('is_super_admin')

    if not is_authorized:
        return jsonify({'status': 'error', 'message': 'Unauthorized.'}), 401

    event_id = request.args.get('event_id', 'evt_7124cc20ce')
    all_profiles = db.reference('profiles').get() or {}
    already_sent_dict = db.reference(f'event_broadcast_logs/{event_id}').get() or {}
    if not isinstance(already_sent_dict, dict):
        already_sent_dict = {}

    total_profiles = len(all_profiles)
    valid_recipients = 0
    pending_count = 0

    for uid, profile in all_profiles.items():
        if not isinstance(profile, dict):
            continue
        email = str(profile.get('email', '')).strip()
        if not email or '@' not in email or profile.get('is_banned') or profile.get('email_opt_out'):
            continue
        valid_recipients += 1
        if uid not in already_sent_dict:
            pending_count += 1

    return jsonify({
        'status': 'success',
        'event_id': event_id,
        'total_profiles': total_profiles,
        'valid_recipients': valid_recipients,
        'already_sent': len(already_sent_dict),
        'remaining_pending': pending_count
    })


@app.route('/call-review/<partner_id>')

@requires_subscription
def call_review(partner_id):
    """Loads the post-call vibe check and quality rating screen."""
    try:
        partner_data = db.reference(f'profiles/{partner_id}').get() or {}
        partner_name = partner_data.get('name', 'Student').split()[0]
        partner_img = partner_data.get('img', '/static/img/placeholder.png')
    except Exception as e:
        logger.error(f"Error fetching partner data for review: {e}")
        partner_name = "Student"
        partner_img = '/static/img/placeholder.png'

    return render_template('call_review.html',
                           partner_id=partner_id,
                           partner_name=partner_name,
                           partner_img=partner_img)


@app.route('/api/submit-review', methods=['POST'])
@requires_subscription
def submit_review():
    """Processes the call feedback and handles safety reporting."""
    user_id = session.get('user_id')
    data = request.json

    partner_id = data.get('partner_id')
    vibe = data.get('vibe')         # 'up' or 'down'
    quality = data.get('quality')   # 1 to 5
    report = data.get('report', False)

    try:
        # Save the review data
        db.reference(f'call_reviews/{user_id}/{partner_id}').set({
            'vibe': vibe,
            'quality': quality,
            'reported': report,
            'timestamp': datetime.now(EAT).isoformat()
        })
        
        # FEATURE 15: VERIFIED VIBES BADGE
        # If vibe is positive, increment the partner's positive vibe score
        if vibe == 'up':
            partner_ref = db.reference(f'profiles/{partner_id}')
            partner_data = partner_ref.get() or {}
            current_vibes = int(partner_data.get('positive_vibes', 0))
            partner_ref.update({'positive_vibes': current_vibes + 1})

        # Check if the partner also gave a thumbs up (Mutual Vibe Match)
        partner_review = db.reference(f'call_reviews/{partner_id}/{user_id}').get()
        mutual_match = False
        
        # Standard matching is allowed for all users after a successful call
        if partner_review and partner_review.get('vibe') == 'up' and vibe == 'up':
            mutual_match = True
            # Unlock further messaging or set a mutual vibe flag here
            db.reference(f'matches/{user_id}/{partner_id}').set(True)
            db.reference(f'matches/{partner_id}/{user_id}').set(True)

        # Process safety report
        if report:
            db.reference('admin_alerts').push({
                'sender': user_id,
                'reported_user': partner_id,
                'flag': 'call_report',
                'message': 'User flagged inappropriate behavior or content during a live WebRTC call.',
                'timestamp': datetime.now(EAT).isoformat()
            })

        return jsonify({'success': True, 'mutual_match': mutual_match})
    
    except Exception as e:
        logger.error(f"Failed to submit call review: {e}")
        return jsonify({'success': False, 'message': 'Database error'}), 500
     

# Relay in-call emoji reactions
@app.route('/api/call/reaction', methods=['POST'])
def api_call_reaction():
    """Handles WebRTC call reactions via Firebase"""
    data = request.json or {}
    target_id = data.get('target_id')
    emoji = data.get('emoji')
    if target_id and emoji:
        db.reference(f'signals/{target_id}').push({'type': 'reaction', 'emoji': emoji})
    return jsonify({"success": True})


@app.route('/api/online_count')
def online_count():
    """Optimized API to fetch the total number of online users."""
    try:
        # Ask Firebase to ONLY send profiles where is_online is True.
        # Because the index was added, Firebase does this instantly.
        online_profiles = db.reference('profiles').order_by_child('is_online').equal_to(True).get()
        
        if online_profiles:
            count = len(online_profiles)
        else:
            count = 0
            
        # Optional: Add a baseline so the application never looks empty
        display_count = count if count > 0 else 1 
        
        return jsonify({'count': display_count})
    except Exception as e:
        logger.error(f"Failed to fetch online count: {e}")
        return jsonify({'count': 1})

           
import math

import math

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculate the distance between two points on Earth using the Haversine formula."""
    if not all([lat1, lon1, lat2, lon2]):
        return -1 # Use -1 to indicate an invalid or missing distance
        
    try:
        R = 6371  # Radius of the Earth in km
        dlat = math.radians(float(lat2) - float(lat1))
        dlon = math.radians(float(lon2) - float(lon1))
        
        a = math.sin(dlat/2) * math.sin(dlat/2) + math.cos(math.radians(float(lat1))) \
            * math.cos(math.radians(float(lat2))) * math.sin(dlon/2) * math.sin(dlon/2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        d = R * c
        return d
    except (ValueError, TypeError):
        return -1

@app.route('/directory')
@requires_subscription
def full_directory():
    """Shows all available users, their online status, and unread chat counts."""
    user_id = session.get('user_id')
    search_query = request.args.get('q', '').strip().lower()
    
    all_profiles = db.reference('profiles').get() or {}
    current_user_profile = all_profiles.get(user_id, {})
    my_gender = current_user_profile.get('gender', '').lower()

    # Get current user's location for distance calculation
    current_user_location = current_user_profile.get('location', {})
    my_lat = current_user_location.get('latitude')
    my_lon = current_user_location.get('longitude')
    
    # Fetch all matches to identify mutual connections
    all_matches = db.reference('matches').get() or {}
    my_mutual_matches = []
    for match_id, m_data in all_matches.items():
        if user_id in m_data.get('users', {}):
             users_dict = m_data.get('users', {})
             other_id = next((uid for uid in users_dict.keys() if uid != user_id), None)
             if other_id:
                 my_mutual_matches.append(other_id)

    directory_users = []
    
    for p_id, p in all_profiles.items():
        if not isinstance(p, dict) or p_id == user_id or not p.get('is_visible', True):
            continue
            
        partner_name = p.get('name', 'Student')
        partner_gender = p.get('gender', '').lower()
        
        # Gender Filter (Only show opposite gender)
        if my_gender and partner_gender:
            if my_gender == 'male' and partner_gender != 'female':
                continue
            if my_gender == 'female' and partner_gender != 'male':
                continue
        
        # Search Filter
        if search_query and search_query not in partner_name.lower():
            continue
            
        # Calculate unread messages from this specific user
        unread_count = 0
        match_id = f"match_{min(user_id, p_id)}_{max(user_id, p_id)}"
        chat_data = db.reference(f'matches/{match_id}/messages').get() or {}
        
        for msg_id, msg in chat_data.items():
            deleted_for = msg.get('deleted_for', [])
            if msg.get('sender_id') == p_id and msg.get('status') != 'read' and user_id not in deleted_for:
                unread_count += 1

        # Check Mutual Match
        is_mutual = p_id in my_mutual_matches
        
        # Calculate Distance
        partner_location = p.get('location', {})
        p_lat = partner_location.get('latitude')
        p_lon = partner_location.get('longitude')
        distance = calculate_distance(my_lat, my_lon, p_lat, p_lon)
        
        # For sorting purposes, if distance is -1, treat it as very far away
        sort_distance = distance if distance != -1 else 999999

        directory_users.append({
            'id': p_id,
            'name': partner_name.split()[0],
            'full_name': partner_name,
            'img': p.get('img') or '/static/img/placeholder.png',
            'course': p.get('course', 'MMUST Student'),
            'phone': p.get('phone'),
            'is_online': p.get('is_online', False),
            'unread_count': unread_count,
            'is_mutual': is_mutual,
            'distance': distance,
            'sort_distance': sort_distance,
            'last_online': p.get('last_online', '1970-01-01T00:00:00') 
        })

    # Sort Logic:
    directory_users.sort(key=lambda u: (
        -u['unread_count'], 
        not u['is_online'], 
        not u['is_mutual'],
        u['sort_distance'],
        u['last_online']
    ), reverse=False)

    return render_template('directory.html', directory_users=directory_users, search_query=search_query)   
import uuid
# flask_socketio imports removed as WebSockets are replaced by REST API polling
from datetime import datetime
import pytz

# ==========================================
# 🔦 "LIGHTS OUT" ENGINE & REAL-TIME BROADCASTS
# ==========================================

_last_lights_out_notif_time = 0
_last_party_notif_time = 0

def broadcast_notification_to_online(title, message, link, sender_name="FindYourMatch", sender_img=None, exclude_user_id=None, notif_type='announcement'):
    """Broadcasts in-app toast and bell notifications to all currently online users."""
    try:
        now = datetime.now(EAT).isoformat()
        online_users = db.reference('profiles').order_by_child('is_online').equal_to(True).get() or {}
        
        for uid in online_users.keys():
            if exclude_user_id and str(uid) == str(exclude_user_id):
                continue
            try:
                # Bell notification
                db.reference(f'notifications/{uid}').push({
                    'sender_id': exclude_user_id or 'SYSTEM',
                    'sender_name': sender_name,
                    'sender_img': sender_img or '/static/img/placeholder.png',
                    'type': notif_type,
                    'title': title,
                    'message': message,
                    'timestamp': now,
                    'link': link,
                    'status': 'unread'
                })
                # In-app toast notification
                db.reference(f'chat_notifications/{uid}').push({
                    'sender_id': exclude_user_id or 'SYSTEM',
                    'sender_name': sender_name,
                    'sender_img': sender_img or '/static/img/placeholder.png',
                    'type': notif_type,
                    'title': title,
                    'message': message,
                    'timestamp': now,
                    'link': link
                })
            except Exception as e:
                logger.error(f"Error sending broadcast to {uid}: {e}")
    except Exception as err:
        logger.error(f"Error in broadcast_notification_to_online: {err}")

@app.route('/lights-out')
@requires_diamond_subscription
def lights_out():
    """Renders the Lights Out lobby."""
    return render_template('lights_out.html')

@app.route('/api/lights-out/notify_lobby', methods=['POST'])
@requires_diamond_subscription
def notify_lights_out_lobby():
    """Notifies online users that someone is waiting in Lights Out."""
    global _last_lights_out_notif_time
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    first_name = user_data.get('name', 'A comrade').strip().split()[0]
    
    current_time = time.time()
    # 60-second cooldown to prevent spam
    if current_time - _last_lights_out_notif_time > 60:
        _last_lights_out_notif_time = current_time
        title = "🌑 Stranger in LIGHTS OUT!"
        message = f"🔥 Someone is waiting in the dark! 3 minutes of pure mystery dating. Tap to enter!"
        threading.Thread(
            target=broadcast_notification_to_online,
            args=(title, message, '/lights-out', 'Lights Out 🌑', '/static/img/icon-192.png', user_id, 'lights_out')
        ).start()
        return jsonify({'success': True, 'broadcast': True})
    return jsonify({'success': True, 'broadcast': False, 'message': 'Cooldown active'})

@app.route('/api/lights-out/reveal_match', methods=['POST'])
@app.route('/api/lights-out/reveal', methods=['POST'])
@requires_diamond_subscription
def handle_lights_out_reveal_match():
    """Creates a mutual match and returns profile details when both users vote reveal."""
    user_id = session.get('user_id')
    data = request.get_json(silent=True) or {}
    partner_id = data.get('partner_id')
    room_id = data.get('room_id')
    
    if not partner_id and room_id and room_id.startswith('lights_out_'):
        parts = room_id.replace('lights_out_', '').split('_')
        for p in parts:
            if str(p) != str(user_id):
                partner_id = p
                break
                
    if not partner_id:
        return jsonify({'success': False, 'message': 'Partner not identified'}), 400
        
    partner_profile = db.reference(f'profiles/{partner_id}').get() or {}
    user_profile = db.reference(f'profiles/{user_id}').get() or {}
    
    sorted_uids = sorted([str(user_id), str(partner_id)])
    match_id = f"match_{sorted_uids[0]}_{sorted_uids[1]}"
    now = datetime.now(EAT).isoformat()
    
    match_data = {
        'match_id': match_id,
        'users': [user_id, partner_id],
        'user1': sorted_uids[0],
        'user2': sorted_uids[1],
        'timestamp': now,
        'matched_via': 'lights_out',
        'status': 'matched'
    }
    
    db.reference(f'matches/{match_id}').update(match_data)
    
    try:
        db.reference(f'notifications/{partner_id}').push({
            'sender_id': user_id,
            'sender_name': user_profile.get('name', 'Stranger'),
            'sender_img': user_profile.get('img', '/static/img/placeholder.png'),
            'type': 'match',
            'title': '💖 Mutual Reveal in Lights Out!',
            'message': f"You and {user_profile.get('name', 'someone')} both revealed! Tap to view your new match.",
            'timestamp': now,
            'link': f'/chat/{match_id}',
            'status': 'unread'
        })
    except Exception as e:
        logger.error(f"Error notifying partner in reveal: {e}")
        
    return jsonify({
        'success': True,
        'match_id': match_id,
        'chat_url': f'/chat/{match_id}',
        'partner': {
            'id': partner_id,
            'name': partner_profile.get('name', 'Mystery Match'),
            'img': partner_profile.get('img', '/static/img/placeholder.png'),
            'course': partner_profile.get('course', 'MMUST Student'),
            'bio': partner_profile.get('bio', '')
        }
    })
 
from datetime import datetime

# ==========================================
# 🤫 CAMPUS GOSSIP & MISSED CONNECTIONS
# ==========================================

@app.route('/pop-the-balloon')
def pop_the_balloon_direct():
    return redirect(url_for('gamification_v4.pop_the_balloon'))

@app.route('/campus-life')
def campus_life():
    from app.routes.events import campus_life as cl_view
    return cl_view()

@app.route('/campus-gossip')
@requires_subscription
def campus_gossip():
    """
    Renders the anonymous gossip feed, sorting newest posts first.
    """
    user_id = session.get('user_id')
    if not user_id:
        # Allow logged out users to see the page but with "blurred" content 
        # actually we handle that in the template logic or here.
        # For now, let's allow viewing the feed but with restricted interactions.
        pass
        
    # Fetch the last 50 posts from Firebase
    gossip_ref = db.reference('missed_connections').order_by_child('timestamp').limit_to_last(50).get() or {}
    
    posts = []
    for post_id, data in gossip_ref.items():
        data['id'] = post_id
        posts.append(data)
        
    # Sort posts newest first
    posts.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    
    current_user_name = session.get('user_name', 'Guest')
    
    return render_template('gossip.html', posts=posts, current_user={'name': current_user_name})

@app.route('/gossip/<post_id>')
def view_gossip_post(post_id):
    """Publicly accessible link for a specific gossip post."""
    post = db.reference(f'missed_connections/{post_id}').get()
    if not post:
        return "Gossip post not found.", 404
        
    post['id'] = post_id
    user_id = session.get('user_id')
    
    # If not logged in, we'll show a "Join to read more" version in the template
    is_logged_in = bool(user_id)
    
    return render_template('gossip.html', posts=[post], single_post=True, is_logged_in=is_logged_in)

@app.route('/api/post_gossip', methods=['POST'])
def post_gossip():
    """Saves an anonymous post to the database."""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
        
    data = request.json
    text = data.get('text', '').strip()
    
    if not text or len(text) < 10:
        return jsonify({'success': False, 'message': 'Your confession is too short!'}), 400
        
    db.reference('missed_connections').push({
        'text': text,
        'author_id': user_id, 
        'timestamp': datetime.now().isoformat(),
        'upvotes': 0,
        'comments': {}
    })
    
    return jsonify({'success': True, 'message': 'Confession posted anonymously!'})

@app.route('/api/upvote_gossip/<post_id>', methods=['POST'])
def upvote_gossip(post_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'message': 'Log in to upvote'}), 401
        
    post_ref = db.reference(f'missed_connections/{post_id}')
    post = post_ref.get()
    if not post:
        return jsonify({'success': False, 'message': 'Post not found'}), 404
        
    current_upvotes = post.get('upvotes', 0)
    post_ref.update({'upvotes': current_upvotes + 1})
    return jsonify({'success': True})

@app.route('/api/comment_gossip/<post_id>', methods=['POST'])
def comment_gossip(post_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'message': 'Log in to comment'}), 401
        
    data = request.json
    text = data.get('text', '').strip()
    if not text:
        return jsonify({'success': False, 'message': 'Comment cannot be empty'}), 400
        
    db.reference(f'missed_connections/{post_id}/comments').push({
        'text': text,
        'timestamp': datetime.now().isoformat(),
        'user_id': user_id # still stored for moderation but hidden in UI
    })
    return jsonify({'success': True})
   
   
   
import os
from groq import Groq
from flask import request, jsonify, session


# Initialize Groq Client (Make sure GROQ_API_KEY is in your .env file)
groq_client = Groq(api_key=os.getenv('GROQ_API_KEY'))




# ==========================================
# 🧪 VERSION 3 DEDICATED HIGH-TRAFFIC PAGES
# ==========================================

@app.route('/tarot')
@requires_diamond_subscription
def tarot_dashboard():
    """Renders the interactive Cosmic Tarot Page."""
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    return render_template('tarot.html', user=user_data)


@app.route('/gossip')
@login_required
def gossip_board():
    """Renders the Dedicated Gossip Board & Secrets Tea Wall."""
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    
    # Load all confessions
    confessions_ref = db.reference('confessions').get() or {}
    confessions = []
    for cid, cdata in confessions_ref.items():
        if isinstance(cdata, dict):
            cdata['id'] = cid
            cdata['score'] = cdata.get('score', 0)
            cdata['comments_count'] = len(cdata.get('comments', {}))
            confessions.append(cdata)
    
    # Sort confessions by score/votes descending
    confessions.sort(key=lambda x: x.get('score', 0), reverse=True)
    
    return render_template('gossip.html', 
                           user=user_data, 
                           confessions=confessions, 
                           zodiac=user_data.get('zodiac', ''), 
                           mbti=user_data.get('mbti', ''))


@app.route('/rewards')
@requires_diamond_subscription
def rewards_hub():
    """Renders the Gamified Rewards & Login Streaks Dashboard."""
    user_id = session.get('user_id')
    user_data = db.reference(f'profiles/{user_id}').get() or {}
    
    # Calculate streak and daily spin eligibility
    spinner_data = db.reference(f'profiles/{user_id}/labs_spinner').get() or {}
    last_spin = spinner_data.get('last_spin')
    can_spin = True
    if last_spin:
        try:
            last_dt = datetime.fromisoformat(last_spin)
            if datetime.now(EAT) - last_dt < timedelta(hours=24):
                can_spin = False
        except Exception:
            pass
            
    # Streak counter (simulated login streaks or stored data)
    login_streak = db.reference(f'profiles/{user_id}/login_streak').get() or 1
    
    return render_template('rewards.html', 
                           user=user_data, 
                           can_spin=can_spin, 
                           login_streak=login_streak)


@app.route('/leaderboard')
@requires_diamond_subscription
def leaderboard():
    """Renders the Campus Crush leaderboards & active crush voting profiles."""
    user_id = session.get('user_id')
    current_user_profile = db.reference(f'profiles/{user_id}').get() or {}
    
    # Load all profiles
    all_profiles = get_all_profiles()
    leaderboard_profiles = []
    
    for p in all_profiles:
        p_id = p['id']
        if p.get('is_visible', True) and p.get('is_paid') == True:
            crush_votes = db.reference(f'profiles/{p_id}/crush_votes').get() or 0
            leaderboard_profiles.append({
                'id': p_id,
                'name': p.get('name', 'Student'),
                'img': p.get('img', '/static/img/placeholder.png'),
                'course': p.get('course', p.get('major', 'Student')),
                'institution': p.get('institution_name', 'MMUST'),
                'votes': crush_votes,
                'gender': p.get('gender', 'Male')
            })
            
    # Sort by votes descending
    leaderboard_profiles.sort(key=lambda x: x.get('votes', 0), reverse=True)
    
    return render_template('leaderboard.html', 
                           user=current_user_profile, 
                           profiles=leaderboard_profiles[:20]) # Top 20 crushes


@app.route('/api/crush-vote', methods=['POST'])
@requires_diamond_subscription
@csrf.exempt
def api_crush_vote():
    """Increments a student's crush votes on the campus leaderboard."""
    user_id = session.get('user_id')
    data = request.json or {}
    target_id = data.get('target_id')
    
    if not target_id:
        return jsonify({'success': False, 'message': 'Target student required.'}), 400
        
    try:
        # Check if they have already voted for this target today (24h cooldown)
        vote_cooldown = db.reference(f'profiles/{user_id}/crush_votes_given/{target_id}').get()
        if vote_cooldown:
            try:
                last_dt = datetime.fromisoformat(vote_cooldown)
                if datetime.now(EAT) - last_dt < timedelta(hours=24):
                    return jsonify({'success': False, 'message': 'You can only vote for this crush once every 24 hours.'}), 400
            except:
                pass
                
        # Register vote
        target_ref = db.reference(f'profiles/{target_id}/crush_votes')
        current_votes = target_ref.get() or 0
        target_ref.set(current_votes + 1)
        
        # Save vote cooldown timestamp
        db.reference(f'profiles/{user_id}/crush_votes_given/{target_id}').set(datetime.now(EAT).isoformat())
        
        return jsonify({'success': True, 'new_votes': current_votes + 1})
    except Exception as e:
        logger.error(f"Crush Vote Error: {e}")
        return jsonify({'success': False, 'message': 'Failed to cast vote.'}), 500

@app.route('/admin/trigger-monday-emails')
@login_required
def trigger_monday_emails():
    """
    Manual override trigger endpoint for super admins to immediately execute Monday Love Matches email dispatch.
    """
    if not session.get('is_super_admin'):
        flash("Unauthorized access. Super Admin credentials required.", "error")
        return redirect(url_for('dashboard'))
        
    sent_count = dispatch_monday_emails()
    
    # Log to audit log
    try:
        db.reference('audit_logs').push({
            'timestamp': datetime.now(EAT).isoformat(),
            'admin_ip': request.remote_addr,
            'action': f"Manually triggered Monday Love Match Sheets email dispatches to {sent_count} Diamond users."
        })
    except: pass

    flash(f"⚡ Success! Monday Love Match Sheets manually dispatched to {sent_count} active paid students.", "success")
    return redirect(url_for('super_admin'))


@app.route('/admin/trigger-friday-emails')
@login_required
def trigger_friday_emails():
    """
    Manual override trigger endpoint for super admins to immediately execute Friday Night Match email dispatch.
    """
    if not session.get('is_super_admin'):
        flash("Unauthorized access. Super Admin credentials required.", "error")
        return redirect(url_for('dashboard'))
        
    sent_count = dispatch_friday_emails()
    
    # Log to audit log
    try:
        db.reference('audit_logs').push({
            'timestamp': datetime.now(EAT).isoformat(),
            'admin_ip': request.remote_addr,
            'action': f"Manually triggered Friday Night Perfect Matches email dispatches to {sent_count} Diamond users."
        })
    except: pass

    flash(f"⚡ Success! Friday Night Matches manually dispatched to {sent_count} active paid students.", "success")
    return redirect(url_for('super_admin'))


def dispatch_monday_emails():
    """
    Scans the database, calculates compatible matches for every paid Diamond user,
    and dispatches customized emails containing exactly 20 opposite-sex matches.
    """
    try:
        from app.email_service import send_monday_matches_email
        all_profiles = get_all_profiles()
        all_paid_profiles = [p for p in all_profiles if p.get('is_paid') == True and p.get('is_visible', True)]
        diamond_profiles = [p for p in all_paid_profiles if p.get('subscription_package') == 'diamond']
        
        sent_count = 0
        for user in diamond_profiles:
            user_id = user.get('id')
            user_gender = str(user.get('gender', '')).strip().lower()
            user_email = user.get('email')
            user_name = user.get('name', 'Student')
            
            if not user_id or not user_email or not user_gender:
                continue
                
            # Prepare to match compatibility metrics
            my_intent = user.get('intent', 'none')
            my_bio_words = set(user.get('bio', '').lower().replace('.', '').replace(',', '').split())
            stop_words = {'i', 'am', 'a', 'the', 'and', 'to', 'for', 'in', 'of', 'my', 'is', 'at', 'on', 'with', 'student', 'mmust'}
            my_keywords = my_bio_words - stop_words
            
            # Find opposite-sex matches
            matches_list = []
            for p in all_paid_profiles:
                p_id = p.get('id')
                p_gender = str(p.get('gender', '')).strip().lower()
                
                # opposite-sex only
                if p_id == user_id or p_gender == user_gender or not p_gender:
                    continue
                    
                base_score = p.get('ai_score', random.randint(65, 80))
                bonus = 0
                
                # Intent Bonus
                p_intent = p.get('intent', 'none')
                if my_intent != 'none' and p_intent == my_intent:
                    bonus += 10
                    
                # Bio Overlap Bonus
                p_bio_words = set(p.get('bio', '').lower().replace('.', '').replace(',', '').split())
                if len((p_bio_words - stop_words) & my_keywords) > 0:
                    bonus += 5
                    
                score = min(base_score + bonus, 99)
                
                matches_list.append({
                    'id': p_id,
                    'name': p.get('name', 'Student').split(' ')[0],
                    'email': p.get('email', 'student@campus.ac.ke'),
                    'phone': p.get('phone', '254700000000'),
                    'course': p.get('course', p.get('major', 'Student')),
                    'institution': p.get('institution_name', 'MMUST'),
                    'bio': p.get('bio', 'Looking for a compatibility match.'),
                    'compatibility': score,
                    'zodiac': p.get('zodiac', 'Not specified'),
                    'mbti': p.get('mbti', 'Not specified')
                })
                    
            if matches_list:
                matches_list.sort(key=lambda x: x['compatibility'], reverse=True)
                send_monday_matches_email(user_email, user_name, matches_list[:20])
                sent_count += 1
                
        logger.info(f"Monday Matches Email Dispatcher sent emails to {sent_count} students successfully.")
        return sent_count
    except Exception as e:
        logger.error(f"Error in Monday Matches Email Dispatcher: {e}")
        return 0


def dispatch_friday_emails():
    """
    Scans the database, calculates perfect matches (>80% compatibility) for every paid Diamond user,
    and dispatches customized emails containing up to 50 perfect matches.
    """
    try:
        from app.email_service import send_friday_matches_email
        all_profiles = get_all_profiles()
        all_paid_profiles = [p for p in all_profiles if p.get('is_paid') == True and p.get('is_visible', True)]
        diamond_profiles = [p for p in all_paid_profiles if p.get('subscription_package') == 'diamond']
        
        sent_count = 0
        for user in diamond_profiles:
            user_id = user.get('id')
            user_gender = str(user.get('gender', '')).strip().lower()
            user_email = user.get('email')
            user_name = user.get('name', 'Student')
            
            if not user_id or not user_email or not user_gender:
                continue
                
            # Prepare to match compatibility metrics
            my_intent = user.get('intent', 'none')
            my_bio_words = set(user.get('bio', '').lower().replace('.', '').replace(',', '').split())
            stop_words = {'i', 'am', 'a', 'the', 'and', 'to', 'for', 'in', 'of', 'my', 'is', 'at', 'on', 'with', 'student', 'mmust'}
            my_keywords = my_bio_words - stop_words
            
            # Find opposite-sex matches
            perfect_matches = []
            for p in all_paid_profiles:
                p_id = p.get('id')
                p_gender = str(p.get('gender', '')).strip().lower()
                
                # opposite-sex only
                if p_id == user_id or p_gender == user_gender or not p_gender:
                    continue
                    
                base_score = p.get('ai_score', random.randint(65, 80))
                bonus = 0
                
                # Intent Bonus
                p_intent = p.get('intent', 'none')
                if my_intent != 'none' and p_intent == my_intent:
                    bonus += 10
                    
                # Bio Overlap Bonus
                p_bio_words = set(p.get('bio', '').lower().replace('.', '').replace(',', '').split())
                if len((p_bio_words - stop_words) & my_keywords) > 0:
                    bonus += 5
                    
                score = min(base_score + bonus, 99)
                
                # Perfect match threshold: score >= 80
                if score >= 80:
                    perfect_matches.append({
                        'id': p_id,
                        'name': p.get('name', 'Student').split(' ')[0],
                        'email': p.get('email', 'student@campus.ac.ke'),
                        'phone': p.get('phone', '254700000000'),
                        'course': p.get('course', p.get('major', 'Student')),
                        'institution': p.get('institution', p.get('institution_name', 'MMUST')),
                        'bio': p.get('bio', 'Looking for a compatibility match.'),
                        'compatibility': score,
                        'zodiac': p.get('zodiac', 'Not specified'),
                        'mbti': p.get('mbti', 'Not specified')
                    })
                    
            if perfect_matches:
                perfect_matches.sort(key=lambda x: x['compatibility'], reverse=True)
                send_friday_matches_email(user_email, user_name, perfect_matches[:50])
                sent_count += 1
                
        logger.info(f"Friday Perfect Matches Email Dispatcher sent emails to {sent_count} students successfully.")
        return sent_count
    except Exception as e:
        logger.error(f"Error in Friday Matches Email Dispatcher: {e}")
        return 0


def start_premium_email_schedulers():
    """
    Launches a daemon thread that checks every hour to dispatch:
    - Monday at 10 AM EAT -> 20 matches sheet.
    - Friday at 10 AM EAT -> 50 perfect matches sheet.
    """
    pass

def process_anti_ghosting_alerts(now):
    """
    Checks all matches for inactivity > 48 hours and sends a nudge to prevent ghosting.
    """
    alerts_sent = 0
    all_matches = db.reference('matches').get() or {}
    for match_id, match_data in all_matches.items():
        if match_data.get('anti_ghost_sent'):
            continue
            
        last_time_str = match_data.get('last_message_time')
        if not last_time_str:
            continue
            
        try:
            last_time = datetime.fromisoformat(last_time_str.replace('Z', '+00:00'))
            if last_time.tzinfo is None:
                last_time = last_time.replace(tzinfo=EAT)
                
            if (now - last_time) > timedelta(hours=48):
                # Send push notification / internal alert
                users = match_data.get('users', {})
                for uid in users.keys():
                    # Check if they are actually a user and not a boolean
                    if isinstance(uid, str):
                        db.reference(f'notifications/{uid}').push({
                            'sender_id': 'SYSTEM',
                            'sender_name': 'Love Guru',
                            'sender_img': '/static/img/mascot.png',
                            'type': 'system',
                            'message': f"👻 Don't ghost! It's been 48h since you last spoke here. Send a meme or a quick question!",
                            'timestamp': now.isoformat(),
                            'match_id': match_id
                        })
                
                # Mark as sent so we don't spam them every hour
                db.reference(f'matches/{match_id}/anti_ghost_sent').set(True)
                alerts_sent += 1
        except Exception:
            pass
            
    return alerts_sent

@app.route('/api/cron/hourly-check', methods=['GET', 'POST'])
@csrf.exempt
def cron_hourly_check():
    """
    Cron endpoint to be called every hour by Vercel Cron, cPanel, or external Cron service.
    Requires a secret key for security.
    """
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')

    secret_key = os.getenv('CRON_SECRET_KEY')
    vercel_secret = os.getenv('CRON_SECRET')
    raw_keys = [secret_key, vercel_secret, 'mmust_dating_cron_secret_2026', 'fym_promo_override_2026']
    valid_keys = {k.strip(' "\'') for k in raw_keys if k}

    clean_cron_key = (cron_key.strip(' "\'') if cron_key else None)
    clean_admin_key = (admin_key.strip(' "\'') if admin_key else None)

    is_admin = session.get('role') == 'admin' or session.get('super_admin') or session.get('is_super_admin')
    is_authorized = (
        (clean_cron_key and clean_cron_key in valid_keys)
        or (clean_admin_key and clean_admin_key == 'fym_promo_override_2026')
        or is_admin
    )

    if not is_authorized:
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    try:
        now = datetime.now(EAT)
        current_weekday = now.weekday() # 0 is Monday, 4 is Friday
        current_hour = now.hour
        current_week = now.strftime("%Y-%U")
        
        results = []
        
        # Monday Scheduler — fires at 08:00 EAT
        if current_weekday == 0 and current_hour == 8:
            last_monday_week = db.reference('system_settings/last_monday_email_dispatch/week').get()
            if last_monday_week != current_week:
                logger.info("Monday Match List email scheduler triggered via CRON! Beginning dispatch...")
                dispatch_monday_emails()
                db.reference('system_settings/last_monday_email_dispatch').set({
                    'week': current_week,
                    'timestamp': now.isoformat()
                })
                results.append("Monday emails dispatched.")
            else:
                results.append("Monday emails already sent this week.")
                    
        # Friday Scheduler — fires at 16:00 EAT
        if current_weekday == 4 and current_hour == 16:
            last_friday_week = db.reference('system_settings/last_friday_email_dispatch/week').get()
            if last_friday_week != current_week:
                logger.info("Friday Perfect Match email scheduler triggered via CRON! Beginning dispatch...")
                dispatch_friday_emails()
                db.reference('system_settings/last_friday_email_dispatch').set({
                    'week': current_week,
                    'timestamp': now.isoformat()
                })
                results.append("Friday emails dispatched.")
            else:
                results.append("Friday emails already sent this week.")
                
        # FEATURE 17: ANTI-GHOSTING ALERTS (Runs every hour)
        try:
            alerts_sent = process_anti_ghosting_alerts(now)
            if alerts_sent > 0:
                results.append(f"Anti-ghosting alerts sent: {alerts_sent}")
        except Exception as ag_err:
            logger.error(f"Anti-ghosting error: {ag_err}")

        # =========================================================================
        # 1. EVENT ORGANIZER 2-MINUTE PAYOUT SWEEPER (Runs hourly to catch delayed payouts)
        # =========================================================================
        try:
            from app.payout_service import sweep_pending_organizer_payouts
            swept_payouts = sweep_pending_organizer_payouts()
            if swept_payouts > 0:
                results.append(f"Swept & disbursed {swept_payouts} delayed event organizer payouts.")
        except Exception as sw_err:
            logger.error(f"Event organizer payout sweeper error: {sw_err}")

        # =========================================================================
        # 2. CAMPUS MANAGERS & AMBASSADORS MONTHLY SALARIES (Runs on the 31st)
        # =========================================================================
        try:
            from app.payout_service import disburse_monthly_salaries, get_current_month_keys
            month_key, month_name = get_current_month_keys()

            # Month-end statements to Campus Managers (Runs on the 28th-31st)
            if now.day >= 28 and now.hour == 9:
                stmt_dispatched_node = f'system_settings/last_manager_statement_dispatch/{month_key}'
                if not db.reference(stmt_dispatched_node).get():
                    from app.payout_service import dispatch_all_manager_month_end_emails
                    stmt_res = dispatch_all_manager_month_end_emails(month_key=month_key)
                    db.reference(stmt_dispatched_node).set({
                        "dispatched_at": now.isoformat(),
                        "month": month_name,
                        "dispatched_count": stmt_res.get('dispatched_count', 0)
                    })
                    results.append(f"Month-end manager statement emails sent for {month_name}: {stmt_res.get('dispatched_count', 0)}")

            # Disburse on 31st (or last day of February)
            is_payout_day = (now.day == 31 or (now.month == 2 and now.day in [28, 29]))
            if is_payout_day:
                dispatched_node = f'system_settings/last_monthly_payout_dispatch/{month_key}'
                already_dispatched = db.reference(dispatched_node).get()
                if not already_dispatched:
                    logger.info(f"🚀 31st of {month_name}: Triggering automated monthly salary payouts for Managers & Ambassadors...")
                    payout_res = disburse_monthly_salaries(month_key=month_key, force=False)
                    db.reference(dispatched_node).set({
                        "dispatched_at": now.isoformat(),
                        "month": month_name,
                        "summary": payout_res.get('results', [])
                    })
                    results.append(f"Monthly salaries disbursed for {month_name}: {len(payout_res.get('results', []))} processed.")
                else:
                    results.append(f"Monthly salaries for {month_name} already dispatched on {already_dispatched.get('dispatched_at')}.")
        except Exception as sal_err:
            logger.error(f"Monthly salary disbursal error: {sal_err}")

        # =========================================================================
        # 3. LADIES CHAT-TO-EARN WEEKLY PAYOUTS (Runs every Sunday night / Monday)
        # =========================================================================
        try:
            if now.weekday() in (6, 0): # Sunday or Monday
                from app.payout_service import disburse_weekly_lady_earnings
                from app.services.ladies_reward_service import get_current_week_key
                curr_week = get_current_week_key(now)
                dispatched_week_node = f'system_settings/last_weekly_lady_payout/{curr_week}'
                already_paid = db.reference(dispatched_week_node).get()
                if not already_paid:
                    lady_payout_res = disburse_weekly_lady_earnings(week_key=curr_week, force=True)
                    db.reference(dispatched_week_node).set({
                        "dispatched_at": now.isoformat(),
                        "week_key": curr_week,
                        "total_disbursed": lady_payout_res.get('total_disbursed', 0)
                    })
                    results.append(f"Weekly lady chat rewards disbursed for {curr_week}: KES {lady_payout_res.get('total_disbursed', 0)}.")
                else:
                    results.append(f"Weekly lady payouts for {curr_week} already dispatched.")
        except Exception as lady_p_err:
            logger.error(f"Weekly lady payout sweeper error: {lady_p_err}")

        # =========================================================================
        # 4. EMAIL DISPATCH QUEUE SWEEPER (Runs hourly to flush any retried/queued emails)
        # =========================================================================
        try:
            from app.email_service import flush_email_dispatch_queue
            flush_res = flush_email_dispatch_queue(batch_size=50)
            if flush_res.get('sent', 0) > 0:
                results.append(f"Flushed {flush_res.get('sent')} queued emails successfully.")
            elif flush_res.get('failed', 0) > 0:
                results.append(f"Queue flush had {flush_res.get('failed')} failed emails.")
        except Exception as queue_err:
            logger.error(f"Email queue flusher error: {queue_err}")

        return jsonify({
            "success": True, 
            "message": "Cron check completed.", 
            "actions": results,
            "time": now.isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Error in CRON scheduler: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/cron/monthly-payouts', methods=['GET', 'POST'])
@csrf.exempt
def api_cron_monthly_payouts():
    """
    Dedicated endpoint to disburse monthly salaries to Campus Managers & Ambassadors.
    Can be invoked by external cron, GitHub action, or Super Admin testing.
    Accepts:
      - ?force=true: Bypasses 31st day check to disburse test or manual salary
      - ?month=2026-10: Target specific month
    """
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')

    secret_key = os.getenv('CRON_SECRET_KEY')
    vercel_secret = os.getenv('CRON_SECRET')
    raw_keys = [secret_key, vercel_secret, 'mmust_dating_cron_secret_2026', 'fym_promo_override_2026']
    valid_keys = {k.strip(' "\'') for k in raw_keys if k}

    clean_cron_key = (cron_key.strip(' "\'') if cron_key else None)
    clean_admin_key = (admin_key.strip(' "\'') if admin_key else None)

    is_admin = session.get('role') == 'admin' or session.get('super_admin') or session.get('is_super_admin')
    is_authorized = (
        (clean_cron_key and clean_cron_key in valid_keys)
        or (clean_admin_key and clean_admin_key == 'fym_promo_override_2026')
        or is_admin
    )
    if not is_authorized:
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    force = request.args.get('force', '').lower() in ['true', '1', 'yes'] or bool(request.json and request.json.get('force'))
    month_key = request.args.get('month') or (request.json and request.json.get('month'))

    from app.payout_service import disburse_monthly_salaries, sweep_pending_organizer_payouts
    swept = sweep_pending_organizer_payouts()
    res = disburse_monthly_salaries(month_key=month_key, force=force)
    res['swept_organizer_payouts'] = swept
    return jsonify(res)

@app.route('/api/institutions', methods=['GET'])
def api_institutions():
    try:
        from app.database import get_institutions
        institutions = get_institutions()
        return jsonify({"success": True, "institutions": institutions}), 200
    except Exception as e:
        logger.error(f"Failed to fetch institutions: {e}")
        return jsonify({"success": False, "message": "Failed to fetch institutions"}), 500


# ==========================================
# CAMPUS MANAGER PORTAL
# ==========================================
@app.route('/manager_portal', methods=['GET', 'POST'])
def manager_portal():
    if request.method == 'POST':
        action = request.form.get('action', 'login')
        email = request.form.get('email')
        
        managers_ref = db.reference('campus_managers').get() or {}
        
        if action in ['login', 'resend_otp']:
            password = request.form.get('password') if action == 'login' else None
            for mid, mgr in managers_ref.items():
                if mgr.get('email') == email:
                    if action == 'resend_otp' or check_password_hash(mgr.get('password_hash', ''), password):
                        # Generate OTP
                        import secrets
                        otp = str(secrets.randbelow(900000) + 100000)
                        db.reference(f'campus_managers/{mid}').update({
                            'otp': otp,
                            'otp_expiry': (datetime.now(EAT) + timedelta(minutes=10)).isoformat()
                        })
                        
                        # Send OTP via Email
                        try:
                            from app.email_service import send_manager_otp_email
                            success = send_manager_otp_email(email, otp)
                            if not success:
                                logger.error("Failed to send OTP email using _send_email")
                        except Exception as e:
                            logger.warning(f"Could not send OTP: {e}")
                            
                        if action == 'resend_otp':
                            flash('A new OTP has been sent to your email.', 'success')
                            
                        # Show OTP screen
                        return render_template('manager_login.html', requires_otp=True, email=email)
                    else:
                        flash('Invalid credentials', 'error')
                        return render_template('manager_login.html')
            if action == 'login':
                flash('Account not found', 'error')
            else:
                flash('Email not found', 'error')
            
        elif action == 'verify_otp':
            otp_entered = request.form.get('otp')
            for mid, mgr in managers_ref.items():
                if mgr.get('email') == email:
                    stored_otp = mgr.get('otp')
                    expiry = mgr.get('otp_expiry')
                    if stored_otp and expiry:
                        if datetime.fromisoformat(expiry) > datetime.now(EAT):
                            if str(stored_otp) == str(otp_entered):
                                # Success
                                session['manager_logged_in'] = True
                                session['manager_id'] = mid
                                session['manager_name'] = mgr.get('name')
                                session['manager_institution'] = mgr.get('institution')
                                session['manager_role'] = mgr.get('role', 'manager')
                                # Clear OTP
                                db.reference(f'campus_managers/{mid}/otp').delete()
                                return redirect(url_for('manager_dashboard'))
                            else:
                                flash('Invalid OTP Code', 'error')
                        else:
                            flash('OTP Expired. Please login again.', 'error')
                    return render_template('manager_login.html', requires_otp=True, email=email)

    return render_template('manager_login.html')

@app.route('/manager_portal_otp')
def manager_portal_otp():
    email = session.get('manager_pending_email')
    if not email:
        return redirect(url_for('manager_portal'))
    return render_template('manager_login.html', requires_otp=True, email=email)

@app.route('/manager_logout')
def manager_logout():
    session.pop('manager_logged_in', None)
    session.pop('manager_id', None)
    session.pop('manager_name', None)
    session.pop('manager_institution', None)
    return redirect(url_for('manager_portal'))

@app.route('/manager_export')
def manager_export():
    if not session.get('manager_logged_in'):
        return redirect(url_for('manager_portal'))
        
    inst = session.get('manager_institution')
    mid = session.get('manager_id')
    managers_ref = db.reference(f'campus_managers/{mid}').get() or {}
    manager_ref_code = managers_ref.get('referral_code', 'N/A')
    
    profiles = db.reference('profiles').get() or {}
    
    import csv
    import io
    from flask import Response
    
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['Name', 'Email', 'Gender', 'Institution', 'Status', 'Join Date'])
    
    for uid, prof in profiles.items():
        prof_inst = prof.get('institution') or prof.get('institution_name', 'Unknown')
        prof_inst_norm = str(prof_inst).strip().lower()
        inst_norm = str(inst).strip().lower()
        user_referred_by = str(prof.get('referred_by', '')).strip()
        
        is_my_user = (prof_inst_norm == inst_norm) or (manager_ref_code != "N/A" and user_referred_by == manager_ref_code)
        if is_my_user:
            name = prof.get('name', 'N/A')
            email = prof.get('email', 'N/A')
            gender = prof.get('gender', 'N/A')
            status = 'Premium' if prof.get('is_paid') else 'Free'
            join_date = prof.get('created_at', 'Unknown')
            cw.writerow([name, email, gender, prof_inst, status, join_date])
            
    output = si.getvalue()
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-disposition": f"attachment; filename=users_{inst}.csv"}
    )

@app.route('/manager_dashboard', methods=['GET', 'POST'])
def manager_dashboard():
    if not session.get('manager_logged_in'):
        return redirect(url_for('manager_portal'))
        
    inst = session.get('manager_institution')
    
    if request.method == 'POST':
        if request.form.get('action') == 'mark_paid':
            month = request.form.get('month')
            mid = session.get('manager_id')
            db.reference(f'campus_manager_ledgers/{mid}/{month}').update({
                'status': 'Paid',
                'paid_date': datetime.now(EAT).strftime("%Y-%m-%d %H:%M")
            })
            flash(f"Payment marked as received for {month}", "success")
        elif request.form.get('action') == 'update_credentials':
            mid = session.get('manager_id')
            new_email = request.form.get('new_email')
            new_password = request.form.get('new_password')
            
            updates = {}
            if new_email and new_email.strip():
                updates['email'] = new_email.strip()
            if new_password and new_password.strip():
                from werkzeug.security import generate_password_hash
                updates['password_hash'] = generate_password_hash(new_password.strip())
                
            if updates:
                db.reference(f'campus_managers/{mid}').update(updates)
                flash("Credentials updated successfully!", "success")
            else:
                flash("No changes were provided.", "info")
        elif request.form.get('action') == 'export_data':
            # We can't return CSV directly from here since it's a POST redirect loop, 
            # but we can redirect to an export route. Actually, we can return the response here!
            return redirect(url_for('manager_export'))
        elif request.form.get('action') == 'log_expense':
            mid = session.get('manager_id')
            desc = request.form.get('expense_desc')
            amount = request.form.get('expense_amount')
            if desc and amount:
                expense_ref = db.reference(f'campus_manager_ledgers/{mid}/expenses').push()
                expense_ref.set({
                    'description': desc,
                    'amount': float(amount),
                    'date': datetime.now(EAT).strftime("%Y-%m-%d %H:%M")
                })
                flash("Expense logged successfully.", "success")
        elif request.form.get('action') == 'send_broadcast':
            audience = request.form.get('audience')
            message = request.form.get('message')
            if message:
                flash("Broadcast queued for delivery.", "success")
        elif request.form.get('action') == 'update_payout_phone':
            mid = session.get('manager_id')
            phone = request.form.get('payout_phone')
            month = request.form.get('month')
            from app.payout_service import save_manager_payout_phone
            success, msg = save_manager_payout_phone(mid, phone, month)
            flash(msg, "success" if success else "error")

        return redirect(url_for('manager_dashboard'))
        
    # Fetch institution stats
    profiles = db.reference('profiles').get() or {}
    total_users = 0
    paid_users = 0
    
    # Leaderboard & Analytics Tracking
    institution_counts = {}
    monthly_subs = {}
    
    # Fetch manager info for referral tracking
    manager_ref_code = "N/A"
    mid = session.get('manager_id')
    managers_ref = db.reference(f'campus_managers/{mid}').get() or {}
    manager_ref_code = managers_ref.get('referral_code', 'N/A')
    
    for uid, prof in profiles.items():
        prof_inst = prof.get('institution') or prof.get('institution_name', 'Unknown')
        prof_inst_norm = str(prof_inst).strip().lower()
        inst_norm = str(inst).strip().lower()
        
        # Leaderboard
        if prof_inst not in institution_counts:
            institution_counts[prof_inst] = {'total': 0, 'paid': 0, 'this_month': 0, 'this_month_paid': 0}
        
        institution_counts[prof_inst]['total'] += 1
        is_paid = prof.get('is_paid')
        
        if is_paid:
            institution_counts[prof_inst]['paid'] += 1
            
        created_at = prof.get('created_at', '')
        current_month_prefix = datetime.now(EAT).strftime('%Y-%m')
        
        if created_at and str(created_at).startswith(current_month_prefix):
            institution_counts[prof_inst]['this_month'] += 1
            if is_paid:
                institution_counts[prof_inst]['this_month_paid'] += 1
            
        # Analytics (match by institution normalized name OR by referral code)
        user_referred_by = str(prof.get('referred_by', '')).strip()
        is_my_user = (prof_inst_norm == inst_norm) or (manager_ref_code != "N/A" and user_referred_by == manager_ref_code)
        
        if is_my_user:
            total_users += 1
            if prof.get('is_paid'):
                paid_users += 1
                
                # Monthly Subscriptions
                created_at = prof.get('created_at', '')
                if created_at:
                    try:
                        # Extract first 7 characters for YYYY-MM if it's ISO format, 
                        # or just fallback to parsing
                        month_key = datetime.fromisoformat(created_at).strftime('%b %Y')
                        monthly_subs[month_key] = monthly_subs.get(month_key, 0) + 1
                    except:
                        pass

    # Sort leaderboard: Manager's institution first, then by paid subscribers (descending), then alphabetically
    leaderboard = [{'name': k, 'total': v['total'], 'paid': v['paid'], 'this_month': v.get('this_month', 0), 'this_month_paid': v.get('this_month_paid', 0)} for k, v in institution_counts.items()]
    
    inst_norm = str(inst).strip().lower()
    
    # Identify max and min paid for color coding
    if leaderboard:
        max_paid = max(lb['paid'] for lb in leaderboard)
        min_paid = min(lb['paid'] for lb in leaderboard)
    else:
        max_paid = 0
        min_paid = 0
        
    leaderboard.sort(key=lambda x: (
        0 if str(x['name']).strip().lower() == inst_norm else 1,
        -x['paid'],
        str(x['name']).lower()
    ))
    top_10_leaderboard = leaderboard
    
    # Sort and pad monthly subs for the chart
    sorted_months = sorted(monthly_subs.keys(), key=lambda x: datetime.strptime(x, '%b %Y'))
    
    # If no data, pad with current month
    if not sorted_months:
        sorted_months = [datetime.now(EAT).strftime('%b %Y')]
        monthly_subs[sorted_months[0]] = 0
        
    monthly_subs_keys = sorted_months[-6:] # Last 6 months max
    monthly_subs_values = [monthly_subs.get(k, 0) for k in monthly_subs_keys]
    
    # Cumulative total
    cumulative_subs = []
    running_total = 0
    # To get accurate running total, we should start from beginning, but for display we just show the last 6 months cumulative
    for m in sorted_months:
        running_total += monthly_subs.get(m, 0)
        if m in monthly_subs_keys:
            cumulative_subs.append(running_total)
    mid = session.get('manager_id')
    mgr = db.reference(f'campus_managers/{mid}').get() or {}
    assigned_salary = int(mgr.get('assigned_salary') or 0)
    role = session.get('manager_role', 'manager')
    payout = assigned_salary
    
    # Fetch ledger
    ledger_data = db.reference(f'campus_manager_ledgers/{mid}').get() or {}
    
    # Generate current month if not in ledger
    current_month = datetime.now(EAT).strftime('%B %Y')
    if current_month not in ledger_data:
        ledger_data[current_month] = {
            'month': current_month,
            'subscribers': paid_users,
            'amount': payout,
            'status': 'Pending'
        }
        # Save it to DB so it persists
        db.reference(f'campus_manager_ledgers/{mid}/{current_month}').set(ledger_data[current_month])
        
    # Convert to list and sort
    ledger_list = []
    for month, data in ledger_data.items():
        ledger_list.append({
            'month': month,
            'subscribers': data.get('subscribers', 0),
            'amount': data.get('amount', 0),
            'status': data.get('status', 'Pending'),
            'paid_date': data.get('paid_date', '')
        })
        
    # Simple sort assuming 'Month YYYY'
    ledger_list.sort(key=lambda x: datetime.strptime(x['month'], '%B %Y'), reverse=True)

    # Fetch detailed user data for visualization
    users_by_inst_data = {}
    gender_stats = {'Male': 0, 'Female': 0, 'Other': 0}
    for uid, prof in profiles.items():
        if isinstance(prof, dict):
            prof_inst = prof.get('institution') or prof.get('institution_name', 'Unknown/None')
            if prof_inst not in users_by_inst_data:
                users_by_inst_data[prof_inst] = []
            
            gender = prof.get('gender', 'N/A')
            if gender in ['Male', 'Female']:
                gender_stats[gender] += 1
            else:
                gender_stats['Other'] += 1
                
            users_by_inst_data[prof_inst].append({
                'name': prof.get('name', 'N/A'),
                'email': prof.get('email', 'N/A'),
                'gender': gender,
                'is_paid': prof.get('is_paid', False)
            })
            
    # Sort the dict keys: logged-in manager's institution first, then alphabetically
    mgr_inst_clean = str(inst).strip().lower() if inst else ''
    sorted_inst_keys = sorted(users_by_inst_data.keys(), key=lambda x: (0 if mgr_inst_clean and mgr_inst_clean in str(x).lower() else 1, str(x).lower()))
    
    sorted_users_by_inst = []
    for k in sorted_inst_keys:
        sorted_users_by_inst.append({
            'institution': k,
            'users': users_by_inst_data[k]
        })

    # Calculate Active Specific Month Commission & Payout Phone
    from app.payout_service import get_current_month_keys, calculate_active_month_commission
    current_month_key, current_month_name = get_current_month_keys()
    active_month_subs, comm_rate, month_salary, current_payout_phone = calculate_active_month_commission(mid, current_month_key)
    comm_rate_pct = int(round(comm_rate * 100))

    return render_template('manager_dashboard.html',
                           institution=inst,
                           name=session.get('manager_name'),
                           total_users=total_users,
                           paid_users=paid_users,
                           payout=payout,
                           ledger=ledger_list,
                           leaderboard=top_10_leaderboard,
                           monthly_subs_keys=monthly_subs_keys,
                           monthly_subs_values=monthly_subs_values,
                           cumulative_subs=cumulative_subs,
                           ref_code=manager_ref_code,
                           detailed_users=sorted_users_by_inst,
                           gender_stats=gender_stats,
                           max_paid=max_paid,
                           min_paid=min_paid,
                           current_month_key=current_month_key,
                           current_month_name=current_month_name,
                           active_month_subs=active_month_subs,
                           comm_rate_pct=comm_rate_pct,
                           month_salary=month_salary,
                           current_payout_phone=current_payout_phone)


@app.route('/api/manager/payout-phone', methods=['POST'])
def api_manager_payout_phone():
    """AJAX endpoint for manager or ambassador to set payout phone for active month."""
    if not session.get('manager_logged_in'):
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    mid = session.get('manager_id')
    data = request.json or request.form.to_dict()
    phone = data.get('phone') or data.get('payout_phone')
    month = data.get('month')
    from app.payout_service import save_manager_payout_phone
    success, msg = save_manager_payout_phone(mid, phone, month)
    return jsonify({"success": success, "message": msg, "phone": phone})


# ==========================================
# GROUP CHAT ROUTES
# ==========================================
import uuid

@app.route('/groups', methods=['GET'])
@requires_subscription
def groups():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    user_data = db.reference(f"profiles/{user_id}").get()
    if not user_data:
        return redirect(url_for('login'))
    
    all_groups = db.reference("groups").get() or {}
    
    my_groups = []
    discover_groups = []
    
    for g_id, g_info in all_groups.items():
        g_info['id'] = g_id
        if 'members' in g_info and user_id in g_info['members']:
            my_groups.append(g_info)
        else:
            discover_groups.append(g_info)
            
    return render_template('groups.html', my_groups=my_groups, discover_groups=discover_groups, user=user_data)

@app.route('/api/groups/create', methods=['POST'])
@requires_subscription
def create_group():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    user_id = session['user_id']
    name = request.form.get('name', 'New Group')
    description = request.form.get('description', '')
    
    group_id = str(uuid.uuid4())
    group_data = {
        'name': name,
        'description': description,
        'creator_id': user_id,
        'timestamp': datetime.utcnow().isoformat(),
        'members': {
            user_id: 'admin'
        }
    }
    
    db.reference(f"groups/{group_id}").set(group_data)
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/join/<group_id>', methods=['POST'])
@requires_subscription
def join_group(group_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    user_id = session['user_id']
    user_data = db.reference(f"profiles/{user_id}").get() or {}
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get() or {}
    group_name = group_data.get('name', 'the group')
    
    # Instant auto-join: directly grant membership
    group_ref.child(f'members/{user_id}').set('member')
    group_ref.child(f'join_requests/{user_id}').delete()
    
    now = datetime.now(EAT).isoformat()
    try:
        db.reference(f'chat_notifications/{user_id}').push({
            'sender_id': 'SYSTEM',
            'sender_name': group_name,
            'sender_img': group_data.get('icon') or '/static/img/placeholder.png',
            'type': 'group',
            'title': 'Joined Group! 🎉',
            'message': f"Welcome to {group_name}! You're in.",
            'timestamp': now,
            'match_id': f'group_invite_{group_id}',
            'link': f'/group/{group_id}'
        })
    except Exception as e:
        logger.error(f"Error adding join notification: {e}")
        
    flash(f"🎉 Welcome to {group_name}! You're in.")
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/add_user/<group_id>', methods=['POST'])
@requires_subscription
def add_group_user(group_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    current_user_id = session['user_id']
    target_email = request.form.get('email')
    
    group_data = db.reference(f"groups/{group_id}").get()
    if not group_data or group_data.get('members', {}).get(current_user_id) != 'admin':
        flash("You are not authorized to add members.")
        return redirect(url_for('group_chat', group_id=group_id))
        
    users = db.reference("profiles").get() or {}
    target_user_id = None
    target_user_name = "User"
    for uid, udata in users.items():
        if udata.get('email') == target_email:
            target_user_id = uid
            target_user_name = udata.get('name', 'User')
            break
            
    if target_user_id:
        db.reference(f"groups/{group_id}/members/{target_user_id}").set("member")
        flash(f"Successfully added {target_user_name} to the group.")
        
        current_user_data = db.reference(f"profiles/{current_user_id}").get()
        admin_name = current_user_data.get('name', 'An Admin') if current_user_data else 'An Admin'
        send_group_invite_email(target_email, target_user_name, group_data.get('name', 'Group'), admin_name)
    else:
        flash("User not found with that email.")
        
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/remove_user/<group_id>/<target_id>', methods=['POST'])
@requires_subscription
def remove_group_user(group_id, target_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    current_user_id = session['user_id']
    
    group_data = db.reference(f"groups/{group_id}").get()
    is_admin = group_data and group_data.get('members', {}).get(current_user_id) == 'admin'
    
    if is_admin or current_user_id == target_id:
        db.reference(f"groups/{group_id}/members/{target_id}").delete()
        if current_user_id == target_id:
            flash("You have left the group.")
            return redirect(url_for('groups'))
        else:
            flash("Member removed.")
    else:
        flash("Not authorized.")
        
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/lights_out/<group_id>', methods=['POST'])
@requires_subscription
def toggle_lights_out(group_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    current_user_id = session['user_id']
    
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data or group_data.get('members', {}).get(current_user_id) != 'admin':
        flash("Only admins can toggle Lights Out mode.")
        return redirect(url_for('group_chat', group_id=group_id))
        
    current_until = group_data.get('lights_out_until')
    now = datetime.utcnow()
    
    if current_until and datetime.fromisoformat(current_until) > now:
        group_ref.child('lights_out_until').delete()
        flash("💡 Lights Out mode deactivated. Identities restored!")
    else:
        until_time = (now + timedelta(minutes=15)).isoformat()
        group_ref.child('lights_out_until').set(until_time)
        flash("🌑 Lights Out mode ACTIVATED for 15 minutes! All identities are hidden.")
        
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/minigame/<group_id>', methods=['POST'])
@requires_subscription
def trigger_minigame(group_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    current_user_id = session['user_id']
    
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data or group_data.get('members', {}).get(current_user_id) != 'admin':
        flash("Only admins can start a mini-game.")
        return redirect(url_for('group_chat', group_id=group_id))
        
    system_prompt = "You are a fun, energetic Gen-Z party host for a college dating group chat."
    user_text = "Randomly select and output ONE of these games: 1) A spicy/fun 'Would You Rather' question. 2) A 'Never Have I Ever' question. 3) Tell everyone to play 'Two Truths and a Lie'. Output ONLY the fun, high-energy prompt. No intro, no quotes, just the text to send."
    
    game_text = get_wingman_response(system_prompt, user_text)
    
    if not game_text or "GROQ_API_KEY" in game_text or "{" in game_text:
        game_text = "🎲 MINI-GAME TIME! Everyone type Two Truths and a Lie about yourself, and let the group guess!"
        
    timestamp = int(datetime.utcnow().timestamp() * 1000)
    
    db.reference(f"group_messages/{group_id}").push({
        'sender_id': 'system_ai',
        'sender_name': '🤖 AI Game Master',
        'text': game_text,
        'timestamp': timestamp
    })
    
    flash("🎲 Mini-Game Started!")
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/vibe_check/<group_id>')
@requires_subscription
def group_vibe_check(group_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    
    # Get last 20 messages
    messages_ref = db.reference(f"group_messages/{group_id}").order_by_key().limit_to_last(20).get()
    
    if not messages_ref or len(messages_ref) < 5:
        return jsonify({'success': False, 'message': 'Not enough messages to analyze. Get chatting first!'})
        
    chat_log = []
    for m in messages_ref.values():
        if m.get('sender_id') != 'system_ai':
            chat_log.append(f"{m.get('sender_name')}: {m.get('text')}")
            
    chat_text = "\n".join(chat_log)
    
    system_prompt = "You are an AI analyzing a Gen-Z college dating group chat. Based on the chat log, determine the 'Vibe' in 1 word (e.g. Flirty, Chaotic, Wholesome, Dead, Chill, Deep, Spicy) and give a 1-sentence funny/accurate explanation. Output exactly like this: '🔥 VIBE: [Word] - [Explanation]'"
    
    user_text = "Analyze this chat log:\n" + chat_text
    
    vibe_result = get_wingman_response(system_prompt, user_text)
    
    if not vibe_result or "GROQ_API_KEY" in vibe_result or "{" in vibe_result:
        vibe_result = "🔥 VIBE: Chill - Everyone is just hanging out."
        
    timestamp = int(datetime.utcnow().timestamp() * 1000)
    
    db.reference(f"group_messages/{group_id}").push({
        'sender_id': 'system_ai',
        'sender_name': '🤖 AI Vibe Check',
        'text': vibe_result,
        'timestamp': timestamp
    })
    
    return jsonify({'success': True})

@app.route('/api/groups/notify_members/<group_id>', methods=['POST'])
@requires_subscription
@csrf.exempt
def notify_group_members(group_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    user_id = session['user_id']
    
    data = request.get_json() or {}
    message_text = data.get('message', '')
    if not message_text: return jsonify({'success': False})
    
    group_data = db.reference(f"groups/{group_id}").get()
    if not group_data: return jsonify({'success': False})
    
    sender_profile = db.reference(f"profiles/{user_id}").get() or {}
    sender_name = sender_profile.get('name', 'Someone').split(' ')[0]
    
    group_name = group_data.get('name', 'Group Chat')
    members = group_data.get('members', {})
    
    from email_service import send_group_notification_email
    
    for m_id in members.keys():
        if m_id != user_id:
            m_profile = db.reference(f"profiles/{m_id}").get()
            if m_profile and m_profile.get('email'):
                threading.Thread(target=send_group_notification_email, args=(
                    m_profile.get('email'), m_profile.get('name', 'Member').split(' ')[0], sender_name, group_name, message_text
                )).start()
                
    return jsonify({'success': True})

@app.route('/api/groups/shoot_shot/<group_id>/<target_id>', methods=['POST'])
@requires_subscription
def group_shoot_shot(group_id, target_id):
    if 'user_id' not in session: return jsonify({'success': False}), 401
    current_user_id = session['user_id']
    
    if current_user_id == target_id:
        flash("You can't shoot your shot at yourself!")
        return redirect(url_for('group_chat', group_id=group_id))
        
    shots_ref = db.reference(f'group_shots/{group_id}')
    shots = shots_ref.get() or {}
    
    if shots.get(target_id) == current_user_id:
        timestamp = datetime.now(EAT).isoformat()
        match_id = "_".join(sorted([current_user_id, target_id]))
        db.reference(f'matches/{match_id}').set({
            'users': {current_user_id: True, target_id: True},
            'matched_at': timestamp,
            'last_message': f'💘 You both shot your shot in the group chat!',
            'last_message_time': timestamp
        })
        flash("💘 OMG! It's a match! They shot their shot at you too. Check your unread chats!")
        db.reference(f'group_shots/{group_id}/{target_id}').delete()

        # Alert both users via real-time notification bell
        try:
            p_curr = db.reference(f'profiles/{current_user_id}').get() or {}
            p_targ = db.reference(f'profiles/{target_id}').get() or {}
            c_name = p_curr.get('name', 'Someone').split()[0]
            t_name = p_targ.get('name', 'Someone').split()[0]
            
            db.reference(f'notifications/{target_id}').push({
                'sender_id': current_user_id,
                'sender_name': p_curr.get('name', 'Someone'),
                'sender_img': p_curr.get('img', '/static/img/placeholder.png'),
                'type': 'shot',
                'title': '🎯 Shot Fired Match! 💘',
                'message': f"OMG! {c_name} shot their shot back at you in the group! Tap to chat.",
                'timestamp': timestamp,
                'match_id': match_id,
                'link': f"/matches/{current_user_id}",
                'status': 'unread'
            })
            db.reference(f'notifications/{current_user_id}').push({
                'sender_id': target_id,
                'sender_name': p_targ.get('name', 'Someone'),
                'sender_img': p_targ.get('img', '/static/img/placeholder.png'),
                'type': 'shot',
                'title': '🎯 Shot Fired Match! 💘',
                'message': f"OMG! It's a match! You and {t_name} shot your shots at each other!",
                'timestamp': timestamp,
                'match_id': match_id,
                'link': f"/matches/{target_id}",
                'status': 'unread'
            })
        except Exception as shot_notif_err:
            logger.error(f"Group shoot match notification push error: {shot_notif_err}")
    else:
        db.reference(f'group_shots/{group_id}/{current_user_id}').set(target_id)
        flash("💘 Shot fired! If they shoot back, it's a match.")
        
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/group/<group_id>/delete', methods=['POST'])
@requires_subscription
def delete_group(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    user_id = session['user_id']
    group_ref = db.reference(f'groups/{group_id}')
    group_data = group_ref.get()
    
    if not group_data:
        flash("Group not found.", "error")
        return redirect(url_for('groups'))
        
    members = group_data.get('members', {})
    
    # Check admin
    if members.get(user_id) != 'admin':
        flash("Only group admins can delete the group.", "error")
        return redirect(url_for('group_chat', group_id=group_id))
        
    group_name = group_data.get('name', 'Unknown Group')
    
    # Send email to all members
    for m_id, role in members.items():
        m_data = db.reference(f'profiles/{m_id}').get()
        if m_data and m_data.get('email'):
            try:
                send_broadcast_email(
                    recipient_email=m_data['email'],
                    recipient_name=m_data.get('name', 'Member').split(' ')[0],
                    subject="Group Deleted 🗑️",
                    message_body=f"The group '{group_name}' has been deleted by the admin. You will no longer be able to access this group chat or view its messages."
                )
            except Exception as e:
                print(f"Failed to email {m_data.get('email')}: {e}")
            
    # Delete from DB
    db.reference(f'groups/{group_id}').delete()
    db.reference(f'group_messages/{group_id}').delete()
    db.reference(f'group_shots/{group_id}').delete()
    db.reference(f'group_invites/{group_id}').delete()
    
    flash(f"Group '{group_name}' has been successfully deleted.")
    return redirect(url_for('groups'))

@app.route('/group/<group_id>')
@requires_subscription
def group_chat(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    
    group_data = db.reference(f"groups/{group_id}").get()
    if not group_data:
        flash("Group not found")
        return redirect(url_for('groups'))
        
    if 'members' not in group_data or user_id not in group_data['members']:
        flash("You are not a member of this group. Please join first.")
        return redirect(url_for('groups'))
        
    user_data = db.reference(f"profiles/{user_id}").get() or {}
    
    if not user_data.get('img') or not user_data.get('phone'):
        flash("You must add a profile photo and phone number before accessing group chats.")
        return redirect(url_for('profile'))
    
    member_details = []
    for m_id, role in group_data.get('members', {}).items():
        m_data = db.reference(f"profiles/{m_id}").get()
        if m_data:
            member_details.append({
                'id': m_id,
                'name': m_data.get('name', 'Unknown'),
                'photo_url': m_data.get('img', '/static/img/placeholder.png'),
                'institution': m_data.get('institution', ''),
                'is_online': m_data.get('is_online', False),
                'role': role
            })
            
    group_data['id'] = group_id
    
    join_requests = []
    if group_data.get('members', {}).get(user_id) == 'admin':
        requests = group_data.get('join_requests', {})
        for req_id, req_data in requests.items():
            req_data['id'] = req_id
            join_requests.append(req_data)
            
    is_admin = group_data.get('members', {}).get(user_id) == 'admin'
    return render_template('group_chat.html', group=group_data, user=user_data, members=member_details, join_requests=join_requests, is_admin=is_admin)

@app.route('/invite/<group_id>')
@requires_subscription
def group_invite(group_id):
    user_id = session.get('user_id')
    group_data = db.reference(f"groups/{group_id}").get()
    
    if not group_data:
        flash("This invite link is invalid or the group no longer exists.")
        return redirect(url_for('groups'))
        
    members = group_data.get('members', {})
    if user_id in members:
        return redirect(url_for('group_chat', group_id=group_id))
        
    return render_template('group_invite.html', group=group_data, group_id=group_id)

@app.route('/groups/request_access/<group_id>', methods=['POST'])
@requires_subscription
def request_join_group(group_id):
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))
        
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data:
        flash("Group not found")
        return redirect(url_for('groups'))
        
    # Instant access: grant membership directly
    group_ref.child(f'members/{user_id}').set('member')
    group_ref.child(f'join_requests/{user_id}').delete()
    
    now = datetime.now(EAT).isoformat()
    try:
        db.reference(f'chat_notifications/{user_id}').push({
            'sender_id': 'SYSTEM',
            'sender_name': group_data.get('name', 'Group'),
            'sender_img': group_data.get('icon') or '/static/img/placeholder.png',
            'type': 'group',
            'title': 'Joined Group! 🎉',
            'message': f"Welcome to {group_data.get('name', 'the group')}! You're in.",
            'timestamp': now,
            'match_id': f'group_invite_{group_id}',
            'link': f'/group/{group_id}'
        })
    except Exception as e:
        logger.error(f"Error adding join notification: {e}")
        
    flash(f"🎉 Welcome! You have joined {group_data.get('name', 'the group')}.")
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/approve_join/<group_id>/<target_user_id>', methods=['POST'])
@requires_subscription
def approve_join_group(group_id, target_user_id):
    user_id = session.get('user_id')
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data or group_data.get('members', {}).get(user_id) != 'admin':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
        
    group_ref.child(f'members/{target_user_id}').set('member')
    group_ref.child(f'join_requests/{target_user_id}').delete()
    
    now = datetime.now(EAT).isoformat()
    try:
        # Push persistent bell notification
        db.reference(f'notifications/{target_user_id}').push({
            'sender_id': user_id or 'SYSTEM',
            'sender_name': group_data.get('name', 'Group'),
            'sender_img': group_data.get('icon') or '/static/img/placeholder.png',
            'type': 'group',
            'title': '👥 Group Request Approved! 🎉',
            'message': f"You've been accepted into {group_data.get('name')}! Tap to chat.",
            'timestamp': now,
            'match_id': f'group_invite_{group_id}',
            'link': f'/group/{group_id}',
            'status': 'unread'
        })
        # Transient in-app toast
        db.reference(f'chat_notifications/{target_user_id}').push({
            'sender_id': user_id or 'system',
            'sender_name': group_data.get('name', 'Group'),
            'sender_img': group_data.get('icon') or '/static/img/placeholder.png',
            'type': 'group',
            'title': 'Group Approved! 🎉',
            'message': f"🎉 You were approved to join {group_data.get('name')}!",
            'timestamp': now,
            'match_id': f'group_invite_{group_id}',
            'link': f'/group/{group_id}'
        })
    except Exception as grp_notif_err:
        logger.error(f"Group approval notification error: {grp_notif_err}")
    
    flash("User approved and added to the group.")
    return redirect(url_for('group_chat', group_id=group_id))

@app.route('/api/groups/reject_join/<group_id>/<target_user_id>', methods=['POST'])
@requires_subscription
def reject_join_group(group_id, target_user_id):
    user_id = session.get('user_id')
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data or group_data.get('members', {}).get(user_id) != 'admin':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
        
    group_ref.child(f'join_requests/{target_user_id}').delete()
    
    flash("User request rejected.")
    return redirect(url_for('group_chat', group_id=group_id))


# ==========================================
# GROUP AUDIO & VIDEO CALL ROUTES
# ==========================================
from app.email_service import send_group_call_invite_email

@app.route('/api/groups/start_call/<group_id>', methods=['POST'])
@csrf.exempt
@requires_subscription
def start_group_call(group_id):
    """
    Initiates or retrieves an active group video/audio call session.
    Dispatches in-app notifications and emails to members not online.
    """
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
        
    user_id = session['user_id']
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data:
        return jsonify({'success': False, 'message': 'Group not found'}), 404
        
    members = group_data.get('members', {})
    if user_id not in members:
        return jsonify({'success': False, 'message': 'You must be a member to call'}), 403
        
    caller_data = db.reference(f"profiles/{user_id}").get() or {}
    caller_name = caller_data.get('name', 'Student').split()[0]
    caller_img = caller_data.get('img', '/static/img/placeholder.png')
    group_name = group_data.get('name', 'Campus Group')
    
    data = request.get_json(silent=True) or request.form.to_dict() or {}
    call_type = 'audio' if data.get('call_type') == 'audio' else 'video'
    
    # Check if there is already an active call in this group
    active_call = db.reference(f"group_calls/{group_id}/active").get()
    now_ms = int(time.time() * 1000)
    
    call_id = None
    if active_call and isinstance(active_call, dict) and active_call.get('call_id'):
        call_created = int(active_call.get('created_at', 0) or 0)
        if now_ms - call_created < 4 * 3600 * 1000:
            call_id = active_call.get('call_id')
            
    if not call_id:
        call_id = f"grpcall_{uuid.uuid4().hex[:10]}"
        call_payload = {
            'call_id': call_id,
            'group_id': group_id,
            'group_name': group_name,
            'started_by': user_id,
            'caller_name': caller_name,
            'caller_img': caller_img,
            'call_type': call_type,
            'status': 'active',
            'created_at': now_ms
        }
        db.reference(f"group_calls/{group_id}/{call_id}").set(call_payload)
        db.reference(f"group_calls/{group_id}/active").set(call_payload)
        
        # Post interactive announcement message to group chat
        try:
            db.reference(f'group_messages/{group_id}').push({
                'sender_id': 'SYSTEM',
                'sender_name': group_name,
                'user_name': caller_name,
                'is_system': True,
                'type': 'group_call',
                'call_type': call_type,
                'call_id': call_id,
                'message': f"📞 {caller_name} started a Group {call_type.title()} Call • Tap to Join",
                'timestamp': datetime.utcnow().isoformat()
            })
        except Exception as e:
            logger.error(f"Error posting group call message: {e}")

    base_url = (os.getenv("BASE_URL") or "https://findyourmatch.co.ke").rstrip("/")
    call_url = f"{base_url}/group/{group_id}/call/{call_id}"
    
    # Dispatch in-app notifications & email alerts in background
    def notify_group_members_async():
        for m_id in members.keys():
            if m_id == user_id:
                continue
            try:
                m_profile = db.reference(f"profiles/{m_id}").get() or {}
                m_name = m_profile.get('name', 'Comrade').split()[0]
                m_email = m_profile.get('email', '')
                is_online = bool(m_profile.get('is_online'))
                
                # 1. In-app real-time notification in Firebase
                db.reference(f'notifications/{m_id}').push({
                    'sender_name': f"{caller_name} ({group_name})",
                    'title': f"📞 Group {call_type.title()} Call",
                    'message': f"Incoming group call in {group_name}. Tap to join!",
                    'sender_img': caller_img,
                    'link': f"/group/{group_id}/call/{call_id}",
                    'type': 'group_call',
                    'timestamp': int(time.time() * 1000)
                })
                
                # Push to chat_notifications for bottom alert bar
                db.reference(f'chat_notifications/{m_id}').push({
                    'sender_id': user_id,
                    'sender_name': f"{caller_name} ({group_name})",
                    'sender_img': caller_img,
                    'type': 'group_call',
                    'title': f"📞 Group {call_type.title()} Call!",
                    'message': f"Live call started in {group_name}. Tap to answer.",
                    'timestamp': datetime.now(EAT).isoformat(),
                    'match_id': f"grpcall_{group_id}",
                    'link': f"/group/{group_id}/call/{call_id}"
                })
                
                # 2. Email notification to offline members
                if m_email and not is_online:
                    send_group_call_invite_email(
                        to_email=m_email,
                        user_name=m_name,
                        caller_name=caller_name,
                        caller_img=caller_img,
                        group_name=group_name,
                        call_type=call_type,
                        call_url=call_url
                    )

                # 3. Native Background Push Notification (alerts even if app is closed / screen locked)
                send_push_notification(
                    receiver_id=m_id,
                    title=f"📞 {caller_name} is calling ({group_name})",
                    body=f"Incoming Group {call_type.title()} Call. Tap to join now!",
                    click_url=f"/group/{group_id}/call/{call_id}"
                )
            except Exception as notify_err:
                logger.error(f"Error notifying member {m_id} for group call: {notify_err}")

    threading.Thread(target=notify_group_members_async, daemon=True).start()

    return jsonify({
        'success': True,
        'call_id': call_id,
        'call_type': call_type,
        'call_url': f"/group/{group_id}/call/{call_id}"
    })


@app.route('/group/<group_id>/call', methods=['GET'])
@app.route('/group/<group_id>/call/<call_id>', methods=['GET'])
@requires_subscription
def group_call_page(group_id, call_id=None):
    """
    Dedicated WhatsApp-style Group Video & Audio Call interface.
    Multi-peer WebRTC mesh with live camera grid, active speaker detection,
    mute controls, and in-call chat.
    """
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    user_id = session['user_id']
    group_ref = db.reference(f"groups/{group_id}")
    group_data = group_ref.get()
    
    if not group_data:
        flash("Group not found.")
        return redirect(url_for('groups'))
        
    members = group_data.get('members', {})
    if user_id not in members:
        flash("You are not a member of this group.")
        return redirect(url_for('groups'))
        
    user_data = db.reference(f"profiles/{user_id}").get() or {}
    user_name = user_data.get('name', 'Student').split()[0]
    user_img = user_data.get('img', '/static/img/placeholder.png')
    
    # If call_id is not specified, check active or create
    if not call_id:
        active_call = db.reference(f"group_calls/{group_id}/active").get()
        if active_call and isinstance(active_call, dict) and active_call.get('call_id'):
            call_id = active_call.get('call_id')
        else:
            call_id = f"grpcall_{uuid.uuid4().hex[:10]}"
            
    call_record = db.reference(f"group_calls/{group_id}/{call_id}").get() or {}
    call_type = call_record.get('call_type') or ('video' if request.args.get('video', 'true') == 'true' else 'audio')
    if request.args.get('type') in ['audio', 'video']:
        call_type = request.args.get('type')
        
    member_details = []
    for m_id, role in members.items():
        m_prof = db.reference(f"profiles/{m_id}").get() or {}
        member_details.append({
            'id': m_id,
            'name': m_prof.get('name', 'Student').split()[0],
            'photo_url': m_prof.get('img', '/static/img/placeholder.png'),
            'is_online': m_prof.get('is_online', False),
            'role': role
        })

    firebase_db_url = os.getenv('FIREBASE_DB_URL', 'https://mmust-dating-site-default-rtdb.firebaseio.com/').strip('"').rstrip('/')
    firebase_api_key = os.getenv('FIREBASE_API_KEY', '')
    base_url = (os.getenv("BASE_URL") or "https://findyourmatch.co.ke").rstrip("/")

    return render_template(
        'group_call.html',
        group=group_data,
        group_id=group_id,
        call_id=call_id,
        call_type=call_type,
        user=user_data,
        user_id=user_id,
        user_name=user_name,
        user_img=user_img,
        members=member_details,
        firebase_db_url=firebase_db_url,
        firebase_api_key=firebase_api_key,
        base_url=base_url
    )


@app.route('/api/groups/ring_member/<group_id>/<call_id>/<target_user_id>', methods=['POST'])
@csrf.exempt
@requires_subscription
def ring_group_member(group_id, call_id, target_user_id):
    """Allows anyone in the call to re-ring / ping an absent member."""
    if 'user_id' not in session:
        return jsonify({'success': False}), 401
    caller_id = session['user_id']
    caller_prof = db.reference(f"profiles/{caller_id}").get() or {}
    caller_name = caller_prof.get('name', 'Student').split()[0]
    caller_img = caller_prof.get('img', '/static/img/placeholder.png')
    
    group_data = db.reference(f"groups/{group_id}").get() or {}
    group_name = group_data.get('name', 'Campus Group')
    
    target_prof = db.reference(f"profiles/{target_user_id}").get() or {}
    target_name = target_prof.get('name', 'Comrade').split()[0]
    target_email = target_prof.get('email', '')
    
    call_record = db.reference(f"group_calls/{group_id}/{call_id}").get() or {}
    call_type = call_record.get('call_type', 'video')
    
    base_url = (os.getenv("BASE_URL") or "https://findyourmatch.co.ke").rstrip("/")
    call_url = f"{base_url}/group/{group_id}/call/{call_id}"
    
    # In-app notification
    db.reference(f'notifications/{target_user_id}').push({
        'sender_name': f"{caller_name} ({group_name})",
        'title': f"📞 Calling You to {group_name}!",
        'message': f"{caller_name} is calling you right now to join the group call!",
        'sender_img': caller_img,
        'link': f"/group/{group_id}/call/{call_id}",
        'type': 'group_call',
        'timestamp': int(time.time() * 1000)
    })
    
    # Email alert
    if target_email:
        threading.Thread(
            target=send_group_call_invite_email,
            args=(target_email, target_name, caller_name, caller_img, group_name, call_type, call_url),
            daemon=True
        ).start()

    # Native Background Push Notification
    send_push_notification(
        receiver_id=target_user_id,
        title=f"📞 {caller_name} is calling you to {group_name}!",
        body=f"Incoming Group {call_type.title()} Call. Tap to join now!",
        click_url=f"/group/{group_id}/call/{call_id}"
    )
        
    return jsonify({'success': True, 'message': f"Ringing {target_name}..."})


@app.route('/api/groups/end_call/<group_id>/<call_id>', methods=['POST'])
@csrf.exempt
@requires_subscription
def end_group_call(group_id, call_id):
    """Leaves or closes the group call session."""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False}), 401
        
    # Remove from participants
    db.reference(f"group_calls/{group_id}/{call_id}/participants/{user_id}").delete()
    
    # Check remaining participants
    participants = db.reference(f"group_calls/{group_id}/{call_id}/participants").get() or {}
    if not participants:
        # All members left, mark ended
        db.reference(f"group_calls/{group_id}/{call_id}").update({'status': 'ended', 'ended_at': int(time.time() * 1000)})
        active_call = db.reference(f"group_calls/{group_id}/active").get() or {}
        if active_call.get('call_id') == call_id:
            db.reference(f"group_calls/{group_id}/active").delete()
            
    return jsonify({'success': True})


# ==========================================
# SMART ACCOUNT ROUTING (Students vs Sponsors)
# ==========================================

@app.route('/clear-session')
def clear_session():
    """Manual override for testing/debugging to clear the session and cookies."""
    session.clear()
    from flask import make_response
    resp = make_response(redirect(url_for('home')))
    resp.set_cookie('account_type_pref', '', expires=0)
    return resp


# ==========================================
# 1. LADIES CHAT-TO-EARN (WEEKLY SQUAD OF 10)
# ==========================================

@app.route('/api/ladies/cohort-status', methods=['GET'])
def api_ladies_cohort_status():
    """Returns the live status of this week's 10-lady reward squad."""
    user_id = session.get('user_id')
    from app.services.ladies_reward_service import get_cohort_status
    status = get_cohort_status(user_id=user_id)
    return jsonify(status)


@app.route('/api/ladies/join-cohort', methods=['POST'])
@csrf.exempt
def api_ladies_join_cohort():
    """Enrolls a lady into this week's 10-lady reward squad. Enforces 10-slot limit."""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Please log in to join the Chat-to-Earn squad.'}), 401
    data = request.get_json(silent=True) or {}
    phone = data.get('phone')
    from app.services.ladies_reward_service import join_weekly_cohort
    res = join_weekly_cohort(user_id=user_id, phone=phone)
    return jsonify(res)


@app.route('/api/ladies/wallet-phone', methods=['POST'])
@csrf.exempt
def api_ladies_wallet_phone():
    """Updates the M-Pesa payout phone line for a lady's wallet."""
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    data = request.get_json(silent=True) or {}
    phone = data.get('phone')
    from app.services.ladies_reward_service import save_lady_wallet_phone
    res = save_lady_wallet_phone(user_id, phone)
    return jsonify(res)


@app.route('/api/cron/weekly-lady-payouts', methods=['GET', 'POST'])
@csrf.exempt
def api_cron_weekly_lady_payouts():
    """Disburses weekly chat earnings to enrolled ladies via M-Pesa B2C."""
    auth_header = request.headers.get('Authorization', '')
    bearer_token = auth_header.split(' ', 1)[1] if auth_header.startswith('Bearer ') else None
    cron_key = request.headers.get('X-Cron-Key') or request.args.get('cron_key') or bearer_token
    admin_key = request.headers.get('X-Admin-Key') or request.args.get('admin_key')

    secret_key = os.getenv('CRON_SECRET_KEY')
    vercel_secret = os.getenv('CRON_SECRET')
    raw_keys = [secret_key, vercel_secret, 'mmust_dating_cron_secret_2026', 'fym_promo_override_2026']
    valid_keys = {k.strip(' "\'') for k in raw_keys if k}

    clean_cron_key = (cron_key.strip(' "\'') if cron_key else None)
    clean_admin_key = (admin_key.strip(' "\'') if admin_key else None)

    is_admin = session.get('role') == 'admin' or session.get('super_admin') or session.get('is_super_admin')
    is_authorized = (
        (clean_cron_key and clean_cron_key in valid_keys)
        or (clean_admin_key and clean_admin_key == 'fym_promo_override_2026')
        or is_admin
    )
    if not is_authorized:
        return jsonify({"success": False, "error": "Unauthorized"}), 401

    force = request.args.get('force', '').lower() in ['true', '1', 'yes'] or bool(request.json and request.json.get('force'))
    week_key = request.args.get('week') or (request.json and request.json.get('week'))

    from app.payout_service import disburse_weekly_lady_earnings
    res = disburse_weekly_lady_earnings(week_key=week_key, force=force)
    return jsonify(res)


@app.route('/api/admin/launch-ladies-campaign', methods=['POST'])
@csrf.exempt
def api_admin_launch_ladies_campaign():
    """Admin switch to launch the Chat-to-Earn & NGL onboarding campaign to all ladies."""
    is_admin = session.get('is_super_admin') or session.get('role') == 'admin' or session.get('super_admin')
    if not is_admin:
        return jsonify({'success': False, 'message': 'Unauthorized. Admin access required.'}), 403

    from app.services.ladies_reward_service import dispatch_ladies_launch_campaign
    admin_name = session.get('name') or "Super Admin"
    res = dispatch_ladies_launch_campaign(
        admin_name=admin_name,
        push_fn=send_push_notification
    )
    return jsonify(res)


@app.route('/api/admin/ladies-campaign-status', methods=['GET'])
def api_admin_ladies_campaign_status():
    """Returns the current dispatch status and metrics for the ladies campaign."""
    is_admin = session.get('is_super_admin') or session.get('role') == 'admin' or session.get('super_admin')
    if not is_admin:
        return jsonify({'success': False, 'message': 'Unauthorized. Admin access required.'}), 403

    from app.services.ladies_reward_service import get_ladies_campaign_status
    status = get_ladies_campaign_status()
    return jsonify({"success": True, "status": status})


# ==========================================
# 2. NGL VIRAL ANONYMOUS LINK & CONFESSIONS
# ==========================================

@app.route('/ngl/<slug>')
def ngl_public_page(slug):
    """
    Public zero-login anonymous confession page.
    Renders receiver info, game prompt, interactive form, and viral CTA.
    """
    from app.services.ngl_service import get_public_ngl_profile
    profile_data = get_public_ngl_profile(slug)
    if not profile_data.get('found'):
        return render_template('404.html', message=profile_data.get('error', 'Link not found')), 404
    return render_template('ngl_respond.html', data=profile_data)


@app.route('/api/ngl/submit', methods=['POST'])
@csrf.exempt
def api_ngl_submit():
    """
    Public endpoint for submitting anonymous confessions without login.
    """
    data = request.get_json(silent=True) or {}
    slug = data.get('slug', '').strip()
    message_text = data.get('text', '').strip()
    user_agent = request.headers.get('User-Agent', '')
    ip_addr = request.remote_addr or request.headers.get('X-Forwarded-For', '')

    from app.services.ngl_service import submit_anonymous_confession
    res = submit_anonymous_confession(
        slug=slug,
        message_text=message_text,
        user_agent=user_agent,
        ip_address=ip_addr
    )
    return jsonify(res)


def resolve_current_ngl_user():
    """
    Resolves the user identity for NGL.
    If authenticated: returns (user_id, False, user_data)
    If guest/ghost: returns (ghost_id, True, ghost_profile)
    """
    user_id = session.get('user_id')
    if user_id:
        user_data = db.reference(f'profiles/{user_id}').get() or {}
        return user_id, False, user_data

    # Check client header, cookie, or session for ghost ID
    client_ghost = request.args.get('ghost_id') or request.headers.get('X-Ghost-Id')
    cookie_ghost = request.cookies.get('fym_ghost_ngl')
    session_ghost = session.get('ghost_user_id')

    ghost_id = session_ghost or cookie_ghost or client_ghost
    if not ghost_id or not str(ghost_id).startswith('ghost_'):
        import secrets
        ghost_id = f"ghost_{secrets.token_hex(6)}"

    session['ghost_user_id'] = ghost_id
    ghost_profile = {
        "name": "Comrade (Ghost Mode)",
        "is_ghost": True,
        "ghost_id": ghost_id
    }
    return ghost_id, True, ghost_profile


@app.route('/ngl')
def ngl_inbox_hub():
    """
    User's NGL inbox, link generator, and Canvas story card replier.
    Accessible to BOTH registered students and instant zero-login ghost users!
    """
    from flask import make_response
    from app.services.ngl_service import get_or_create_user_link, get_user_inbox

    user_id, is_ghost, user_data = resolve_current_ngl_user()
    link_info = get_or_create_user_link(user_id, is_ghost=is_ghost)
    inbox_messages = get_user_inbox(user_id)

    full_link = url_for('ngl_public_page', slug=link_info['slug'], _external=True)

    resp = make_response(render_template(
        'ngl_inbox.html',
        user=user_data,
        link_info=link_info,
        full_link=full_link,
        messages=inbox_messages,
        is_ghost=is_ghost,
        ghost_id=user_id if is_ghost else ""
    ))

    if is_ghost:
        # Keep ghost cookie valid for 1 year
        resp.set_cookie('fym_ghost_ngl', user_id, max_age=31536000, httponly=False, samesite='Lax')

    return resp


@app.route('/api/ngl/my-link', methods=['GET'])
def api_ngl_my_link():
    """Returns user link settings and prompts (works for registered & ghost users)."""
    from app.services.ngl_service import get_or_create_user_link
    user_id, is_ghost, _ = resolve_current_ngl_user()
    link_info = get_or_create_user_link(user_id, is_ghost=is_ghost)
    link_info['full_link'] = url_for('ngl_public_page', slug=link_info['slug'], _external=True)
    link_info['is_ghost'] = is_ghost
    return jsonify(link_info)


@app.route('/api/ngl/update-link', methods=['POST'])
@csrf.exempt
def api_ngl_update_link():
    """Updates slug, game type, or custom prompt for registered or ghost user."""
    user_id, is_ghost, _ = resolve_current_ngl_user()
    data = request.get_json(silent=True) or {}
    new_slug = data.get('slug')
    game_type = data.get('game_type')
    custom_prompt = data.get('custom_prompt')

    from app.services.ngl_service import update_user_link
    res = update_user_link(
        user_id=user_id,
        new_slug=new_slug,
        game_type=game_type,
        custom_prompt=custom_prompt
    )
    if res.get('success'):
        res['full_link'] = url_for('ngl_public_page', slug=res['slug'], _external=True)
    return jsonify(res)


@app.route('/api/ngl/inbox', methods=['GET'])
def api_ngl_inbox():
    """Fetches anonymous inbox messages for current user or ghost session."""
    user_id, is_ghost, _ = resolve_current_ngl_user()
    from app.services.ngl_service import get_user_inbox
    messages = get_user_inbox(user_id)
    return jsonify({"success": True, "messages": messages, "is_ghost": is_ghost})


@app.route('/api/ngl/inbox/read', methods=['POST'])
@csrf.exempt
def api_ngl_inbox_read():
    """Marks an anonymous message as opened/read."""
    user_id, _, _ = resolve_current_ngl_user()
    data = request.get_json(silent=True) or {}
    message_id = data.get('message_id')
    from app.services.ngl_service import mark_inbox_message_read
    ok = mark_inbox_message_read(user_id, message_id)
    return jsonify({"success": ok})


@app.route('/api/ngl/inbox/delete', methods=['POST'])
@csrf.exempt
def api_ngl_inbox_delete():
    """Deletes an anonymous message."""
    user_id, _, _ = resolve_current_ngl_user()
    data = request.get_json(silent=True) or {}
    message_id = data.get('message_id')
    from app.services.ngl_service import delete_inbox_message
    ok = delete_inbox_message(user_id, message_id)
    return jsonify({"success": ok})


@app.route('/api/ngl/claim', methods=['POST'])
@login_required
@csrf.exempt
def api_ngl_claim():
    """
    Migrates a ghost user's link and inbox confessions to their registered account.
    """
    user_id = session.get('user_id')
    data = request.get_json(silent=True) or {}
    ghost_id = data.get('ghost_id') or session.get('ghost_user_id') or request.cookies.get('fym_ghost_ngl')

    from app.services.ngl_service import claim_ghost_ngl_link
    res = claim_ghost_ngl_link(user_id, ghost_id)
    if res.get('success'):
        session.pop('ghost_user_id', None)
    return jsonify(res)


# ==========================================
# SPONSORS V2 INTEGRATION
# ==========================================
from app.routes.sponsors import sponsors_bp
app.register_blueprint(sponsors_bp)
csrf.exempt(sponsors_bp)


if __name__ == '__main__':
    # Grab the port from Render's environment, default to 5000 for local testing
    port = int(os.environ.get('PORT', 5000))
    # You must listen on '0.0.0.0' for external traffic on a server!
    app.run(host='0.0.0.0', port=port, debug=False)
